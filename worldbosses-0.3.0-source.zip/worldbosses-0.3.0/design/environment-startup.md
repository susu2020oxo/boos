# 可复用云环境启动说明

配置草稿更新返回 `draft_not_editable / CONFLICT`，系统说明草稿可能已经发布或仍处于发布流程中。因此本次新版启动说明保存在此文件；未确认写回环境配置草稿。

- 使用现有 `/workspace/boos` 检出目录，保留未提交源码、资源和设计文件。云任务已隔离，无须额外 Git worktree。
- 目标 Minecraft Java 1.21.10，Fabric Loader 0.17.3，Fabric API 0.138.4+1.21.10，Java 21。
- `tools/cloud-build.sh` 使用 `/workspace/tools/jdk-21.0.9+10`、`/workspace/tools/gradle-home`，保留环境代理和系统 CA。
- 在仓库运行 `./tools/cloud-build.sh build`、`python tools/check_resources.py`、`python tools/check_jar.py`。涉及游戏逻辑时运行 `./tools/cloud-build.sh runGametest` 并检查当次报告。
- 已通过 6 项生成预算 Java 单元测试、12 项模组 GameTest、1 项 Minecraft 基线 GameTest、5 项资源检查和生产 JAR 映射检查。
- 官方原版 Minecraft＋Fabric Loader＋两个实际安装 JAR 的独立客户端已进入单人世界，检查了代表性 Boss 模型和血条。安装包位于 `/workspace/artifacts`，不包含 Minecraft 本体。
- 客户端 Mixin 必须使用 `client-worldbosses-refmap.json`；主源集配置使用 `worldbosses-refmap.json`。不要因开发环境可启动而跳过生产 JAR 检查。
- Fabric/Mojang 域名配置已经在运行环境生效。遇到将来的下载失败先读当前运行状态，不要依据旧的 403 结论重复要求发布。
- 临时游戏与显示进程不视为持久服务，后续任务需要自行启动客户端或测试服务。可用的 Xvfb 位于 `/workspace/tools/xvfb/usr/bin/Xvfb`。
- 0.2.0 采用 68 种独立骨骼与材质模型、68 件独立成品掉落及共享敌对技能框架；未声称 68 种生物的全部动画或长期多人平衡均已手测。具体实现范围以 README 为准。

需要将本文件同步到环境设置时，待已有发布流程结束，再更新并审核发布；模组安装文件可以独立下载使用。
