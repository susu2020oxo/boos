package dev.susu.worldbosses;

import net.fabricmc.fabric.api.gametest.v1.GameTest;
import net.minecraft.entity.*;
import net.minecraft.entity.passive.*;
import net.minecraft.item.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.entity.effect.*;
import net.minecraft.entity.projectile.ArrowEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.GameMode;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.component.type.ContainerComponent;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.util.collection.DefaultedList;
import net.minecraft.potion.Potions;
import net.minecraft.test.TestContext;
import net.minecraft.text.Text;

/** Runs only in the development GameTest source set, never ships as production tests. */
public class BossGameTests {
    @GameTest public void wardenIsFiveTimesItsPreviousSize(TestContext context) {
        var warden=EntityType.WARDEN.create(context.getWorld(),SpawnReason.COMMAND);
        warden.setPosition(context.getAbsolutePos(new net.minecraft.util.math.BlockPos(60,100,60)).toCenterPos());
        context.getWorld().spawnEntity(warden);BossManager.loaded(warden,context.getWorld());
        context.assertTrue(Math.abs(warden.getScale()-1.08*5)<.001&&Math.abs(warden.getHeight()-2.3*1.08*5)<.01,Text.literal("Warden size: scale="+warden.getScale()+", height="+warden.getHeight()));
        BossManager.loaded(warden,context.getWorld());
        context.assertTrue(Math.abs(warden.getScale()-5.4)<.001,Text.literal("Reload must not multiply the fivefold scale again"));
        warden.discard();context.complete();
    }
    @GameTest public void ammoIsFreeWithAndWithoutInventoryArrows(TestContext context) {
        var p=player(context);
        for(String source:java.util.List.of("skeleton","stray","bogged","pillager")) {
            ItemStack bow=new ItemStack(BossItems.specialFor(source));
            p.setStackInHand(Hand.MAIN_HAND,bow);p.setStackInHand(Hand.OFF_HAND,ItemStack.EMPTY);
            var free=p.getProjectileType(bow);
            context.assertTrue(free.isOf(Items.ARROW)&&!free.isEmpty(),Text.literal("Boss ranged weapons must fire without inventory arrows"));
            ItemStack original=new ItemStack(Items.SPECTRAL_ARROW,7);p.setStackInHand(Hand.OFF_HAND,original);
            var chosen=p.getProjectileType(bow);chosen.decrement(1);
            context.assertTrue(chosen.isOf(Items.SPECTRAL_ARROW)&&original.getCount()==7,Text.literal("Special arrow effects must survive without spending real arrows"));
        }
        context.complete();
    }
    @GameTest public void allFinishedGearIsUnbreakable(TestContext context) {
        var p=player(context);
        for(var spec:LootCatalog.BY_ID.values()) {
            if(spec.durability()==0)continue;
            ItemStack gear=new ItemStack(BossItems.ALL.get(spec.id()));
            gear.damage(10000,p,EquipmentSlot.MAINHAND);
            context.assertTrue(gear.contains(DataComponentTypes.UNBREAKABLE)&&gear.getDamage()==0&&!gear.isEmpty(),Text.literal("Boss gear must not lose durability: "+spec.id()));
            context.assertTrue(spec.cooldown_ticks()==0,Text.literal("Published cooldown must be zero"));
        }
        context.complete();
    }
    @GameTest public void everySpecialFoodIsReusable(TestContext context) {
        var p=player(context);
        for(var spec:LootCatalog.BY_ID.values())if(spec.category().equals("food")) {
            ItemStack food=new ItemStack(BossItems.ALL.get(spec.id()));
            for(int i=0;i<3;i++) {
                ItemStack returned=food.finishUsing(context.getWorld(),p);
                context.assertTrue(returned.isOf(BossItems.ALL.get(spec.id()))&&returned.getCount()==1&&food.getCount()==1,Text.literal("The last food item must survive repeated consumption: "+spec.id()));
            }
        }
        context.complete();
    }
    @GameTest public void armorProvidesRealDefenseAndExtraAttributes(TestContext context) {
        var p=context.createMockCreativeServerPlayerInWorld();
        p.equipStack(EquipmentSlot.HEAD,new ItemStack(BossItems.specialFor("piglin")));
        p.equipStack(EquipmentSlot.CHEST,new ItemStack(BossItems.specialFor("iron_golem")));
        p.equipStack(EquipmentSlot.LEGS,new ItemStack(BossItems.specialFor("wolf")));
        p.equipStack(EquipmentSlot.FEET,new ItemStack(BossItems.specialFor("rabbit")));
        context.waitAndRun(3,()->{
            p.playerTick();
            context.assertTrue(p.getArmor()==30&&p.getMaxHealth()==42,Text.literal("Equipped attributes: armor="+p.getArmor()+", health="+p.getMaxHealth()));
            context.assertTrue(p.getAttributeValue(net.minecraft.entity.attribute.EntityAttributes.ARMOR_TOUGHNESS)==20&&p.getAttributeValue(net.minecraft.entity.attribute.EntityAttributes.MOVEMENT_SPEED)>.11,Text.literal("Toughness and movement attributes must apply to a real equipped player"));
            context.complete();
        });
    }
    @GameTest public void guardianIsActuallyGiantAndDoesNotStackOnReload(TestContext context) {
        var golem=EntityType.IRON_GOLEM.create(context.getWorld(),SpawnReason.COMMAND);
        golem.setPosition(context.getAbsolutePos(new net.minecraft.util.math.BlockPos(40,100,40)).toCenterPos());
        context.getWorld().spawnEntity(golem);BossManager.loaded(golem,context.getWorld());float height=golem.getHeight();
        BossManager.loaded(golem,context.getWorld());
        context.assertTrue(height>6&&golem.getHeight()==height,Text.literal("Guardian size="+height+", reload="+golem.getHeight()+", scale="+golem.getScale()));
        golem.discard();context.complete();
    }
    @GameTest(maxTicks=120) public void nativeCreeperAndLauncherBothDestroyBlocks(TestContext context) {
        var world=context.getWorld();var origin=context.getAbsolutePos(new net.minecraft.util.math.BlockPos(2048,0,0));
        var pos=new net.minecraft.util.math.BlockPos(origin.getX(),300,origin.getZ());
        var target=pos.down();world.setBlockState(target,net.minecraft.block.Blocks.STONE.getDefaultState());
        var creeper=EntityType.CREEPER.create(world,SpawnReason.COMMAND);creeper.setPosition(pos.toCenterPos());creeper.setNoGravity(true);creeper.setAiDisabled(true);
        world.spawnEntity(creeper);creeper.ignite();
        for(int i=0;i<32&&!creeper.isRemoved();i++)creeper.tick();
        context.assertTrue(BossExplosions.POWER==200,Text.literal("Explosion strength must be exactly 50 times TNT's strength of four"));
        var p=context.createMockCreativeServerPlayerInWorld();p.changeGameMode(GameMode.SURVIVAL);
        var second=pos.add(1024,0,0);world.setBlockState(second.down(),net.minecraft.block.Blocks.STONE.getDefaultState());
        p.requestTeleport(second.getX()+.5,300.5,second.getZ()+.5);p.setNoGravity(true);p.onTeleportationDone();p.setLoaded(true);
        var shot=new net.minecraft.entity.projectile.thrown.SnowballEntity(world,p,new ItemStack(Items.FIRE_CHARGE));
        shot.addCommandTag("worldbosses:shot:crack_grenade");
        BossItemEffects.projectileHit(shot,new net.minecraft.util.hit.BlockHitResult(second.toCenterPos(),net.minecraft.util.math.Direction.UP,second,false));
        context.waitAndRun(45,()->{
            context.assertTrue(creeper.isRemoved()&&world.getBlockState(target).isAir(),Text.literal("Native Boss creeper fuse must detonate and destroy stone"));
            context.assertTrue(world.getBlockState(second.down()).isAir(),Text.literal("Launcher fuse must detonate and destroy stone"));
            context.assertTrue(p.getHealth()<20,Text.literal("A shooter standing inside the blast must not be excluded from TNT damage"));
            context.complete();
        });
    }
    private static net.minecraft.entity.player.PlayerEntity player(TestContext context) {
        var p=context.createMockPlayer(GameMode.SURVIVAL);p.setUuid(java.util.UUID.randomUUID());return p;
    }
    @GameTest public void cookpotIsFreeAndCanRepeatImmediately(TestContext context) {
        var p=player(context);var item=BossItems.specialFor("fox");ItemStack tool=new ItemStack(item);
        p.setStackInHand(Hand.MAIN_HAND,tool);p.setStackInHand(Hand.OFF_HAND,new ItemStack(Items.PORKCHOP,10));
        p.getInventory().setStack(9,new ItemStack(Items.COAL,2));
        boolean used=BossItemEffects.use(BossItems.spec(tool),context.getWorld(),p,tool,Hand.MAIN_HAND,null);
        int cooked=0,coal=0;for(int i=0;i<p.getInventory().size();i++) {
            var s=p.getInventory().getStack(i);if(s.isOf(Items.COOKED_PORKCHOP))cooked+=s.getCount();if(s.isOf(Items.COAL))coal+=s.getCount();
        }
        context.assertTrue(used&&cooked==10&&coal==2&&p.getOffHandStack().isEmpty()&&tool.getDamage()==0,
                Text.literal("Cookpot must convert all ten raw meat without coal or durability cost"));
        p.setStackInHand(Hand.OFF_HAND,new ItemStack(Items.PORKCHOP,64));
        context.assertTrue(BossItemEffects.use(BossItems.spec(tool),context.getWorld(),p,tool,Hand.MAIN_HAND,null)&&p.getOffHandStack().isEmpty(),Text.literal("A second full stack must cook immediately without cooldown"));
        context.complete();
    }
    @GameTest public void royalFoodActuallyPreventsNewPoison(TestContext context) {
        var p=player(context);p.setHealth(10);p.addStatusEffect(new StatusEffectInstance(StatusEffects.POISON,100));
        ItemStack food=new ItemStack(BossItems.specialFor("bee"),2);food.finishUsing(context.getWorld(),p);
        context.assertTrue(!p.hasStatusEffect(StatusEffects.POISON)&&p.getHealth()==16&&food.getCount()==2,Text.literal("Royal comb must heal six, detoxify and retain its count"));
        context.assertTrue(!p.addStatusEffect(new StatusEffectInstance(StatusEffects.POISON,100)),Text.literal("Royal food immunity must reject a new poison effect through the real entity hook"));
        context.complete();
    }
    @GameTest public void repairKitIsFreeAndRepeatable(TestContext context) {
        var p=player(context);ItemStack kit=new ItemStack(BossItems.specialFor("mule"));ItemStack sword=new ItemStack(Items.IRON_SWORD);sword.setDamage(50);
        p.setStackInHand(Hand.MAIN_HAND,kit);p.setStackInHand(Hand.OFF_HAND,sword);
        for(int i=0;i<2;i++) {
            sword.setDamage(50);
            context.assertTrue(BossItemEffects.use(BossItems.spec(kit),context.getWorld(),p,kit,Hand.MAIN_HAND,null)&&sword.getDamage()==0&&kit.getDamage()==0,Text.literal("Repair must work without materials or cooldown and without tool wear"));
        }
        context.complete();
    }
    @GameTest public void newBowRetainsItsOwnArrowEffect(TestContext context) {
        var p=player(context);ItemStack bow=new ItemStack(BossItems.specialFor("stray"));
        ArrowEntity arrow=new ArrowEntity(context.getWorld(),p,new ItemStack(Items.ARROW),bow);
        context.assertTrue(arrow.getCommandTags().contains("worldbosses:arrow:frost_arrow"),Text.literal("A real bow-created arrow must remember its weapon through the production constructor mixin"));
        var pig=context.spawnEntity(EntityType.PIG,2,2,2);BossItemEffects.arrowHit(arrow,new EntityHitResult(pig));
        context.assertTrue(pig.hasStatusEffect(StatusEffects.SLOWNESS)&&pig.getFrozenTicks()>0,Text.literal("Frost arrows must actually slow and chill the struck creature"));context.complete();
    }
    @GameTest public void fallProtectionRequiresWearingTheBoots(TestContext context) {
        var p=player(context);ItemStack boots=new ItemStack(BossItems.specialFor("rabbit"));p.setStackInHand(Hand.MAIN_HAND,boots);
        context.assertTrue(BossItemEffects.damageFactor(p,p.getDamageSources().fall())==1,Text.literal("Holding boots must not grant an armor effect"));
        p.setStackInHand(Hand.MAIN_HAND,ItemStack.EMPTY);p.equipStack(EquipmentSlot.FEET,boots);
        context.assertTrue(BossItemEffects.damageFactor(p,p.getDamageSources().fall())==.35f,Text.literal("Worn moonstep boots must reduce fall damage"));context.complete();
    }
    @GameTest public void distillationChangesPotionAndCannotRepeat(TestContext context) {
        var p=player(context);ItemStack flask=new ItemStack(BossItems.specialFor("witch"));ItemStack potion=new ItemStack(Items.POTION);
        potion.set(DataComponentTypes.POTION_CONTENTS,new PotionContentsComponent(Potions.STRONG_POISON));
        p.setStackInHand(Hand.MAIN_HAND,flask);p.setStackInHand(Hand.OFF_HAND,potion);
        context.assertTrue(BossItemEffects.use(BossItems.spec(flask),context.getWorld(),p,flask,Hand.MAIN_HAND,null),Text.literal("Distiller must process a potion"));
        context.assertTrue(!potion.get(DataComponentTypes.POTION_CONTENTS).hasEffects(),Text.literal("Harmful potion effects must actually be removed"));
        BossItemEffects.mark(p,"cd_distill_potion",0);
        context.assertTrue(!BossItemEffects.use(BossItems.spec(flask),context.getWorld(),p,flask,Hand.MAIN_HAND,null),Text.literal("The same bottle must not be processed repeatedly"));context.complete();
    }
    @GameTest public void pocketReallyStoresAndRejectsNestedContainers(TestContext context) {
        var p=context.createMockCreativeServerPlayerInWorld();p.setUuid(java.util.UUID.randomUUID());
        ItemStack pocket=new ItemStack(BossItems.specialFor("shulker"));p.setStackInHand(Hand.MAIN_HAND,pocket);
        BossItemEffects.use(BossItems.spec(pocket),context.getWorld(),p,pocket,Hand.MAIN_HAND,null);
        var handler=p.currentScreenHandler;
        context.assertTrue(handler.slots.size()==45&&handler.canUse(p),Text.literal("Pocket must open nine real storage slots with the player's inventory"));
        context.assertTrue(!handler.getSlot(0).canInsert(pocket)&&!handler.getSlot(0).canInsert(new ItemStack(Items.SHULKER_BOX)),Text.literal("Pocket must reject itself and nested shulker boxes"));
        handler.getSlot(0).setStack(new ItemStack(Items.DIAMOND,3));p.closeHandledScreen();
        DefaultedList<ItemStack> saved=DefaultedList.ofSize(9,ItemStack.EMPTY);pocket.getOrDefault(DataComponentTypes.CONTAINER,ContainerComponent.DEFAULT).copyTo(saved);
        context.assertTrue(saved.getFirst().isOf(Items.DIAMOND)&&saved.getFirst().getCount()==3,Text.literal("Contents must persist on the actual item"));
        BossItemEffects.use(BossItems.spec(pocket),context.getWorld(),p,pocket,Hand.MAIN_HAND,null);
        context.assertTrue(p.currentScreenHandler.getSlot(0).getStack().getCount()==3,Text.literal("Reopening must preserve the saved inventory"));p.closeHandledScreen();context.complete();
    }
    @GameTest public void skeletonDropsFinishedEnchantedWeapon(TestContext context) {
        var skeleton=context.spawnEntity(EntityType.SKELETON,2,2,2);skeleton.damage(context.getWorld(),skeleton.getDamageSources().generic(),1000);
        context.waitAndRun(2,()->{
            var drops=context.getWorld().getEntitiesByClass(ItemEntity.class,skeleton.getBoundingBox().expand(4),e->true);
            var bow=drops.stream().map(ItemEntity::getStack).filter(s->s.isOf(BossItems.specialFor("skeleton"))).findFirst().orElseThrow();
            var ench=context.getWorld().getRegistryManager().getOrThrow(RegistryKeys.ENCHANTMENT);
            context.assertTrue(EnchantmentHelper.getLevel(ench.getOrThrow(Enchantments.POWER),bow)>=6&&EnchantmentHelper.getLevel(ench.getOrThrow(Enchantments.UNBREAKING),bow)==2,Text.literal("Finished skeleton bow must carry strong enchantments"));
            context.assertTrue(drops.stream().anyMatch(e->e.getStack().isOf(BossItems.SOUL_BONE)),Text.literal("Skeleton must also drop usable crafting bones"));context.complete();
        });
    }
    @GameTest public void pigHealthAndPersistence(TestContext context) {
        var pig = context.spawnEntity(EntityType.PIG, 2, 2, 2);
        context.assertTrue(pig.getMaxHealth() == 16, Text.literal("A friendly pig must have 16 HP"));
        pig.setHealth(7);
        BossManager.loaded(pig, context.getWorld());
        context.assertTrue(pig.getMaxHealth() == 16 && pig.getHealth() == 7,
                Text.literal("Repeated attachment must neither inflate HP nor heal"));
        context.complete();
    }
    @GameTest public void aquaticMobsRemainVanilla(TestContext context) {
        var axolotl = context.spawnEntity(EntityType.AXOLOTL, 2, 2, 2);
        context.assertTrue(!axolotl.getCommandTags().contains(BossManager.MARKER),
                Text.literal("Aquatic mobs must not become Bosses"));
        context.complete();
    }
    @GameTest public void pigDropsMoreThanAStack(TestContext context) {
        var pig = context.spawnEntity(EntityType.PIG, 2, 2, 2);
        pig.damage(context.getWorld(), pig.getDamageSources().generic(), 1000);
        context.waitAndRun(2, () -> {
            var drops = context.getWorld().getEntitiesByClass(ItemEntity.class, pig.getBoundingBox().expand(4), e -> true);
            int count = drops.stream().filter(e -> e.getStack().isOf(Items.PORKCHOP)).mapToInt(e -> e.getStack().getCount()).sum();
            context.assertTrue(count >= 72, Text.literal("Pig Boss must drop at least 72 raw porkchops"));
            context.assertTrue(drops.stream().anyMatch(e->e.getStack().isOf(BossItems.specialFor("pig")))
                    &&drops.stream().noneMatch(e->BossItems.LEGACY.containsValue(e.getStack().getItem())),
                    Text.literal("Pig must drop its finished buff food and no obsolete placeholder materials"));
            context.assertTrue(drops.stream().allMatch(e -> e.getStack().getCount() <= e.getStack().getMaxCount()),
                    Text.literal("Every dropped stack must respect its maximum size"));
            context.complete();
        });
    }
    @GameTest public void bossBloodFleshAndBonesAreRegistered(TestContext context) {
        var zombie = context.spawnEntity(EntityType.ZOMBIE, 2, 2, 2);
        context.assertTrue(zombie.getMaxHealth() == 50, Text.literal("Zombie boss HP must be 50"));
        zombie.damage(context.getWorld(), zombie.getDamageSources().generic(), 1000);
        context.waitAndRun(2, () -> {
            var drops = context.getWorld().getEntitiesByClass(ItemEntity.class, zombie.getBoundingBox().expand(4), e -> true);
            context.assertTrue(drops.stream().anyMatch(e -> e.getStack().isOf(BossItems.BLOOD_FLESH)),
                    Text.literal("Zombie boss must drop functional blood flesh"));
            context.complete();
        });
    }
}
