package dev.susu.worldbosses;

import org.junit.jupiter.api.Test;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;
import static dev.susu.worldbosses.SpawnBudget.*;

class SpawnBudgetTest {
    private final Point origin = new Point(0, 64, 0);
    private List<Occupant> four(String family) {
        return java.util.stream.IntStream.range(0, 4).mapToObj(i -> new Occupant(new Point(i, 64, 40), family)).toList();
    }
    @Test void fifthSameFamilyIsRejectedButOtherSpeciesAllowed() {
        assertFalse(permits(origin, "undead", List.of(origin), four("undead"), 128, 4, 12));
        assertTrue(permits(origin, "spider", List.of(origin), four("undead"), 128, 4, 12));
    }
    @Test void overlappingPlayersDoNotDoubleTheBudget() {
        var second = new Point(200, 64, 0);
        var mobs = four("undead").stream().map(o -> new Occupant(new Point(220,64,0),o.family())).toList();
        assertFalse(permits(origin, "undead", List.of(origin, second), mobs, 128, 4, 12));
    }
    @Test void transitiveOverlapIsMerged() {
        var players = List.of(origin, new Point(220,64,0), new Point(440,64,0));
        var mobs = four("undead").stream().map(o -> new Occupant(new Point(450,64,0),o.family())).toList();
        assertFalse(permits(origin,"undead",players,mobs,128,4,12));
    }
    @Test void disjointPlayersHaveSeparateBudgets() {
        var mobs = four("undead").stream().map(o -> new Occupant(new Point(600,64,0),o.family())).toList();
        assertTrue(permits(origin,"undead",List.of(origin,new Point(600,64,0)),mobs,128,4,12));
    }
    @Test void totalBudgetAppliesAcrossFamilies() {
        List<Occupant> mobs = new ArrayList<>();
        for (int i=0;i<12;i++) mobs.add(new Occupant(origin,"family"+i));
        assertFalse(permits(origin,"new",List.of(origin),mobs,128,4,12));
    }
    @Test void radiusIsThreeDimensionalAndIncludesBoundary() {
        assertFalse(permits(origin,"undead",List.of(origin),
                Collections.nCopies(4,new Occupant(new Point(128,64,0),"undead")),128,4,12));
        assertTrue(permits(origin,"undead",List.of(origin),
                Collections.nCopies(4,new Occupant(new Point(0,193,0),"undead")),128,4,12));
    }
}
