package dev.susu.worldbosses.client.mixin;

import net.minecraft.client.model.ModelPart;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.gen.Accessor;
import java.util.Map;
import java.util.List;

@Mixin(ModelPart.class)
public interface ModelPartAccessor {
    @Accessor("children") Map<String, ModelPart> worldbosses$getChildren();
    @Mutable @Accessor("children") void worldbosses$setChildren(Map<String, ModelPart> children);
    @Mutable @Accessor("cuboids") void worldbosses$setCuboids(List<ModelPart.Cuboid> cuboids);
}
