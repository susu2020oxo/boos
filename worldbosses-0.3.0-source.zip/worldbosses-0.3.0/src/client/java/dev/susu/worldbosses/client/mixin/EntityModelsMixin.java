package dev.susu.worldbosses.client.mixin;

import dev.susu.worldbosses.client.BossShapes;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.entity.model.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LoadedEntityModels.class)
public abstract class EntityModelsMixin {
    @Inject(method = "getModelPart", at = @At("RETURN"))
    private void worldbosses$decorate(EntityModelLayer layer, CallbackInfoReturnable<ModelPart> cir) {
        if (layer.name().equals("main")) BossShapes.decorate(layer.id().getPath(), cir.getReturnValue());
    }
}
