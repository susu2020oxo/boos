package dev.susu.worldbosses.client;

import com.google.gson.Gson;
import dev.susu.worldbosses.BossCatalog;
import dev.susu.worldbosses.WorldBosses;
import dev.susu.worldbosses.client.mixin.ModelPartAccessor;
import net.minecraft.client.model.*;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.util.Identifier;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Independent authored anatomy. Native cuboids are removed, leaving empty compatibility bones. */
public final class BossShapes {
    public record Material(String name,String color,String pattern) {}
    public record Bone(String name,String parent,float[] pivot,float[] rotation,String animation) {}
    public record Cube(String bone,float[] from,float[] size,int material,float[] rotation,float[] pivot) {}
    public record Sculpture(String id,int[] texture_size,float[] hitbox,List<Material> palette,List<Bone> bones,List<Cube> boxes) {}
    private record Pose(Sculpture sculpture,ModelPart ownRoot,Map<String,ModelPart> bones) {}
    private static final Map<String,Sculpture> DATA=new HashMap<>();
    private static final Map<ModelPart,Pose> POSES=Collections.synchronizedMap(new WeakHashMap<>());
    private static final float RAD=(float)(Math.PI/180);
    public static synchronized Sculpture data(String id) {
        if(DATA.containsKey(id))return DATA.get(id);
        try(InputStream in=BossShapes.class.getResourceAsStream("/assets/worldbosses/boss_models/"+id+".json")) {
            if(in==null)throw new IllegalStateException("Missing independent model "+id);
            Sculpture s=new Gson().fromJson(new InputStreamReader(in,StandardCharsets.UTF_8),Sculpture.class);
            if(s.boxes()==null||s.bones()==null||s.palette()==null)throw new IllegalStateException("Incomplete model "+id);
            DATA.put(id,s);return s;
        } catch(IOException e){throw new UncheckedIOException(e);}
    }
    public static boolean custom(LivingEntityRenderState state) {return state.entityType!=null&&BossCatalog.get(state.entityType)!=null;}
    public static String species(LivingEntityRenderState state) {return BossCatalog.get(state.entityType).entity();}
    public static Identifier texture(String id) {return WorldBosses.id("textures/entity/boss/"+id+".png");}
    public static Identifier emissive(String id) {return WorldBosses.id("textures/entity/boss/"+id+"_emissive.png");}
    public static boolean glows(String id) {return data(id).palette().stream().anyMatch(m->Set.of("fire","ice","void","honey").contains(m.pattern())&&!m.name().contains("eye"));}
    public static void decorate(String layer,ModelPart root) {
        String normalized=layer.split("/")[0];
        String id=BossCatalog.PROFILES.keySet().stream().sorted(Comparator.comparingInt(String::length).reversed())
                .filter(key->normalized.equals(key)||normalized.startsWith(key+"_")).findFirst().orElse(null);
        if(id==null)return;
        clearNative(root);
        boolean auxiliary=normalized.contains("armor")||normalized.contains("wool")||normalized.contains("saddle")
                ||normalized.contains("collar")||normalized.contains("decor")||normalized.contains("pattern");
        if(auxiliary)return;
        Sculpture sculpture=data(id);
        ModelPart anchor=new ModelPart(new ArrayList<>(),new HashMap<>());
        ModelTransform anchorTransform=normalized.contains("baby")?ModelTransform.origin(0,12,0).withScale(.5f):ModelTransform.NONE;
        anchor.setTransform(anchorTransform);anchor.setDefaultTransform(anchorTransform);
        Map<String,ModelPart> parts=new LinkedHashMap<>();parts.put("root",anchor);
        for(Bone bone:sculpture.bones()) {
            ModelPart part=new ModelPart(new ArrayList<>(),new HashMap<>());
            float[] p=bone.pivot(),r=bone.rotation()==null?new float[3]:bone.rotation();
            ModelTransform transform=ModelTransform.of(p[0],p[1],p[2],r[0]*RAD,r[1]*RAD,r[2]*RAD);
            part.setTransform(transform);part.setDefaultTransform(transform);parts.put(bone.name(),part);
        }
        for(Bone bone:sculpture.bones())add(parts.get(bone.parent()==null?"root":bone.parent()),"wb_"+bone.name(),parts.get(bone.name()));
        int tile=sculpture.texture_size()[0]/4;
        Map<String,ModelPartBuilder> batches=new LinkedHashMap<>();int rotated=0;
        for(Cube cube:sculpture.boxes()) {
            float[] f=cube.from(),size=cube.size();int u=cube.material()%4*tile,v=cube.material()/4*tile;
            boolean hasRotation=cube.rotation()!=null&&(cube.rotation()[0]!=0||cube.rotation()[1]!=0||cube.rotation()[2]!=0);
            if(hasRotation) {
                float[] p=cube.pivot()!=null?cube.pivot():new float[]{f[0]+size[0]/2,f[1]+size[1]/2,f[2]+size[2]/2};
                ModelData d=new ModelData();
                ModelPartBuilder builder=ModelPartBuilder.create().uv(u,v).cuboid(f[0]-p[0],f[1]-p[1],f[2]-p[2],size[0],size[1],size[2]);
                float[] r=cube.rotation();
                ModelPart part=d.getRoot().addChild("shape",builder,ModelTransform.of(p[0],p[1],p[2],r[0]*RAD,r[1]*RAD,r[2]*RAD))
                        .createPart(sculpture.texture_size()[0],sculpture.texture_size()[1]);
                add(parts.get(cube.bone()),"wb_rotated_"+(rotated++),part);
            } else {
                String key=cube.bone()+":"+cube.material();
                batches.computeIfAbsent(key,k->ModelPartBuilder.create()).uv(u,v).cuboid(f[0],f[1],f[2],size[0],size[1],size[2]);
            }
        }
        batches.forEach((key,builder)->{
            ModelData d=new ModelData();
            ModelPart part=d.getRoot().addChild("shape",builder,ModelTransform.NONE).createPart(sculpture.texture_size()[0],sculpture.texture_size()[1]);
            add(parts.get(key.substring(0,key.lastIndexOf(':'))),"wb_material_"+key.substring(key.lastIndexOf(':')+1),part);
        });
        add(root,"worldbosses_full_sculpture",anchor);POSES.put(root,new Pose(sculpture,anchor,parts));
    }
    private static void clearNative(ModelPart part) {
        var accessor=(ModelPartAccessor)(Object)part;
        for(ModelPart child:List.copyOf(accessor.worldbosses$getChildren().values()))clearNative(child);
        accessor.worldbosses$setCuboids(new ArrayList<>());
    }
    private static void add(ModelPart parent,String name,ModelPart child) {
        if(parent==null)throw new IllegalStateException("Absent independent bone parent for "+name);
        var accessor=(ModelPartAccessor)(Object)parent;
        Map<String,ModelPart> children=new HashMap<>(accessor.worldbosses$getChildren());children.put(name,child);accessor.worldbosses$setChildren(children);
    }
    public static void animate(ModelPart root,LivingEntityRenderState state) {
        Pose pose=POSES.get(root);if(pose==null)return;
        float age=state.age,walk=state.limbSwingAnimationProgress,amplitude=Math.min(1,state.limbSwingAmplitude);
        // Long, splayed spider legs use a shallow alternating gait, not a quadruped's high kick.
        if(pose.sculpture.id().endsWith("spider"))amplitude*=.28f;
        for(Bone spec:pose.sculpture.bones()) {
            ModelPart part=pose.bones.get(spec.name());String animation=spec.animation()==null?"none":spec.animation();
            switch(animation) {
                case "head" -> {part.yaw+=state.relativeHeadYaw*RAD;part.pitch+=state.pitch*RAD*.75f;}
                case "body" -> part.originY+=(float)Math.sin(age*.07)*.16f;
                case "jaw" -> part.pitch+=(float)(Math.sin(age*.085)*.045+.025);
                case "tail" -> part.yaw+=(float)Math.sin(age*.12)*.18f;
                case "leg_fl","leg_hr","leg_l" -> part.pitch+=(float)Math.cos(walk*.65)*.7f*amplitude;
                case "leg_fr","leg_hl","leg_r" -> part.pitch-=(float)Math.cos(walk*.65)*.7f*amplitude;
                case "arm_l" -> part.pitch-=(float)Math.cos(walk*.65)*.45f*amplitude;
                case "arm_r" -> part.pitch+=(float)Math.cos(walk*.65)*.45f*amplitude;
                case "wing_l" -> part.roll+=(float)Math.sin(age*.7)*.4f;
                case "wing_r" -> part.roll-=(float)Math.sin(age*.7)*.4f;
                case "float" -> part.originY+=(float)Math.sin(age*.07+spec.pivot()[0])*.7f;
                case "orbit" -> part.yaw+=age*.025f;
                case "pulse" -> {float n=1+(float)Math.sin(age*.12)*.025f;part.xScale*=n;part.yScale*=n;part.zScale*=n;}
                case "tentacle" -> part.pitch+=(float)Math.sin(age*.09+spec.pivot()[0])*.15f;
                default -> {}
            }
        }
    }
    private BossShapes(){}
}
