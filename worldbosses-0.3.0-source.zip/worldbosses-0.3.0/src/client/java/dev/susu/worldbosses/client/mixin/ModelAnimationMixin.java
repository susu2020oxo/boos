package dev.susu.worldbosses.client.mixin;
import dev.susu.worldbosses.client.BossShapes;
import net.minecraft.client.model.*;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(Model.class)
public abstract class ModelAnimationMixin {
    @Shadow @Final protected ModelPart root;
    @Inject(method="setAngles",at=@At("TAIL"))
    private void worldbosses$animate(Object state,CallbackInfo ci) {
        if(state instanceof LivingEntityRenderState living)BossShapes.animate(root,living);
    }
}
