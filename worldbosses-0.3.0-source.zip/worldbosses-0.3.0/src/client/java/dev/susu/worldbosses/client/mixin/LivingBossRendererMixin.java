package dev.susu.worldbosses.client.mixin;
import dev.susu.worldbosses.client.BossShapes;
import net.minecraft.client.render.*;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.client.render.state.CameraRenderState;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.*;
@Mixin(LivingEntityRenderer.class)
public abstract class LivingBossRendererMixin {
    @Shadow protected EntityModel<LivingEntityRenderState> model;
    @Shadow protected abstract void scale(LivingEntityRenderState state,MatrixStack matrices);
    @Inject(method="getRenderLayer",at=@At("HEAD"),cancellable=true)
    private void worldbosses$texture(LivingEntityRenderState state,boolean body,boolean translucent,boolean outline,CallbackInfoReturnable<RenderLayer> cir) {
        if(!BossShapes.custom(state))return;
        var texture=BossShapes.texture(BossShapes.species(state));
        cir.setReturnValue(translucent?RenderLayer.getItemEntityTranslucentCull(texture):body?RenderLayer.getEntityTranslucent(texture):outline?RenderLayer.getOutline(texture):null);
    }
    @Inject(method="shouldRenderFeatures",at=@At("HEAD"),cancellable=true)
    private void worldbosses$noNativeShells(LivingEntityRenderState state,CallbackInfoReturnable<Boolean> cir) {
        if(BossShapes.custom(state))cir.setReturnValue(false);
    }
    @Redirect(method="render(Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/render/state/CameraRenderState;)V",at=@At(value="INVOKE",target="Lnet/minecraft/client/render/entity/LivingEntityRenderer;scale(Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;)V"))
    private void worldbosses$ownProportions(LivingEntityRenderer<?,?,?> renderer,LivingEntityRenderState state,MatrixStack matrices) {
        if(!BossShapes.custom(state))scale(state,matrices);
    }
    @Inject(method="render(Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/render/state/CameraRenderState;)V",at=@At(value="INVOKE",target="Lnet/minecraft/client/util/math/MatrixStack;pop()V"))
    private void worldbosses$emissive(LivingEntityRenderState state,MatrixStack matrices,OrderedRenderCommandQueue queue,CameraRenderState camera,CallbackInfo ci) {
        if(!BossShapes.custom(state)||state.invisible)return;
        String id=BossShapes.species(state);if(!BossShapes.glows(id))return;
        queue.submitModel(model,state,matrices,RenderLayer.getEyes(BossShapes.emissive(id)),0xF000F0,OverlayTexture.DEFAULT_UV,-1,null,state.outlineColor,null);
    }
}
