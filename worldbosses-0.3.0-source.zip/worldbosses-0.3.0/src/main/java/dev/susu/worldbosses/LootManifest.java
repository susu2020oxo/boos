package dev.susu.worldbosses;

import com.google.gson.Gson;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** One authored finished artifact per species. Shared infrastructure does not imply shared behavior. */
public final class LootManifest {
    public record Food(int nutrition, float saturation) {}
    public record Definition(String id, String source, String category, String zh_name, String en_name,
                             String description_zh, String action, int cooldown_ticks, int duration_ticks,
                             float power, int durability, String slot, Food food) {
        public int cooldown() { return cooldown_ticks > 0 ? cooldown_ticks : 160; }
        public int duration() { return duration_ticks > 0 ? duration_ticks : 200; }
        public float strength(float fallback) { return power > 0 ? power : fallback; }
        public boolean isFood() { return category.equals("food"); }
    }
    private record Document(List<Definition> items) {}
    private static final Map<String, Definition> IDS = new LinkedHashMap<>();
    private static final Map<String, Definition> SOURCES = new LinkedHashMap<>();
    static {
        try (var stream = Objects.requireNonNull(LootManifest.class.getResourceAsStream("/loot_v2.json"), "Missing loot_v2.json")) {
            var doc = new Gson().fromJson(new InputStreamReader(stream, StandardCharsets.UTF_8), Document.class);
            for (Definition d : doc.items) {
                if (d.id == null || !d.id.matches("v2_[a-z0-9_]+") || !Set.of("weapon","tool","food","equipment").contains(d.category))
                    throw new IllegalArgumentException("Invalid v2 loot definition " + d);
                if (IDS.put(d.id, d) != null || SOURCES.put(d.source, d) != null)
                    throw new IllegalArgumentException("Duplicate finished drop " + d.id);
            }
            if (!SOURCES.keySet().equals(BossCatalog.PROFILES.keySet())) {
                Set<String> missing = new TreeSet<>(BossCatalog.PROFILES.keySet()); missing.removeAll(SOURCES.keySet());
                throw new IllegalArgumentException("Unfinished per-species loot coverage: " + missing);
            }
        } catch (Exception e) { throw new ExceptionInInitializerError(e); }
    }
    public static Definition byId(String id) { return IDS.get(id); }
    public static Definition forSource(String source) { return SOURCES.get(source); }
    public static Collection<Definition> all() { return Collections.unmodifiableCollection(IDS.values()); }
    private LootManifest() {}
}
