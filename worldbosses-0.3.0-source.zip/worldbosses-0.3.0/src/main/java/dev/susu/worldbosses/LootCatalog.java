package dev.susu.worldbosses;
import com.google.gson.Gson;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
public final class LootCatalog {
    public record Spec(String id,String source,String zh_name,String en_name,String category,String action,
                       String model_theme,String description_zh,int durability,int cooldown_ticks,float power,
                       String slot,int nutrition,float saturation,int duration_ticks) {}
    private record Manifest(List<Spec> items) {}
    public static final Map<String,Spec> BY_ID;
    public static final Map<String,Spec> BY_SOURCE;
    static {
        try(InputStream in=LootCatalog.class.getResourceAsStream("/loot_v2.json")) {
            if(in==null)throw new IllegalStateException("Missing unique loot manifest");
            Manifest manifest=new Gson().fromJson(new InputStreamReader(in,StandardCharsets.UTF_8),Manifest.class);
            Map<String,Spec> ids=new LinkedHashMap<>(),sources=new LinkedHashMap<>();
            for(Spec s:manifest.items()) {
                if(ids.put(s.id(),s)!=null||sources.put(s.source(),s)!=null)throw new IllegalStateException("Duplicate individual reward "+s.id());
                if(!Set.of("weapon","tool","food","equipment").contains(s.category()))throw new IllegalStateException("Invalid reward category "+s.id());
            }
            if(!sources.keySet().equals(BossCatalog.PROFILES.keySet()))throw new IllegalStateException("Every species must have an individual reward");
            BY_ID=Collections.unmodifiableMap(ids);BY_SOURCE=Collections.unmodifiableMap(sources);
        }catch(IOException e){throw new ExceptionInInitializerError(e);}
    }
    private LootCatalog(){}
}
