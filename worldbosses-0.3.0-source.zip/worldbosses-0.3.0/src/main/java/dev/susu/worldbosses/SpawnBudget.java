package dev.susu.worldbosses;

import java.util.*;

/** Pure, deterministic policy. The caller must reserve accepted spawns on the server thread. */
public final class SpawnBudget {
    public record Point(double x, double y, double z) {
        public double distanceSquared(Point other) {
            return Math.pow(x - other.x, 2) + Math.pow(y - other.y, 2) + Math.pow(z - other.z, 2);
        }
    }
    public record Occupant(Point position, String family) {}

    public static boolean permits(Point candidate, String family, List<Point> players,
                                  Collection<Occupant> occupants, int radius, int perFamily, int total) {
        Set<Integer> component = new HashSet<>();
        for (int i = 0; i < players.size(); i++) {
            if (candidate.distanceSquared(players.get(i)) <= (double) radius * radius) component.add(i);
        }
        if (component.isEmpty()) return true; // Chunk generation without a nearby player.
        boolean changed;
        do {
            changed = false;
            for (int i = 0; i < players.size(); i++) {
                if (component.contains(i)) continue;
                for (int j : List.copyOf(component)) {
                    if (players.get(i).distanceSquared(players.get(j)) <= 4.0 * radius * radius) {
                        changed |= component.add(i);
                        break;
                    }
                }
            }
        } while (changed);
        int same = 0, all = 0;
        for (Occupant occupant : occupants) {
            boolean inside = component.stream().anyMatch(i ->
                    occupant.position.distanceSquared(players.get(i)) <= (double) radius * radius);
            if (!inside) continue;
            all++;
            if (occupant.family.equals(family)) same++;
        }
        return same < perFamily && all < total;
    }
    private SpawnBudget() {}
}
