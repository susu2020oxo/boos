package dev.susu.worldbosses;
import com.google.gson.*;
import net.minecraft.entity.*;
import net.minecraft.entity.attribute.EntityAttributes;
import java.io.*;
import java.util.*;
public final class BossDimensions {
    private static final Map<String,float[]> CORE=new HashMap<>();
    public static synchronized float[] core(String id) {
        return CORE.computeIfAbsent(id,key->{
            try(InputStream stream=BossDimensions.class.getResourceAsStream("/assets/worldbosses/boss_models/"+key+".json")) {
                if(stream==null)throw new IllegalStateException("Missing physical model "+key);
                var a=JsonParser.parseReader(new InputStreamReader(stream,java.nio.charset.StandardCharsets.UTF_8)).getAsJsonObject().getAsJsonArray("hitbox");
                return new float[]{a.get(0).getAsFloat(),a.get(1).getAsFloat()};
            }catch(IOException e){throw new UncheckedIOException(e);}
        });
    }
    public static boolean active(LivingEntity mob) {
        var attr=mob.getAttributeInstance(EntityAttributes.SCALE);
        return BossCatalog.get(mob.getType())!=null&&attr!=null&&attr.getModifier(WorldBosses.id("boss_scale"))!=null;
    }
    private BossDimensions(){}
}
