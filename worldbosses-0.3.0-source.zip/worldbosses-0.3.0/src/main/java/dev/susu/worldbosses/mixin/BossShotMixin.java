package dev.susu.worldbosses.mixin;

import dev.susu.worldbosses.BossItemEffects;
import net.minecraft.entity.projectile.thrown.SnowballEntity;
import net.minecraft.util.hit.HitResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(SnowballEntity.class)
public abstract class BossShotMixin {
    @Inject(method="onCollision",at=@At("HEAD"),cancellable=true)
    private void applyBossShot(HitResult hit,CallbackInfo ci) {
        if(BossItemEffects.projectileHit((SnowballEntity)(Object)this,hit))ci.cancel();
    }
}
