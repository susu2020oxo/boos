package dev.susu.worldbosses.mixin;

import dev.susu.worldbosses.BossManager;
import net.minecraft.entity.*;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.world.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(MobEntity.class)
public abstract class MobEntityMixin {
    @Inject(method = "initialize", at = @At("HEAD"))
    private void worldbosses$source(ServerWorldAccess world, LocalDifficulty difficulty, SpawnReason reason,
                                   EntityData data, CallbackInfoReturnable<EntityData> cir) {
        MobEntity mob = (MobEntity) (Object) this;
        if (reason == SpawnReason.NATURAL || reason == SpawnReason.CHUNK_GENERATION)
            mob.addCommandTag(BossManager.NATURAL);
        if (reason == SpawnReason.MOB_SUMMONED) mob.addCommandTag(BossManager.MINION);
    }
}
