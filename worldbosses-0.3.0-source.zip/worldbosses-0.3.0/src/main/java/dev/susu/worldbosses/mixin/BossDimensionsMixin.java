package dev.susu.worldbosses.mixin;
import dev.susu.worldbosses.*;
import net.minecraft.entity.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(LivingEntity.class)
public abstract class BossDimensionsMixin {
    @Inject(method="getDimensions",at=@At("RETURN"),cancellable=true)
    private void worldbosses$body(EntityPose pose,CallbackInfoReturnable<EntityDimensions> cir) {
        LivingEntity entity=(LivingEntity)(Object)this;
        if(!BossDimensions.active(entity)||pose==EntityPose.SLEEPING)return;
        var p=BossCatalog.get(entity.getType());float[] core=BossDimensions.core(p.entity());
        float scale=entity.getScale()*(entity.isBaby()?.5f:1);
        cir.setReturnValue(EntityDimensions.changing(core[0]*scale,core[1]*scale).withEyeHeight(core[1]*scale*.78f));
    }
}
