package dev.susu.worldbosses;

import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import java.nio.file.*;

public final class BossConfig {
    public int radius = 128;
    public int perFamily = 4;
    public int hostileTotal = 12;
    public int visibleBossBars = 3;
    public boolean abilities = true;
    public boolean generousVanillaLoot = true;
    public boolean specialLoot = true;

    public static BossConfig load() {
        Path path = FabricLoader.getInstance().getConfigDir().resolve("worldbosses.json");
        var gson = new GsonBuilder().setPrettyPrinting().create();
        try {
            BossConfig c;
            if (Files.exists(path)) c = gson.fromJson(Files.readString(path), BossConfig.class);
            else {
                c = new BossConfig();
                Files.createDirectories(path.getParent());
                Files.writeString(path, gson.toJson(c));
            }
            if (c == null || c.radius < 16 || c.radius > 256 || c.perFamily < 1 || c.perFamily > 4
                    || c.hostileTotal < 1 || c.hostileTotal > 64 || c.visibleBossBars < 1 || c.visibleBossBars > 8)
                throw new IllegalArgumentException("Invalid worldbosses.json bounds; perFamily must be 1–4");
            return c;
        } catch (Exception e) {
            throw new IllegalStateException("Cannot read " + path + "; fix it rather than silently losing settings", e);
        }
    }
}
