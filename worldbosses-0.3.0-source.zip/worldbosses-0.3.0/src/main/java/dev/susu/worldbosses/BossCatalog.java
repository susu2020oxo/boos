package dev.susu.worldbosses;

import com.google.gson.Gson;
import net.minecraft.entity.EntityType;
import net.minecraft.registry.Registries;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public final class BossCatalog {
    public record Drop(String item, int min, int max) {}
    public record Profile(String entity, String name, String attitude, String family,
                          double health, double scale, String ability, String material,
                          String utility, int color, List<Drop> vanilla) {
        public boolean combatant() { return !attitude.equals("passive"); }
        public boolean hostile() { return attitude.equals("hostile"); }
    }
    public static final Map<String, Profile> PROFILES = load();

    private static Map<String, Profile> load() {
        try (var stream = Objects.requireNonNull(BossCatalog.class.getResourceAsStream("/boss_profiles.json"))) {
            var values = new Gson().fromJson(new InputStreamReader(stream, StandardCharsets.UTF_8), Profile[].class);
            Map<String, Profile> result = new LinkedHashMap<>();
            for (Profile p : values) {
                if (result.put(p.entity, p) != null) throw new IllegalStateException("Duplicate " + p.entity);
            }
            return Collections.unmodifiableMap(result);
        } catch (IOException e) { throw new ExceptionInInitializerError(e); }
    }
    public static Profile get(EntityType<?> type) { return PROFILES.get(Registries.ENTITY_TYPE.getId(type).getPath()); }
    private BossCatalog() {}
}
