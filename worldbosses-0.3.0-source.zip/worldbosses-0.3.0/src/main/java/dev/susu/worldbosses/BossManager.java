package dev.susu.worldbosses;

import net.minecraft.entity.*;
import net.minecraft.entity.attribute.*;
import net.minecraft.entity.boss.*;
import net.minecraft.entity.mob.*;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.Box;
import java.util.*;

public final class BossManager {
    public static final String MARKER = "worldbosses:boss", NATURAL = "worldbosses:natural", MINION = "worldbosses:minion";
    public static final ThreadLocal<Integer> SPLITTING = ThreadLocal.withInitial(() -> 0);
    private static final Map<ServerWorld, Map<UUID, State>> WORLDS = new IdentityHashMap<>();
    private static final Map<ServerWorld, Map<UUID, SpawnBudget.Occupant>> PENDING = new IdentityHashMap<>();

    public static final class State {
        public final MobEntity mob;
        public final BossCatalog.Profile profile;
        public final ServerBossBar bar;
        public int cooldown, windup;
        public net.minecraft.util.math.Vec3d aim;
        State(MobEntity mob, BossCatalog.Profile profile) {
            this.mob = mob; this.profile = profile;
            this.cooldown = 100 + mob.getRandom().nextInt(100);
            this.bar = new ServerBossBar(Text.literal(profile.name()),
                    profile.hostile() ? BossBar.Color.RED : BossBar.Color.GREEN, BossBar.Style.PROGRESS);
        }
    }

    public static void loaded(Entity entity, ServerWorld world) {
        if (!(entity instanceof MobEntity mob)) return;
        if (SPLITTING.get() > 0 && mob instanceof SlimeEntity) mob.addCommandTag(MINION);
        var p = BossCatalog.get(mob.getType());
        if (p == null || mob.getCommandTags().contains(MINION) || mob.getCommandTags().contains("worldbosses:no_boss")) return;
        apply(mob, p);
        State previous = WORLDS.computeIfAbsent(world, ignored -> new LinkedHashMap<>()).put(mob.getUuid(), new State(mob, p));
        if (previous != null) previous.bar.clearPlayers();
    }

    private static void apply(MobEntity mob, BossCatalog.Profile p) {
        float oldMax = mob.getMaxHealth(), ratio = Math.clamp(mob.getHealth() / oldMax, 0, 1);
        var hp = mob.getAttributeInstance(EntityAttributes.MAX_HEALTH);
        var scale = mob.getAttributeInstance(EntityAttributes.SCALE);
        // Saved, uniquely named modifiers avoid repeated health inflation and preserve damage across reloads.
        if (hp != null && hp.getModifier(WorldBosses.id("boss_health")) == null) {
            double base = hp.getBaseValue();
            double target = p.health() > 0 ? Math.max(base, p.health()) : p.hostile() ? base :
                    (p.attitude().equals("passive") ? Math.max(base, Math.min(40, base * 1.5)) : base * 1.25);
            hp.addPersistentModifier(new EntityAttributeModifier(WorldBosses.id("boss_health"), target - base,
                    EntityAttributeModifier.Operation.ADD_VALUE));
            mob.setHealth(mob.getMaxHealth() * ratio);
        }
        if(scale!=null&&!mob.getCommandTags().contains("worldbosses:shape_v3")){scale.removeModifier(WorldBosses.id("boss_scale"));mob.addCommandTag("worldbosses:shape_v3");}
        if (scale != null && scale.getModifier(WorldBosses.id("boss_scale")) == null) {
            double chosenScale = p.scale();
            // Keep vanilla spawn positions legal: fit the core body to the available space, never carve terrain.
            float[] core=BossDimensions.core(p.entity());
            while (!p.entity().equals("warden") && chosenScale > .35 && mob.getEntityWorld() instanceof ServerWorld world) {
                double half = core[0] * chosenScale / 2;
                Box bounds = new Box(mob.getX()-half, mob.getY(), mob.getZ()-half,
                        mob.getX()+half, mob.getY()+core[1]*chosenScale, mob.getZ()+half);
                if (world.isSpaceEmpty(mob, bounds)) break;
                chosenScale = Math.max(.35, chosenScale - .1);
            }
            scale.addPersistentModifier(new EntityAttributeModifier(WorldBosses.id("boss_scale"), chosenScale - 1,
                    EntityAttributeModifier.Operation.ADD_MULTIPLIED_BASE));
        }
        mob.addCommandTag(MARKER);
        mob.calculateDimensions();
    }

    public static void unloaded(Entity entity, ServerWorld world) {
        var map = WORLDS.get(world);
        if (map != null) {
            State state = map.remove(entity.getUuid());
            if (state != null) state.bar.clearPlayers();
        }
    }

    public static void resetConverted(MobEntity mob) {
        float ratio = Math.clamp(mob.getHealth() / mob.getMaxHealth(), 0, 1);
        for (var attribute : List.of(EntityAttributes.MAX_HEALTH, EntityAttributes.SCALE)) {
            var instance = mob.getAttributeInstance(attribute);
            if (instance != null) {
                instance.removeModifier(WorldBosses.id("boss_health"));
                instance.removeModifier(WorldBosses.id("boss_scale"));
            }
        }
        mob.removeCommandTag(MARKER);
        mob.setHealth(mob.getMaxHealth() * ratio);
        // A zombie becoming aquatic must not carry oversized boss attributes into an excluded species.
    }

    private static SpawnBudget.Point point(Entity entity) {
        return new SpawnBudget.Point(entity.getX(), entity.getY(), entity.getZ());
    }

    public static boolean allowNaturalSpawn(ServerWorld world, MobEntity mob) {
        var profile = BossCatalog.get(mob.getType());
        if (profile == null || !profile.combatant() || mob.getCommandTags().contains(MINION)) return true;
        var players = world.getPlayers().stream().filter(p -> !p.isSpectator()).map(BossManager::point).toList();
        Map<UUID, SpawnBudget.Occupant> occupants = new HashMap<>(PENDING.getOrDefault(world, Map.of()));
        for (var state : WORLDS.getOrDefault(world, Map.of()).values())
            if (state.mob.isAlive() && state.profile.combatant())
                occupants.put(state.mob.getUuid(), new SpawnBudget.Occupant(point(state.mob), state.profile.family()));
        var c = WorldBosses.CONFIG;
        boolean allowed = SpawnBudget.permits(point(mob), profile.family(), players, occupants.values(),
                c.radius, c.perFamily, c.hostileTotal);
        if (allowed) PENDING.computeIfAbsent(world, ignored -> new HashMap<>()).put(mob.getUuid(),
                new SpawnBudget.Occupant(point(mob), profile.family()));
        return allowed;
    }

    public static void tick(ServerWorld world) {
        PENDING.remove(world);
        var states = WORLDS.get(world);
        if (states == null) return;
        for (State s : List.copyOf(states.values())) {
            for (ServerPlayerEntity viewer : List.copyOf(s.bar.getPlayers()))
                if (viewer.getEntityWorld() != world || viewer.isRemoved()) s.bar.removePlayer(viewer);
            if (!s.mob.isAlive() || s.mob.isRemoved()) { s.bar.clearPlayers(); continue; }
            s.bar.setPercent(Math.clamp(s.mob.getHealth() / s.mob.getMaxHealth(), 0, 1));
            if (s.mob.hasCustomName()) s.bar.setName(s.mob.getCustomName());
            BossAbilities.tick(world, s);
            if (world.getTime() % 40 == 0)
                world.spawnParticles(s.profile.hostile() ? ParticleTypes.SOUL : ParticleTypes.ENCHANT,
                        s.mob.getX(), s.mob.getBodyY(.8), s.mob.getZ(), 2, .2, .1, .2, .01);
        }
        if (world.getTime() % 10 != 0) return;
        for (ServerPlayerEntity player : world.getPlayers()) {
            var visible = states.values().stream().filter(s -> s.mob.isAlive() &&
                    !player.isSpectator() && s.mob.squaredDistanceTo(player) <= 32 * 32)
                    .sorted(Comparator.<State>comparingInt(s -> s.mob.getTarget() == player ? 0 : 1)
                            .thenComparingDouble(s -> s.mob.squaredDistanceTo(player)))
                    .limit(WorldBosses.CONFIG.visibleBossBars).toList();
            Set<State> selected = Set.copyOf(visible);
            for (State s : states.values()) {
                if (selected.contains(s)) s.bar.addPlayer(player); else s.bar.removePlayer(player);
            }
        }
    }
    public static void clear() {
        WORLDS.values().forEach(states -> states.values().forEach(s -> s.bar.clearPlayers()));
        WORLDS.clear(); PENDING.clear(); SPLITTING.remove();
    }
    private BossManager() {}
}
