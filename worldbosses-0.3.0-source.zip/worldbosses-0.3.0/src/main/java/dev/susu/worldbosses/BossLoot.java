package dev.susu.worldbosses;

import net.minecraft.entity.*;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.passive.*;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.item.*;
import net.minecraft.registry.*;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;
import net.minecraft.world.GameRules;
import java.util.Map;

public final class BossLoot {
    private static final Map<String, String> COOKED = Map.of("porkchop", "cooked_porkchop", "beef", "cooked_beef",
            "chicken", "cooked_chicken", "mutton", "cooked_mutton", "rabbit", "cooked_rabbit", "cod", "cooked_cod");

    public static void onDeath(LivingEntity entity, DamageSource source) {
        if (!(entity instanceof MobEntity mob) || !(mob.getEntityWorld() instanceof ServerWorld world)
                || !mob.getCommandTags().contains(BossManager.MARKER)
                || mob.getCommandTags().contains(BossManager.MINION)
                || mob.getCommandTags().contains("worldbosses:rewarded")
                || !world.getGameRules().getBoolean(GameRules.DO_MOB_LOOT)) return;
        if (mob instanceof PassiveEntity passive && passive.isBaby()) return;
        var profile = BossCatalog.get(mob.getType());
        if (profile == null || profile.entity().equals("creaking")) return;
        mob.addCommandTag("worldbosses:rewarded");
        var random = mob.getRandom();
        if (WorldBosses.CONFIG.generousVanillaLoot) for (var entry : profile.vanilla()) {
            String id = entry.item();
            String path = Identifier.of(id).getPath();
            if (mob.isOnFire() && COOKED.containsKey(path)) id = "minecraft:" + COOKED.get(path);
            if (mob instanceof SheepEntity sheep && path.equals("white_wool")) {
                if (sheep.isSheared()) continue;
                id = "minecraft:" + sheep.getColor().asString() + "_wool";
            }
            int amount = entry.min() + random.nextInt(entry.max() - entry.min() + 1);
            drop(mob, world, Registries.ITEM.get(Identifier.of(id)), amount);
        }
        if (!WorldBosses.CONFIG.specialLoot) return;
        var spec = LootCatalog.BY_SOURCE.get(profile.entity());
        Item special = BossItems.specialFor(profile.entity());
        ItemStack reward = new ItemStack(special, spec.category().equals("food") ? 2 + random.nextInt(3) : 1);
        if (spec.action().endsWith("_arrow")) {
            var enchantments = world.getRegistryManager().getOrThrow(RegistryKeys.ENCHANTMENT);
            if (special instanceof CrossbowItem) {
                reward.addEnchantment(enchantments.getOrThrow(Enchantments.QUICK_CHARGE), 3);
                reward.addEnchantment(enchantments.getOrThrow(Enchantments.PIERCING), 4);
            } else reward.addEnchantment(enchantments.getOrThrow(Enchantments.POWER), random.nextFloat() < .2f ? 7 : 6);
            reward.addEnchantment(enchantments.getOrThrow(Enchantments.UNBREAKING), 2);
        }
        mob.dropStack(world, reward);
        if (profile.entity().equals("zombie")) drop(mob, world, BossItems.BLOOD_FLESH, 3 + random.nextInt(3));
        if (profile.family().equals("skeleton")) drop(mob, world, BossItems.SOUL_BONE, 4 + random.nextInt(3));
    }
    static void drop(MobEntity mob, ServerWorld world, Item item, int amount) {
        if (item == Items.AIR) throw new IllegalArgumentException("Unknown bonus loot item");
        // Never create illegal 96-count stacks. A pig produces a full stack plus a second legal stack.
        while (amount > 0) {
            int count = Math.min(amount, item.getMaxCount());
            mob.dropStack(world, new ItemStack(item, count));
            amount -= count;
        }
    }
    private BossLoot() {}
}
