package dev.susu.worldbosses.mixin;

import dev.susu.worldbosses.BossManager;
import net.minecraft.entity.Entity.RemovalReason;
import net.minecraft.entity.mob.SlimeEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(SlimeEntity.class)
public abstract class SlimeEntityMixin {
    @Inject(method = "remove", at = @At("HEAD"))
    private void worldbosses$beginSplit(RemovalReason reason, CallbackInfo ci) { BossManager.SPLITTING.set(BossManager.SPLITTING.get() + 1); }
    @Inject(method = "remove", at = @At("RETURN"))
    private void worldbosses$endSplit(RemovalReason reason, CallbackInfo ci) { BossManager.SPLITTING.set(Math.max(0, BossManager.SPLITTING.get() - 1)); }
}
