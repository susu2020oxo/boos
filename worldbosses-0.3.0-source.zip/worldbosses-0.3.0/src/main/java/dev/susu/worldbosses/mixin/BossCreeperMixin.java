package dev.susu.worldbosses.mixin;

import dev.susu.worldbosses.BossExplosions;
import dev.susu.worldbosses.BossManager;
import net.minecraft.entity.mob.CreeperEntity;
import net.minecraft.server.world.ServerWorld;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(CreeperEntity.class)
public abstract class BossCreeperMixin extends net.minecraft.entity.mob.HostileEntity {
    protected BossCreeperMixin(net.minecraft.entity.EntityType<? extends net.minecraft.entity.mob.HostileEntity> type,net.minecraft.world.World world){super(type,world);}
    @Shadow private void spawnEffectsCloud() {}
    @Inject(method="explode", at=@At("HEAD"), cancellable=true)
    private void bossDetonation(CallbackInfo ci) {
        var creeper=(CreeperEntity)(Object)this;
        if(creeper.getEntityWorld() instanceof ServerWorld world && creeper.getCommandTags().contains(BossManager.MARKER)) {
            dead=true;
            BossExplosions.detonate(world,creeper,creeper.getEntityPos());
            creeper.discard();spawnEffectsCloud();ci.cancel();
        }
    }
}
