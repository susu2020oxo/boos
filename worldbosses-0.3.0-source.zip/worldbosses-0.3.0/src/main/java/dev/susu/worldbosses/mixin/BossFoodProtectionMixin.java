package dev.susu.worldbosses.mixin;

import dev.susu.worldbosses.BossItemEffects;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.damage.DamageSource;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntity.class)
public abstract class BossFoodProtectionMixin {
    @Inject(method="canHaveStatusEffect",at=@At("HEAD"),cancellable=true)
    private void protectAfterMeal(StatusEffectInstance effect,CallbackInfoReturnable<Boolean> cir) {
        if(!BossItemEffects.permitsEffect((LivingEntity)(Object)this,effect))cir.setReturnValue(false);
    }
    @ModifyVariable(method="takeKnockback",at=@At("HEAD"),argsOnly=true,ordinal=0)
    private double armorKnockback(double strength) {
        return strength*BossItemEffects.knockbackFactor((LivingEntity)(Object)this);
    }
    @Inject(method="handleFallDamage",at=@At("TAIL"))
    private void bounceAfterLanding(double distance,float multiplier,DamageSource source,CallbackInfoReturnable<Boolean> cir) {
        BossItemEffects.landed((LivingEntity)(Object)this,distance);
    }
}
