package dev.susu.worldbosses.mixin;

import dev.susu.worldbosses.BossItemEffects;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.util.hit.EntityHitResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(PersistentProjectileEntity.class)
public abstract class BossArrowHitMixin {
    @Inject(method="onEntityHit",at=@At("TAIL"))
    private void applyRewardArrow(EntityHitResult hit,CallbackInfo ci) {
        BossItemEffects.arrowHit((PersistentProjectileEntity)(Object)this,hit);
    }
}
