package dev.susu.worldbosses;

import net.minecraft.entity.effect.*;
import net.minecraft.entity.projectile.ArrowEntity;
import net.minecraft.item.*;
import net.minecraft.particle.*;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.*;
import net.minecraft.util.math.*;

public final class BossAbilities {
    public static void tick(ServerWorld world, BossManager.State s) {
        if (!WorldBosses.CONFIG.abilities || !s.profile.hostile() || s.profile.ability().equals("none")) return;
        var mob = s.mob;
        if(mob instanceof net.minecraft.entity.mob.CreeperEntity)return;
        if (s.windup > 0) {
            if (s.windup % 4 == 0) telegraph(world, s);
            if (--s.windup == 0) {
                perform(world, s);
                s.cooldown = 180 + mob.getRandom().nextInt(100);
            }
            return;
        }
        if (s.cooldown > 0) { s.cooldown--; return; }
        if (!(mob.getTarget() instanceof ServerPlayerEntity target) || target.isCreative() || target.isSpectator()
                || mob.squaredDistanceTo(target) > 18 * 18 || !mob.getVisibilityCache().canSee(target)) return;
        s.aim = target.getEntityPos();
        s.windup = 26;
        world.playSound(null, mob.getX(), mob.getY(), mob.getZ(), SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME,
                SoundCategory.HOSTILE, .9f, .6f);
    }

    private static void ring(ServerWorld world, Vec3d center, double radius, ParticleEffect particle) {
        for (int i = 0; i < 24; i++) {
            double angle = Math.PI * 2 * i / 24;
            world.spawnParticles(particle, center.x + Math.cos(angle) * radius, center.y + .15,
                    center.z + Math.sin(angle) * radius, 1, 0, 0, 0, 0);
        }
    }
    private static void telegraph(ServerWorld world, BossManager.State s) {
        boolean atTarget = s.profile.ability().equals("poison") || s.profile.ability().equals("leap");
        ring(world, atTarget ? s.aim : s.mob.getEntityPos(), atTarget ? 2 : 3, ParticleTypes.END_ROD);
    }

    private static void perform(ServerWorld world, BossManager.State s) {
        var mob = s.mob;
        String ability = s.profile.ability();
        if (ability.equals("volley") || ability.equals("frost") || ability.equals("fire")) {
            Vec3d origin = mob.getEyePos();
            Vec3d aim = s.aim.add(0, 1, 0).subtract(origin).normalize();
            for (int i = -1; i <= 1; i++) {
                Vec3d direction = aim.rotateY(i * .22f);
                // Vanilla arrows preserve shield interaction, projectile travel and normal invulnerability frames.
                var arrow = new ArrowEntity(world, mob, new ItemStack(Items.ARROW), null);
                arrow.setPosition(origin);
                arrow.setVelocity(direction.x, direction.y + .05, direction.z, 1.2f, 1f);
                arrow.setDamage(2);
                if (ability.equals("frost")) arrow.addEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 60, 0));
                if (ability.equals("fire")) arrow.setOnFireFor(4);
                world.spawnEntity(arrow);
            }
            return;
        }
        if (ability.equals("teleport")) {
            Vec3d candidate = s.aim.add(3, 0, 0);
            Box destination = mob.getBoundingBox().offset(candidate.subtract(mob.getEntityPos()));
            if (world.isSpaceEmpty(mob, destination) && world.getBlockState(BlockPos.ofFloored(candidate).down()).isSolidBlock(world, BlockPos.ofFloored(candidate).down()))
                mob.teleport(candidate.x, candidate.y, candidate.z, false);
            ring(world, candidate, 2, ParticleTypes.PORTAL);
            // The normal melee AI performs the actual attack; no invisible teleport damage.
            return;
        }
        boolean targeted = ability.equals("leap") || ability.equals("poison");
        Vec3d center = targeted ? s.aim : mob.getEntityPos();
        double radius = targeted ? 2 : ability.equals("blast") ? 4 : 3;
        if (targeted && mob.squaredDistanceTo(center) > 12 * 12) return;
        if (ability.equals("leap")) {
            Vec3d towards = center.subtract(mob.getEntityPos()).normalize().multiply(.55);
            mob.setVelocity(towards.x, .45, towards.z);
        }
        ring(world, center, radius, ability.equals("blast") ? ParticleTypes.FLAME : ParticleTypes.SOUL_FIRE_FLAME);
        for (ServerPlayerEntity player : world.getPlayers()) {
            if (player.isCreative() || player.isSpectator() || player.squaredDistanceTo(center) > radius * radius
                    || Math.abs(player.getY() - center.y) > 2.5 || !mob.getVisibilityCache().canSee(player)) continue;
            Vec3d delta = player.getEntityPos().subtract(mob.getEntityPos());
            if (ability.equals("slam") && delta.lengthSquared() > 1 &&
                    mob.getRotationVec(1).dotProduct(delta.normalize()) < .25) continue;
            // Pulse shockwaves can be jumped over.
            if (ability.equals("pulse") && !player.isOnGround()) continue;
            float damage = ability.equals("poison") ? 2 : ability.equals("blast") ? 4 : 6;
            player.damage(world, mob.getDamageSources().mobAttack(mob), damage);
            if (ability.equals("poison")) player.addStatusEffect(new StatusEffectInstance(StatusEffects.POISON, 60, 0));
            if (ability.equals("wind")) player.takeKnockback(.7, -delta.x, -delta.z);
            if (ability.equals("leap")) player.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 40, 0));
        }
    }
    private BossAbilities() {}
}
