package dev.susu.worldbosses;

import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.*;
import net.minecraft.entity.*;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.*;
import net.minecraft.entity.attribute.*;
import net.minecraft.item.*;
import net.minecraft.item.equipment.*;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.registry.*;
import net.minecraft.registry.tag.DamageTypeTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.*;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import java.util.*;
import java.util.function.*;

public final class BossItems {
    public static final Map<String,Item> ALL=new LinkedHashMap<>();
    public static final Map<String,Item> LEGACY=new LinkedHashMap<>();
    public static Item BLOOD_FLESH,SOUP,SOUL_BONE,LONG_BOW;
    private static final ThreadLocal<Boolean> REDUCING=ThreadLocal.withInitial(()->false);
    public static LootCatalog.Spec spec(ItemStack stack){return stack.getItem() instanceof Described d?d.spec():null;}
    public static Item specialFor(String source){return ALL.get(LootCatalog.BY_SOURCE.get(source).id());}
    public static boolean freeAmmo(ItemStack weapon) {
        var s=spec(weapon);
        return s!=null&&s.action().endsWith("_arrow")||weapon.isOf(ALL.get("bone_bow"))||weapon.isOf(LONG_BOW);
    }
    private static final ArmorMaterial BOSS_ARMOR=new ArmorMaterial(50,
            Map.of(EquipmentType.HELMET,8,EquipmentType.CHESTPLATE,16,EquipmentType.LEGGINGS,12,EquipmentType.BOOTS,8,EquipmentType.BODY,16),
            25,ArmorMaterials.NETHERITE.equipSound(),5f,.15f,ArmorMaterials.IRON.repairIngredient(),ArmorMaterials.IRON.assetId());
    private static Item.Settings armor(Item.Settings s,EquipmentType type) {
        var slot=AttributeModifierSlot.forEquipmentSlot(type.getEquipmentSlot());
        double health=switch(type){case HELMET,BOOTS->4;case LEGGINGS->6;default->8;};
        var attrs=BOSS_ARMOR.createAttributeModifiers(type)
                .with(EntityAttributes.MAX_HEALTH,new EntityAttributeModifier(WorldBosses.id("v3_health_"+type.getName()),health,EntityAttributeModifier.Operation.ADD_VALUE),slot);
        if(type==EquipmentType.BOOTS)attrs=attrs.with(EntityAttributes.MOVEMENT_SPEED,new EntityAttributeModifier(WorldBosses.id("v3_boot_speed"),.15,EntityAttributeModifier.Operation.ADD_MULTIPLIED_TOTAL),slot);
        if(type==EquipmentType.HELMET)attrs=attrs.with(EntityAttributes.ATTACK_DAMAGE,new EntityAttributeModifier(WorldBosses.id("v3_helm_damage"),3,EntityAttributeModifier.Operation.ADD_VALUE),slot);
        return s.armor(BOSS_ARMOR,type).attributeModifiers(attrs).component(DataComponentTypes.UNBREAKABLE,Unit.INSTANCE);
    }
    private interface Described {LootCatalog.Spec spec();}
    private static Item add(String id,Function<Item.Settings,Item> factory,boolean visible) {
        var key=RegistryKey.of(RegistryKeys.ITEM,WorldBosses.id(id));
        Item item=Registry.register(Registries.ITEM,key,factory.apply(new Item.Settings().registryKey(key)));
        (visible?ALL:LEGACY).put(id,item);return item;
    }
    private static void lore(LootCatalog.Spec spec,Consumer<Text> lines){lines.accept(Text.literal(spec.description_zh()));}
    public static void register() {
        BLOOD_FLESH=add("blood_flesh",s->new HealingFood(s.food(new FoodComponent.Builder().nutrition(4).saturationModifier(.1f).alwaysEdible().build()),false),true);
        SOUP=add("purified_soup",s->new HealingFood(s.maxCount(16).food(new FoodComponent.Builder().nutrition(6).saturationModifier(.6f).alwaysEdible().build()),true),true);
        SOUL_BONE=add("soul_bone",BoneTool::new,true);
        // Saved-world compatibility only: old placeholders cannot be newly dropped or used as buff tokens.
        for(var profile:BossCatalog.PROFILES.values())if(!ALL.containsKey(profile.material())&&!LEGACY.containsKey(profile.material()))
            add(profile.material(),Item::new,false);
        for(EquipmentType type:List.of(EquipmentType.HELMET,EquipmentType.CHESTPLATE,EquipmentType.LEGGINGS,EquipmentType.BOOTS))
            add("bone_"+type.getName(),s->new Item(armor(s,type).maxDamage(type.getMaxDamage(50)).repairable(SOUL_BONE)
                    .component(DataComponentTypes.EQUIPPABLE,EquippableComponent.builder(type.getEquipmentSlot()).model(RegistryKey.of(EquipmentAssetKeys.REGISTRY_KEY,WorldBosses.id("soul_bone"))).build())),true);
        add("bone_sword",s->new Item(s.sword(ToolMaterial.NETHERITE,9,0).component(DataComponentTypes.UNBREAKABLE,Unit.INSTANCE).repairable(SOUL_BONE)),true);
        add("bone_bow",s->new BowItem(s.maxDamage(480).component(DataComponentTypes.UNBREAKABLE,Unit.INSTANCE).enchantable(25).repairable(SOUL_BONE)),true);
        LONG_BOW=add("soul_longbow",s->new BowItem(s.maxDamage(560).component(DataComponentTypes.UNBREAKABLE,Unit.INSTANCE).enchantable(25).rarity(Rarity.RARE).repairable(SOUL_BONE)),false);
        for(var spec:LootCatalog.BY_ID.values())add(spec.id(),settings->{
            if(spec.category().equals("food")) {
                settings.maxCount(16).food(new FoodComponent.Builder().nutrition(spec.nutrition()).saturationModifier(spec.saturation()).alwaysEdible().build());
                return new RewardFood(settings,spec);
            }
            if(spec.durability()>0)settings.maxDamage(spec.durability()).component(DataComponentTypes.UNBREAKABLE,Unit.INSTANCE).repairable(Items.IRON_INGOT);
            else settings.maxCount(1);
            if(spec.action().endsWith("_arrow")) {
                settings.enchantable(15).repairable(SOUL_BONE);
                return spec.action().equals("toxic_arrow")||spec.action().equals("siege_arrow")?new RewardCrossbow(settings,spec):new RewardBow(settings,spec);
            }
            if(spec.category().equals("weapon")) {
                if(Set.of("shield_cleaver","brute_charge").contains(spec.action()))settings.axe(ToolMaterial.NETHERITE,Math.max(1,spec.power()-5),16f);
                else settings.sword(ToolMaterial.NETHERITE,Math.max(1,spec.power()-5),16f);
            }
            if(spec.action().equals("vein_mine")||spec.action().equals("cliff_climb"))settings.pickaxe(ToolMaterial.NETHERITE,1,-2.8f);
            if(spec.action().equals("seed_excavate"))settings.shovel(ToolMaterial.NETHERITE,1,-3f);
            if(spec.action().equals("till_plane"))settings.hoe(ToolMaterial.NETHERITE,0,-2f);
            if(spec.durability()>0)settings.maxDamage(spec.durability());
            if(spec.category().equals("equipment")&&spec.slot()!=null&&!spec.slot().equals("offhand")) {
                EquipmentType type=switch(spec.slot()){case "head"->EquipmentType.HELMET;case "feet"->EquipmentType.BOOTS;case "legs"->EquipmentType.LEGGINGS;default->EquipmentType.CHESTPLATE;};
                armor(settings,type).maxDamage(spec.durability())
                        .component(DataComponentTypes.EQUIPPABLE,EquippableComponent.builder(type.getEquipmentSlot())
                                .model(RegistryKey.of(EquipmentAssetKeys.REGISTRY_KEY,WorldBosses.id(spec.id()))).build());
            }
            if(spec.category().equals("equipment")&&"offhand".equals(spec.slot())) {
                var attrs=AttributeModifiersComponent.DEFAULT
                        .with(EntityAttributes.ARMOR,new EntityAttributeModifier(WorldBosses.id("offhand_armor"),8,EntityAttributeModifier.Operation.ADD_VALUE),AttributeModifierSlot.OFFHAND)
                        .with(EntityAttributes.ARMOR_TOUGHNESS,new EntityAttributeModifier(WorldBosses.id("offhand_toughness"),3,EntityAttributeModifier.Operation.ADD_VALUE),AttributeModifierSlot.OFFHAND)
                        .with(EntityAttributes.MAX_HEALTH,new EntityAttributeModifier(WorldBosses.id("offhand_health"),6,EntityAttributeModifier.Operation.ADD_VALUE),AttributeModifierSlot.OFFHAND);
                if(spec.action().equals("trade_seal"))attrs=attrs.with(EntityAttributes.LUCK,new EntityAttributeModifier(WorldBosses.id("offhand_luck"),5,EntityAttributeModifier.Operation.ADD_VALUE),AttributeModifierSlot.OFFHAND);
                settings.attributeModifiers(attrs);
            }
            if(spec.action().equals("basalt_guard")) {
                settings.component(DataComponentTypes.BLOCKS_ATTACKS,Items.SHIELD.getComponents().get(DataComponentTypes.BLOCKS_ATTACKS));
                return new RewardShield(settings,spec);
            }
            return new Reward(settings,spec);
        },true);
        String[][] groups={{"weapons","武器","weapon"},{"tools","工具","tool"},{"foods","增益食物","food"},{"equipment","装备","equipment"}};
        for(var group:groups)Registry.register(Registries.ITEM_GROUP,WorldBosses.id(group[0]),FabricItemGroup.builder()
                .displayName(Text.literal("万物皆Boss · "+group[1])).icon(()->LootCatalog.BY_ID.values().stream().filter(s->s.category().equals(group[2])).findFirst().map(s->ALL.get(s.id()).getDefaultStack()).orElse(ItemStack.EMPTY))
                .entries((context,entries)->{
                    LootCatalog.BY_ID.values().stream().filter(s->s.category().equals(group[2])).forEach(s->entries.add(ALL.get(s.id())));
                    if(group[2].equals("food")){entries.add(BLOOD_FLESH);entries.add(SOUP);}
                    if(group[2].equals("tool"))entries.add(SOUL_BONE);
                    if(group[2].equals("equipment"))ALL.forEach((id,item)->{if(id.matches("bone_(helmet|chestplate|leggings|boots)"))entries.add(item);});
                    if(group[2].equals("weapon")){entries.add(ALL.get("bone_sword"));entries.add(ALL.get("bone_bow"));}
                }).build());
    }
    public static boolean armorDamage(LivingEntity entity,DamageSource source,float amount) {
        if(REDUCING.get()||amount<=0||!(entity.getEntityWorld() instanceof ServerWorld world))return true;
        int pieces=0;
        for(EquipmentSlot slot:List.of(EquipmentSlot.HEAD,EquipmentSlot.CHEST,EquipmentSlot.LEGS,EquipmentSlot.FEET)) {
            Item item=entity.getEquippedStack(slot).getItem();
            if(ALL.entrySet().stream().anyMatch(e->e.getKey().matches("bone_(helmet|chestplate|leggings|boots)")&&e.getValue()==item))pieces++;
        }
        float factor=(pieces>=2&&source.isIn(DamageTypeTags.IS_FALL)||pieces==4&&source.isIn(DamageTypeTags.IS_PROJECTILE))?.6f:1;
        factor*=BossItemEffects.damageFactor(entity,source);
        if(factor==1)return true;
        REDUCING.set(true);try{entity.damage(world,source,amount*factor);}finally{REDUCING.set(false);}return false;
    }
    private static class Reward extends Item implements Described {
        private final LootCatalog.Spec spec;
        Reward(Settings settings,LootCatalog.Spec spec){super(settings);this.spec=spec;}
        public LootCatalog.Spec spec(){return spec;}
        @Override public void appendTooltip(ItemStack stack,TooltipContext context,TooltipDisplayComponent display,Consumer<Text> lines,TooltipType type){lore(spec,lines);}
        @Override public ActionResult use(World world,net.minecraft.entity.player.PlayerEntity user,Hand hand) {
            if(spec.category().equals("equipment")&&spec.slot()!=null&&!spec.slot().equals("offhand")&&!user.isSneaking())return super.use(world,user,hand);
            return BossItemEffects.use(spec,world,user,user.getStackInHand(hand),hand,null)?ActionResult.SUCCESS:ActionResult.PASS;
        }
        @Override public ActionResult useOnBlock(ItemUsageContext context) {
            return BossItemEffects.use(spec,context.getWorld(),context.getPlayer(),context.getStack(),context.getHand(),context.getBlockPos())?ActionResult.SUCCESS:super.useOnBlock(context);
        }
    }
    private static final class RewardFood extends Item implements Described {
        private final LootCatalog.Spec spec;
        RewardFood(Settings settings,LootCatalog.Spec spec){super(settings);this.spec=spec;}
        public LootCatalog.Spec spec(){return spec;}
        @Override public void appendTooltip(ItemStack s,TooltipContext c,TooltipDisplayComponent d,Consumer<Text> lines,TooltipType t){lore(spec,lines);}
        @Override public ItemStack finishUsing(ItemStack stack,World world,LivingEntity user) {
            int count=stack.getCount();
            ItemStack result=super.finishUsing(stack,world,user);
            stack.setCount(count);result=stack;
            if(world instanceof ServerWorld&&user instanceof net.minecraft.entity.player.PlayerEntity player)BossItemEffects.eat(spec,player);
            return result;
        }
    }
    private static final class RewardBow extends BowItem implements Described {
        private final LootCatalog.Spec spec;RewardBow(Settings s,LootCatalog.Spec p){super(s);spec=p;}public LootCatalog.Spec spec(){return spec;}
        @Override public void appendTooltip(ItemStack s,TooltipContext c,TooltipDisplayComponent d,Consumer<Text> lines,TooltipType t){lore(spec,lines);}
    }
    private static final class RewardCrossbow extends CrossbowItem implements Described {
        private final LootCatalog.Spec spec;RewardCrossbow(Settings s,LootCatalog.Spec p){super(s);spec=p;}public LootCatalog.Spec spec(){return spec;}
        @Override public void appendTooltip(ItemStack s,TooltipContext c,TooltipDisplayComponent d,Consumer<Text> lines,TooltipType t){lore(spec,lines);}
    }
    private static final class RewardShield extends ShieldItem implements Described {
        private final LootCatalog.Spec spec;RewardShield(Settings s,LootCatalog.Spec p){super(s);spec=p;}public LootCatalog.Spec spec(){return spec;}
        @Override public void appendTooltip(ItemStack s,TooltipContext c,TooltipDisplayComponent d,Consumer<Text> lines,TooltipType t){lore(spec,lines);}
        @Override public ActionResult use(World world,net.minecraft.entity.player.PlayerEntity user,Hand hand){BossItemEffects.use(spec,world,user,user.getStackInHand(hand),hand,null);return super.use(world,user,hand);}
    }
    private static final class BoneTool extends Item {
        BoneTool(Settings s){super(s);}
        @Override public ActionResult useOnBlock(ItemUsageContext context) {
            return BoneMealItem.useOnFertilizable(context.getStack().copy(),context.getWorld(),context.getBlockPos())?ActionResult.SUCCESS:ActionResult.PASS;
        }
        @Override public void appendTooltip(ItemStack s,TooltipContext c,TooltipDisplayComponent d,Consumer<Text> lines,TooltipType t){lines.accept(Text.literal("可制作冥骨装备、剑与弓；也能对作物使用，发挥强效骨粉的作用。"));}
    }
    private static final class HealingFood extends Item {
        private final boolean purified;HealingFood(Settings s,boolean p){super(s);purified=p;}
        @Override public ItemStack finishUsing(ItemStack stack,World world,LivingEntity user) {
            int count=stack.getCount();
            var result=super.finishUsing(stack,world,user);
            stack.setCount(count);result=stack;
            if(world instanceof ServerWorld&&user instanceof net.minecraft.entity.player.PlayerEntity player) {
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION,purified?480:300,1));
                if(!purified&&player.getRandom().nextBoolean())player.addStatusEffect(new StatusEffectInstance(StatusEffects.HUNGER,600,0));
            }return result;
        }
    }
    private BossItems(){}
}
