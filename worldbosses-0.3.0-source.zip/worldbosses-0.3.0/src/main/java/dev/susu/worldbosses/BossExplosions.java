package dev.susu.worldbosses;

import net.minecraft.entity.Entity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/** TNT's strength is 4. The requested fiftyfold strength is 200, not fifty TNT entities. */
public final class BossExplosions {
    public static final float POWER = 4f * 50;
    public static void detonate(ServerWorld world, Entity source, Vec3d pos) {
        if(source instanceof net.minecraft.entity.player.PlayerEntity) {
            // Credit the shooter without excluding that player from the explosion's damage.
            world.createExplosion(null,world.getDamageSources().explosion(null,source),null,pos,POWER,false,World.ExplosionSourceType.TNT);
        } else world.createExplosion(source, pos.x, pos.y, pos.z, POWER, World.ExplosionSourceType.TNT);
    }
    private BossExplosions() {}
}
