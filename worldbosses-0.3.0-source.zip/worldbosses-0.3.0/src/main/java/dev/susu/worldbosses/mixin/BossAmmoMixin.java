package dev.susu.worldbosses.mixin;

import dev.susu.worldbosses.BossItems;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PlayerEntity.class)
public abstract class BossAmmoMixin {
    @Inject(method="getProjectileType",at=@At("RETURN"),cancellable=true)
    private void unlimitedBossAmmo(ItemStack weapon,CallbackInfoReturnable<ItemStack> cir) {
        if(!BossItems.freeAmmo(weapon))return;
        ItemStack selected=cir.getReturnValue();
        // Vanilla spends only this detached copy; chosen special arrows retain their effects.
        cir.setReturnValue(selected.isEmpty()?new ItemStack(Items.ARROW,64):selected.copyWithCount(64));
    }
}
