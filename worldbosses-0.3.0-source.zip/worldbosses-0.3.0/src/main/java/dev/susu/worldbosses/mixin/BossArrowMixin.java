package dev.susu.worldbosses.mixin;

import dev.susu.worldbosses.BossItemEffects;
import net.minecraft.entity.projectile.ArrowEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ArrowEntity.class)
public abstract class BossArrowMixin {
    @Inject(method="<init>(Lnet/minecraft/world/World;DDDLnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;)V",at=@At("TAIL"))
    private void rememberBow(World world,double x,double y,double z,ItemStack arrow,ItemStack bow,CallbackInfo ci) {
        if(bow!=null)BossItemEffects.markArrow((ArrowEntity)(Object)this,bow);
    }
    @Inject(method="<init>(Lnet/minecraft/world/World;Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;)V",at=@At("TAIL"))
    private void rememberShooterBow(World world,LivingEntity owner,ItemStack arrow,ItemStack bow,CallbackInfo ci) {
        if(bow!=null)BossItemEffects.markArrow((ArrowEntity)(Object)this,bow);
    }
}
