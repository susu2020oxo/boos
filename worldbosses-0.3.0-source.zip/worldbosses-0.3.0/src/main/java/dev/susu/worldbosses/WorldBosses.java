package dev.susu.worldbosses;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.CreakingHeartBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.world.GameRules;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.item.ItemGroups;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class WorldBosses implements ModInitializer {
    public static final String MOD_ID = "worldbosses";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    public static BossConfig CONFIG;
    public static Identifier id(String path) { return Identifier.of(MOD_ID, path); }

    @Override public void onInitialize() {
        CONFIG = BossConfig.load();
        BossItems.register();
        BossItemEffects.register();
        ServerEntityEvents.ENTITY_LOAD.register(BossManager::loaded);
        ServerEntityEvents.ENTITY_UNLOAD.register(BossManager::unloaded);
        ServerLivingEntityEvents.AFTER_DEATH.register(BossLoot::onDeath);
        ServerLivingEntityEvents.ALLOW_DAMAGE.register(BossItems::armorDamage);
        ServerLivingEntityEvents.MOB_CONVERSION.register((before, after, context) -> {
            if (before.getCommandTags().contains(BossManager.MINION)) after.addCommandTag(BossManager.MINION);
            BossManager.resetConverted(after);
        });
        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, blockEntity) -> {
            if (world instanceof ServerWorld serverWorld && WorldBosses.CONFIG.specialLoot && !player.isCreative() && state.isOf(Blocks.CREAKING_HEART)
                    && state.get(CreakingHeartBlock.NATURAL) && serverWorld.getGameRules().getBoolean(GameRules.DO_TILE_DROPS))
                Block.dropStack(world, pos, new ItemStack(BossItems.specialFor("creaking"), 1));
        });
        ServerTickEvents.END_WORLD_TICK.register(BossManager::tick);
        ServerLifecycleEvents.SERVER_STOPPED.register(server -> BossManager.clear());
        LOGGER.info("World Bosses {} profiles loaded for Minecraft 1.21.10", BossCatalog.PROFILES.size());
    }
}
