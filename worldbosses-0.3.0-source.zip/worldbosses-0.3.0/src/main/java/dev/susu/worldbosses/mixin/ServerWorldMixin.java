package dev.susu.worldbosses.mixin;

import dev.susu.worldbosses.BossManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.server.world.ServerWorld;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ServerWorld.class)
public abstract class ServerWorldMixin {
    @Inject(method = "spawnEntity", at = @At("HEAD"), cancellable = true)
    private void worldbosses$budget(Entity entity, CallbackInfoReturnable<Boolean> cir) {
        if (entity instanceof MobEntity mob && mob.getCommandTags().contains(BossManager.NATURAL)
                && !BossManager.allowNaturalSpawn((ServerWorld) (Object) this, mob)) cir.setReturnValue(false);
    }
}
