#!/usr/bin/env python3
"""Authored complete hostile anatomy/armor meshes. Outputs independent skeletons, never vanilla add-ons."""
from pathlib import Path
import json, math

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'src/main/resources/assets/worldbosses/boss_models'

class Mesh:
    def __init__(self, identity, palette, design):
        self.d={'id':identity,'texture_size':[1024,1024],'design':design,
                'palette':[{'name':n,'color':c,'pattern':p} for n,c,p in palette], 'bones':[], 'boxes':[]}
        self.materials={p['name']:i for i,p in enumerate(self.d['palette'])}
    def bone(self,name,pivot=(0,0,0),animation='none',parent='root',rotation=(0,0,0)):
        self.d['bones'].append({'name':name,'parent':parent,'pivot':list(pivot),'rotation':list(rotation),'animation':animation})
        return name
    def box(self,bone,x,y,z,w,h,d,material,rotation=None,pivot=None):
        b={'bone':bone,'from':[round(v,3) for v in (x,y,z)],'size':[round(v,3) for v in (w,h,d)],
           'material':self.materials[material] if isinstance(material,str) else material}
        if rotation is not None:b['rotation']=list(rotation)
        if pivot is not None:b['pivot']=list(pivot)
        self.d['boxes'].append(b)
    def plates(self,bone,x,y,z,cols,rows,sx,sy,depth,material,gap=.3):
        for row in range(rows):
            for col in range(cols):
                self.box(bone,x+col*sx,y+row*sy,z,sx-gap,sy-gap,depth,material)
    def moss(self,bone,x,y,z,count=5):
        for i in range(count):
            self.box(bone,x+(i%3)*1.3,y+i*.7,z,.65,1.8+(i%2),.6,'moss')
    def save(self):
        OUT.mkdir(parents=True,exist_ok=True)
        (OUT/(self.d['id']+'.json')).write_text(json.dumps(self.d,ensure_ascii=False,separators=(',',':'))+'\n')
        return self.d

STONE=[('skin','#658C53','skin'),('skin_dark','#365C36','skin'),('cloth','#248B8F','cloth'),('trousers','#59457B','cloth'),
       ('stone','#484B47','stone'),('edge','#777D70','stone'),('moss','#648947','leaf'),('eye','#13261C','void'),
       ('teeth','#D9D0AB','bone'),('glow','#7CCA5A','fire'),('strap','#5C493D','cloth')]

def head_face(m,bone='head',skin='skin',eyes='eye',nose=False):
    m.box(bone,-4.5,-5,-4.5,9,9,8,skin)
    m.box(bone,-4,-4.8,-4.9,3.4,1.1,.6,skin)
    m.box(bone,.6,-4.8,-4.9,3.4,1.1,.6,skin)
    for x in (-3.1,1.3):
        m.box(bone,x,-2.4,-4.85,1.8,1.7,.45,eyes)
        m.box(bone,x-.3,-3.2,-5,2.4,.6,.7,skin)
    m.box(bone,-2,1.6,-4.9,4,1.2,.45,eyes)
    for x in (-1.5,0,.9):m.box(bone,x,1.7,-5.1,.7,.8,.4,'teeth')
    if nose:
        m.box(bone,-1,-1.2,-7,2,4.5,2.8,skin)
        m.box(bone,-1.1,2.3,-7.2,2.2,1.1,1.3,skin)

def zombie(identity='zombie'):
    palette=list(STONE)
    if identity=='husk':
        palette=[(n,{'skin':'#B4A078','skin_dark':'#7E7355','cloth':'#8F8064','trousers':'#706149',
                     'stone':'#927D56','edge':'#C2AA76','moss':'#917A42','glow':'#D8AD54'}.get(n,c),p) for n,c,p in palette]
    if identity=='zombie_villager':
        palette=[(n,{'cloth':'#724963','trousers':'#423946','glow':'#9CCD4D'}.get(n,c),p) for n,c,p in palette]
    m=Mesh(identity,palette,{'zombie':'Asymmetric giant stone-arm tomb knight with original green face and cyan torn shirt.',
                            'husk':'Desiccated sandstone mummy, layered wrapping bands, sand-seal and burial mask.',
                            'zombie_villager':'Long-nosed plagued elder with broken-house timber backpack and crystal infected robe.'}[identity])
    m.bone('body',(0,1,0),'body');m.bone('head',(0,-1,-.5),'head')
    head_face(m,nose=identity=='zombie_villager')
    m.box('body',-6,0,-4,12,13,8,'cloth');m.box('body',-5.8,1,3.5,11.6,12,1,'cloth')
    for row in range(3):
        for col in range(4):
            if (col+row)%3!=1:m.box('body',-5.5+col*3,10+row,-4.4,2.2,3.5-row,.7,'cloth')
    m.box('body',-5,12.5,-3.6,10,3.5,7.2,'trousers')
    for side in (-1,1):
        leg='left_leg' if side==1 else 'right_leg'
        m.bone(leg,(side*3,16,0),'leg_l' if side==1 else 'leg_r')
        m.box(leg,-2.5,0,-3,5,7,6,'trousers');m.box(leg,-3,6,-4.2,6,2.2,8,'skin_dark')
        m.plates(leg,-2.7,4.5,-3.5,2,2,2.7,1.9,.9,'stone')
        m.box(leg,-2.8,7.2,-4.4,5.6,.8,8.4,'edge')
    m.bone('giant_arm',(-8,1,0),'arm_r')
    m.box('giant_arm',-5,-1,-4.3,8,10,8,'skin');m.box('giant_arm',-6,8,-5,9,9,10,'stone')
    m.plates('giant_arm',-6.4,3,-5.4,3,4,3,3,1,'stone')
    m.plates('giant_arm',-6.5,4,3.8,3,3,3,3,.8,'edge')
    for i in range(4):m.box('giant_arm',-5.8+i*2.1,15,-5.2,1.7,4.5,4,'skin_dark')
    for y in (2,7,12):m.box('giant_arm',-6.6,y,-5.7,9.5,.7,.8,'moss')
    m.bone('other_arm',(8,1,0),'arm_l')
    m.box('other_arm',-2.5,0,-3,5,15,6,'skin');m.box('other_arm',-2.6,-1,-3.2,5.2,4,6.4,'cloth')
    m.box('other_arm',-3,-4,-4.5,8,5,9,'stone')
    m.plates('other_arm',-3.5,-4.5,-5,3,2,2.7,2.5,1,'edge')
    if identity=='zombie':
        # Tomb slabs have deeply inset cross, stepped caps and hanging moss, as in the reference.
        m.box('other_arm',.5,-13,-2,6,10,3,'stone');m.box('other_arm',1.3,-15,-1.8,4.5,2.5,2.8,'edge')
        m.box('other_arm',3,-11.5,-2.3,1,6,.5,'skin_dark');m.box('other_arm',1.5,-9.5,-2.4,4,1,.5,'skin_dark')
        m.moss('other_arm',-2,-2,-5.8,8);m.moss('body',3,2,4.3,7)
        for x,y in [(-3,3),(2,7),(4,4)]:m.box('body',x,y,-4.6,1.4,2,.8,'skin')
    elif identity=='husk':
        for y in range(-4,4,2):
            m.box('head',-4.8,y,-5.1,9.6,.8,.8,'edge');m.box('head',4.4,y,-4.7,.8,.8,8.3,'edge')
        for y in range(1,12,2):m.box('body',-6.3,y,-4.4,12.6,1.2,.8,'strap')
        for y in range(1,14,3):m.box('other_arm',-2.9,y,-3.4,5.8,1.5,6.8,'edge')
        m.box('body',-2,3,-5,4,5,1,'edge');m.box('body',-1,3.8,-5.4,2,3.5,.6,'glow')
        for side in (-1,1):m.box('head',side*4.8-1,-6,-3.7,2,7,2,'stone')
    else:
        for side in (-1,1):
            m.box('body',side*6-1,-5,4,2,21,2,'strap')
            for y in (0,6,12):m.box('body',side*6-2,y,4.5,4,1.2,1.4,'stone')
        for y in (-4,1,6):m.box('body',-7,y,5,14,2,2,'strap')
        for i in range(7):
            m.box('body',-4+i*1.3,5+(i%3),-5.3,1,3+i%2,1.4,'glow')
        m.box('head',-5,-6,-3,10,2,7,'trousers');m.box('head',-4.9,-4,3,9.8,7,1.4,'trousers')
    return m

BONE=[('bone','#D5D1BB','bone'),('edge','#EEE5CC','bone'),('dark','#3D4548','bone'),('leather','#272D35','cloth'),
      ('soul','#64D1D6','glass'),('ice','#A6D7EA','ice'),('moss','#63845A','leaf'),('fungus','#9C5C48','skin'),
      ('wood','#665948','wood'),('iron','#7A888C','metal'),('ember','#C9724D','fire')]

def skeleton(identity='skeleton'):
    palette=list(BONE)
    if identity=='wither_skeleton':palette=[(n,{'bone':'#34393C','edge':'#596063','soul':'#B05B3B','leather':'#202426'}.get(n,c),p) for n,c,p in palette]
    m=Mesh(identity,palette,'Independent articulated bone anatomy with layered ribs, skull, vertebrae, sculpted fingers and species-specific weapon/mantle.')
    m.bone('body',(0,-1,0),'body');m.bone('head',(0,-6,0),'head')
    m.box('head',-4,-6,-4.5,8,8,7.5,'bone');m.box('head',-4.6,-4.5,-4.8,9.2,1.5,1.4,'edge')
    for x in (-3.2,1):
        m.box('head',x,-2.8,-4.7,2.2,2.4,.6,'dark');m.box('head',x+.5,-2.2,-5,.9,1,.5,'soul')
    m.box('head',-.7,-.1,-5,1.4,1.8,.7,'dark');m.box('head',-3.6,2,-4.6,7.2,2,5.5,'bone')
    for x in (-2.6,-1.3,0,1.3,2.6):m.box('head',x-.35,1,-5,.7,2,.6,'edge')
    for y in range(0,13,2):m.box('body',-1,y,-.9,2,1.6,2,'bone')
    for row in range(5):
        y=1+row*2
        for side in (-1,1):
            m.box('body',side*3.3-2.2,y,-2,4.4,.9,1.2,'bone')
            m.box('body',side*5.2-.55,y,-.7,1.1,1,3.4,'edge')
            m.box('body',side*3.7-1.7,y,2.5,3.4,.9,1.1,'bone')
    m.box('body',-.7,.5,-2.5,1.4,10,1.2,'edge');m.box('body',-4.5,12,-2.5,9,2.2,5,'bone')
    for side in (-1,1):
        leg='leg_left' if side==1 else 'leg_right';m.bone(leg,(side*2.8,14,0),'leg_l' if side==1 else 'leg_r')
        for x in (-1,.4):m.box(leg,x,0,-.6,.7,8.5,1.2,'bone')
        m.box(leg,-1.8,4.6,-1.5,3.6,1.8,3,'edge');m.box(leg,-1.9,8,-3,3.8,2,4.8,'bone')
        for j in range(3):m.box(leg,-1.7+j*1.2,9,-4.2,.8,1,1.7,'edge')
        arm='arm_left' if side==1 else 'arm_right';m.bone(arm,(side*6,-.5,0),'arm_l' if side==1 else 'arm_r')
        m.box(arm,-1.1,0,-.9,2.2,8,1.8,'bone');m.box(arm,-1.8,6.5,-1.7,3.6,2,3.4,'edge')
        m.box(arm,-1,8,-1.1,.7,7,1.6,'bone');m.box(arm,.4,8,-1.1,.7,7,1.6,'bone')
        m.box(arm,-1.6,14.2,-1.7,3.2,2,2.4,'bone')
        for j in range(3):m.box(arm,-1.4+j,15.5,-2.5,.7,2.5,1.2,'edge')
        m.box(arm,-2.8,-1.2,-2.5,5.6,3.2,5,'dark')
        m.box(arm,-2.6,-1.7,-2.7,5.2,1.2,5.4,'edge')
    if identity=='skeleton':
        for x in (-4,-2,0,2,4):
            m.box('head',x-.45,-9-abs(x)*.35,-4.7,.9,4.5+abs(x)*.35,1,'dark')
            m.box('head',x-.55,-10-abs(x)*.35,-4.8,1.1,1.7,1.2,'edge')
        m.bone('cloak',(0,1,3),'tail')
        for i in range(7):
            m.box('cloak',-7+i*2,0,0,1.6,17+(i%3)*2,1,'leather')
            m.box('cloak',-7+i*2,12+(i%2)*2,.3,1.6,7,.7,'dark')
    elif identity=='stray':
        m.bone('frost_mantle',(0,-1,2),'tail')
        for i in range(9):
            m.box('frost_mantle',-9+i*2,0,1,1.8,18+(i%3)*2,1.2,'leather')
            m.box('frost_mantle',-9+i*2,15+(i%3),.2,1.7,6,1.2,'ice')
        for side in (-1,1):
            for i in range(4):m.box('body',side*(4+i*.8)-.5,-5+i*.6,-1,.9,5.5-i*.8,1.2,'ice')
        m.box('head',-5,-7,-4,10,2,9,'leather')
    elif identity=='bogged':
        for side in (-1,1):m.moss('head',side*3,1,-5,6)
        for i in range(7):
            x=-5+i*1.6;y=-7-(i%2)*2;z=(i%3)*2-2
            m.box('head',x,y,z,1,2.5,1,'wood');m.box('head',x-1.2,y-1,z-1.2,3.4,1.1,3.4,'fungus')
        for i in range(6):m.box('body',-5+i*1.8,3+(i%2),3.7,1.1,11-i%3,1.2,'moss')
    else:
        # Charcoal executioner shoulders, ember-coal neck and enormous chipped stone sword.
        for side in (-1,1):
            for i in range(4):m.box('body',side*(5+i*.9)-1,-3-i*.8,-2,2,4.5,4,'dark')
        for i in range(6):m.box('body',-3+i,3+(i%2),-3,1,5,.8,'ember')
        sword(m,'arm_right','dark','edge','ember',long=True)
    if identity!='wither_skeleton':bow(m,'arm_left','ice' if identity=='stray' else 'bone','soul')
    return m

def bow(m,parent,main='bone',glow='soul'):
    m.bone('great_bow',(1,12,-3),'none',parent)
    for i in range(-6,7):
        x=2.5+(6-abs(i))*.58;y=i*2.5
        m.box('great_bow',x,y,-.9,2,3,1.8,main)
        if abs(i)%2==0:m.box('great_bow',x+.4,y+.3,-1.4,1.2,1.8,.6,glow)
    m.box('great_bow',1,-14,-.35,.4,30,.7,'leather')
    m.box('great_bow',-.7,-.5,-1.6,3.4,2.8,3.2,'dark')

def sword(m,parent,blade='iron',edge='edge',glow='soul',long=False):
    m.bone('sword',(0,15,-3),'none',parent)
    m.box('sword',-.8,-1,-.8,1.6,6,1.6,'leather');m.box('sword',-4,-2,-1.2,8,1.5,2.4,edge)
    length=22 if long else 16
    for i in range(length//2):
        w=4 if i<length//2-2 else 3 if i==length//2-2 else 1.5
        m.box('sword',-w/2,-3-i*2,-.7,w,2.2,1.4,blade)
        if i%3==0:m.box('sword',-.35,-3-i*2,-1,.7,1.8,.5,glow)
    for i in (1,4,7):
        if i<length//2:m.box('sword',-2.7,-4-i*2,-.75,1.2,1.6,1.5,edge)

def creeper():
    pal=[('hide','#5A9C43','skin'),('light','#87BB58','leaf'),('dark','#20352B','void'),('stone','#424A41','stone'),
         ('edge','#6C7566','stone'),('moss','#577A35','leaf'),('fire','#FFAA32','fire'),('core','#FFD665','glass')]
    m=Mesh('creeper',pal,'Four-legged moss-stone creeper. Deep black classic face, visible nested orange square core, layered broken plates and chunky four feet.')
    m.bone('body',(0,3,0),'body');m.bone('head',(0,-5,-.8),'head')
    m.box('body',-5,0,-4,10,13,8,'hide');m.box('body',-3,2,-5.1,6,6,2,'fire');m.box('body',-1.5,3.6,-5.8,3,3,1,'core')
    # Stone frame leaves the burning central square exposed rather than burying it under geometry.
    for x in (-5.6,3.8):m.box('body',x,1,-5.4,1.8,10,2,'stone')
    for y in (0,8.8):m.box('body',-4,y,-5.4,8,1.5,2,'edge')
    m.plates('body',-5.8,0,3.5,4,4,3,3.5,1.4,'stone')
    for side in (-1,1):
        m.bone('side_plates_'+str(side),(side*5.7,0,0),'none')
        for y in range(0,12,3):
            m.box('side_plates_'+str(side),-1,y,-3,2.5,2.6,6.5,'stone')
            m.box('side_plates_'+str(side),-.2,y+2.1,-3.4,1,1,1.5,'moss')
        for i in range(3):m.box('body',side*(4+i)-1,-3.5-i,-2+i*2,2,4.5,2,'edge')
    m.box('head',-5.6,-6,-5.5,11.2,11,10.8,'hide')
    for x in (-3.7,1.6):m.box('head',x,-2.3,-6.1,2.4,2.5,.8,'dark')
    m.box('head',-1.3,.2,-6.2,2.6,3.9,.9,'dark')
    for side in (-1,1):m.box('head',side*2.5-1.2,1.8,-6.2,2.4,3,.9,'dark')
    for x,z in [(-5,2),(-2,3),(2,3),(4,-1)]:m.box('head',x,-6.5,z,2,1,2,'moss')
    for side in (-1,1):
        for fore in (-1,1):
            name=f'foot_{side}_{fore}';m.bone(name,(side*4.5,15,fore*3.5),'leg_fl' if side<0 and fore<0 else 'leg_fr' if fore<0 else 'leg_hl' if side<0 else 'leg_hr')
            m.box(name,-3,0,-3.6,6,9,7.2,'hide')
            m.plates(name,-3.4,2,-4,3,2,2.3,3,1.2,'stone')
            m.box(name,-3.5,7,-4.3,7,2.2,8.6,'edge')
            for i in range(3):m.box(name,-2.8+i*2,8.8,-4.5,1.6,1.2,2,'stone')
    for i in range(9):m.box('body',-5+(i%4)*3,1+(i//4)*3,-4.8,1.1,1.8,.5,'moss')
    return m

def spider(identity='spider'):
    pal=[('carapace','#29272A','stone'),('edge','#555157','metal'),('black','#131219','void'),('red','#C52F35','fire'),
         ('fang','#DCD3AF','bone'),('silk','#CAC8BA','cloth'),('moss','#4B6F63','leaf')]
    if identity=='cave_spider':pal=[(n,{'carapace':'#16353C','edge':'#355B60','red':'#86CF58','silk':'#9CAC80'}.get(n,c),p) for n,c,p in pal]
    m=Mesh(identity,pal,'Eight complete articulated block legs, a low armored double abdomen, eight front eyes, squared ivory fangs and genuine overlapping carapace segments.')
    m.bone('body',(0,12,2),'body');m.box('body',-8,-5,-5,16,10,13,'carapace')
    m.box('body',-10,-6,6,20,12,17,'black');m.box('body',-8,-8,8,16,3,13,'carapace')
    for row in range(4):
        for col in range(5):m.box('body',-10+col*4,-6.5-(1 if row in (1,2) else 0),6+row*4,3.7,2,3.7,'edge')
    for side in (-1,1):
        for i in range(5):
            m.box('body',side*9.3-1,-3.5,7+i*3,2,5,2.4,'carapace')
            m.box('body',side*8.2-.7,-10+(i%2),8+i*3,1.4,5,1.4,'edge')
    m.bone('head',(0,11,-7),'head');m.box('head',-6,-4,-5,12,8,8,'carapace')
    for row in range(2):
        for col in range(4):m.box('head',-4.8+col*2.5,-2.7+row*3,-5.5,1.5,1.5,.9,'red')
    for side in (-1,1):
        m.box('head',side*4-1,1,-7,2.2,5,3,'fang');m.box('head',side*3.2-1,5,-8,2,2,3,'fang')
    for side in (-1,1):
        for idx in range(4):
            z=-3+idx*4;name=f'leg_{side}_{idx}'
            anim=('leg_fl','leg_fr','leg_hl','leg_hr')[(idx+(1 if side>0 else 0))%4]
            m.bone(name,(side*7,12,z),anim)
            m.box(name,0 if side>0 else -12,-1.5,-1.6,12,3,3.2,'carapace')
            for k in range(3):m.box(name,side*(2+k*3)-1.8,-2.3,-2,3.6,1.4,4,'edge')
            m.box(name,side*11-2,-2,-2,4,4,4,'edge')
            for k in range(3):
                m.box(name,side*(11+k*1.8)-1.6,1+k*3,-1.5,3.2,3.3,3,'carapace')
                m.box(name,side*(11+k*1.8)-2,2+k*3,-1.9,4,1.1,3.8,'edge')
            m.box(name,side*16-1.5,9,-3,3,2,5,'black')
    for i in range(7):m.box('body',-8+i*2.5,-8.3,8+(i%3)*3,.55,2.4,.55,'silk')
    if identity=='cave_spider':
        m.box('body',-5,-4,21,10,7,4,'red')
        for i in range(5):m.box('body',-4+i*2,3+(i%2),20,.8,3,.8,'red')
    return m

def enderman():
    pal=[('skin','#101018','void'),('edge','#282333','stone'),('obsidian','#221A35','void'),('purple','#9C54D2','glass'),
         ('eye','#E0A6ED','glass'),('dark','#09080F','void')]
    m=Mesh('enderman',pal,'Tall complete lanky figure with stepped obsidian cloak, three distinct floating crown fragments and purple eyes. Thin limbs remain readable.')
    m.bone('body',(0,-7,0),'body');m.bone('head',(0,-16,0),'head')
    m.box('body',-4,0,-2.5,8,18,5,'skin');m.box('body',-4.4,-1,-2.8,8.8,3,5.6,'edge')
    m.box('head',-4.8,-8,-4.8,9.6,9.5,9.6,'skin')
    for side in (-1,1):m.box('head',side*2.4-1.8,-3.5,-5.1,3.6,1.2,.6,'purple');m.box('head',side*2.4-.5,-3.5,-5.4,1,1.2,.5,'eye')
    for side in (-1,1):
        arm=f'arm_{side}';m.bone(arm,(side*5.8,-7,0),'arm_l' if side>0 else 'arm_r')
        m.box(arm,-1.4,0,-1.5,2.8,28,3,'skin');m.box(arm,-1.9,12,-1.9,3.8,3.8,3.8,'edge')
        m.box(arm,-2,27,-2.2,4,4,4.4,'skin')
        for j in range(3):m.box(arm,-1.7+j*1.2,30,-2.9,.9,3.2,1.1,'edge')
        leg=f'leg_{side}';m.bone(leg,(side*2.6,11,0),'leg_l' if side>0 else 'leg_r')
        m.box(leg,-1.4,0,-1.5,2.8,12,3,'skin');m.box(leg,-1.8,11.2,-3.5,3.6,1.8,5.2,'edge')
    m.bone('cloak',(0,-8,3.2),'tail')
    for col in range(7):
        length=20+((col*7)%5);x=-8+col*2.7
        for row in range(5):
            m.box('cloak',x+(.4 if row%2 else 0),row*length/5,1+row*.7,2.1,length/5+.5,1.3,'obsidian')
        m.box('cloak',x,4+(col%3)*3,.6,1.1,2.8,.7,'purple')
    for idx,(x,y,z) in enumerate([(-6,-31,-1),(4,-34,-2),(-1,-37,4)]):
        name='crown_'+str(idx);m.bone(name,(x,y,z),'orbit')
        m.box(name,-1.5,-1.5,-1.5,3,3,3,'obsidian');m.box(name,-.8,-1.8,-1.7,1.6,1,.6,'purple')
    for side in (-1,1):
        for i in range(5):m.box('body',side*4.3-.65,1+i*2.4,-3,1.3,1.8,1,'edge')
    return m

def slime():
    pal=[('gel','#6FCA54','glass'),('core','#72A84B','skin'),('inner','#B0EA71','glass'),('face','#225C2A','void'),
         ('stone','#7A8260','stone'),('moss','#3D793F','leaf'),('glow','#C2F68B','glass')]
    m=Mesh('slime',pal,'Three nested translucent cubes and an unmistakable slime face, with actual ruined corner piers and broken stepped stonework embedded in the gel.')
    m.bone('body',(0,13,0),'pulse');m.box('body',-10,-10,-10,20,20,20,'gel')
    m.box('body',-7,-7,-7,14,14,14,'inner');m.box('body',-4.5,-4.5,-4.5,9,9,9,'core')
    for x in (-6,2):m.box('body',x,-3,-10.3,3.4,3.8,.6,'face')
    m.box('body',-3,3,-10.4,6,2.4,.6,'face')
    for sx,sz in [(-1,-1),(1,1),(-1,1)]:
        x=sx*8;z=sz*8
        for row in range(5):
            m.box('body',x-2.2-(row%2)*.5,-13+row*4,z-2,4.5,3.7,4.5,'stone')
            m.box('body',x-2.5,-13+row*4,z-2.2,5.2,.7,5.1,'moss')
        for i in range(3):m.box('body',x-2+i*2,-16-(i%2)*2,z-1,1.7,4,2.5,'stone')
    for side in (-1,1):
        for i in range(6):m.box('body',-8+i*3,-11,side*8-1.2,2.7,2.2,2.4,'stone')
    for i in range(16):
        a=i*math.tau/16;name='drop_'+str(i);m.bone(name,(math.cos(a)*12,21+((i%3)-1),math.sin(a)*12),'float')
        m.box(name,-.7,-.7,-.7,1.4+(i%2)*.5,1.4+(i%2)*.5,1.4,'gel')
    for i in range(12):m.box('body',-8+(i%4)*4,-10.4+(i//4)*3,-10.2,.8,1.5,.5,'glow')
    return m

VILLAGER=[('skin','#8F9491','skin'),('shade','#58635D','skin'),('robe','#38303F','cloth'),('hem','#6C4B7C','cloth'),
          ('metal','#68777D','metal'),('wood','#6B4A32','wood'),('leather','#45322C','cloth'),('gold','#C4A34E','metal'),
          ('soul','#98CBC8','glass'),('red','#A54B4A','cloth'),('teeth','#D6CDB2','bone'),('dark','#1B2027','void'),
          ('glass','#9BC5BD','glass'),('potion','#9372BA','glass'),('ice','#91C5D9','ice'),('edge','#A9B4AE','metal')]

def villager_anatomy(identity,name):
    m=Mesh(identity,VILLAGER,name)
    m.bone('body',(0,0,0),'body');m.bone('head',(0,-2,-.5),'head')
    m.box('body',-5.7,0,-3.5,11.4,15,7,'robe');m.box('body',-6.7,11,-4.2,13.4,5,8.4,'robe')
    m.box('body',-6.9,14,-4.4,13.8,2,8.8,'hem')
    for side in (-1,1):
        leg=f'leg_{side}';m.bone(leg,(side*3,16,0),'leg_l' if side>0 else 'leg_r')
        m.box(leg,-2,0,-2.7,4,6,5.4,'leather');m.box(leg,-2.8,5.4,-4.5,5.6,2.6,7.5,'dark')
        arm=f'arm_{side}';m.bone(arm,(side*7.5,1,0),'arm_l' if side>0 else 'arm_r')
        m.box(arm,-2.4,0,-2.8,4.8,12,5.6,'robe');m.box(arm,-2.8,10.5,-3.2,5.6,2.2,6.4,'hem')
        m.box(arm,-2,12,-2.4,4,3.5,4.8,'skin')
    head_face(m,nose=True,eyes='dark')
    m.box('head',-4.4,-3.4,-5.2,8.8,.9,.7,'shade')
    for side in (-1,1):m.box('head',side*4.8-.7,-2,-1.5,1.4,3,2,'skin')
    m.box('body',-5.9,8,-4,11.8,2,1,'leather');m.box('body',-1.5,8,-4.6,3,2.2,.8,'gold')
    for y in (2,5):m.box('body',-.65,y,-4,.9,1.2,.5,'gold')
    return m

def witch():
    m=villager_anatomy('witch','A full layered violet witch robe, monumental stepped bent hat and detailed wearable alchemy rack with three different potion vessels.')
    # Hat is a sculpted folded silhouette, not a flat brim/cube cap.
    m.box('head',-8,-6.6,-7.5,16,1.8,15,'robe');m.box('head',-6,-9,-5.4,12,3,10.8,'hem')
    for i,(x,z,w,h,d) in enumerate([(0,0,9,4,8),(1,0,7,4,6),(2,-.4,5,3,4),(3.3,-.4,3,3,3)]):
        m.box('head',x-w/2,-12-i*3,z-d/2,w,h,d,'robe')
    m.box('head',3,-23,-2,5,2,3,'hem');m.box('head',-1,-9.5,-6.2,2.5,2.5,1,'gold')
    for i in range(8):m.box('body',-7+i*2,2,-4.3,1.4,13+(i%2)*1.2,1,'hem')
    m.bone('rack',(0,2,5),'none')
    for x in (-6,5):m.box('rack',x,-1,-1,1.4,13,2,'wood')
    for y in (0,6,12):m.box('rack',-6.2,y,-1.2,13.4,1.2,2.4,'wood')
    for i in range(3):
        x=-4+i*4
        m.box('rack',x-1.4,3-i%2,0,2.8,5+i%2,3,'glass');m.box('rack',x-.8,1-i%2,.5,1.6,2,2,'glass')
        m.box('rack',x-.9,.5-i%2,.3,1.8,.8,2.4,'wood');m.box('rack',x-1,5-i%2,-.2,2,2.5,3.2,'potion' if i%2==0 else 'soul')
    for side in (-1,1):
        for i in range(4):m.box('arm_'+str(side),-2.7+i*1.3,7,-3.4,1,3.5,.8,'gold')
    return m

def illager(identity):
    m=villager_anatomy(identity,{'pillager':'Heavy wood/iron siege archer with a full mechanical crossbow and a short red battle standard.',
                              'vindicator':'Blue-coated executioner with asymmetric iron pauldrons and a giant chamfered double-edged axe.',
                              'evoker':'Black/gold summoner with structured collar, flared sleeves and three floating fang sigil panels.'}[identity])
    if identity=='pillager':
        for side in (-1,1):
            m.plates('arm_'+str(side),-3,-1,-3.5,3,2,2,2,1,'metal')
            m.box('body',side*4-1,0,-4,2,8,1,'leather')
        m.bone('crossbow',(0,7,-8),'none')
        m.box('crossbow',-2,-1,-7,4,3,13,'wood');m.box('crossbow',-1,2,-2,2,5,3,'wood')
        for side in (-1,1):
            for i in range(4):m.box('crossbow',side*(3+i*2)-1.2,-1.5,-2+i*.7,2.4,2.5,2.2,'metal')
        for x in range(-9,10,2):m.box('crossbow',x,-.2,1.8,1.8,.45,.5,'leather')
        m.box('crossbow',-.4,-2,-9,.8,.8,16,'edge');m.box('crossbow',-.8,-2.2,-10,1.6,1.2,2,'metal')
        m.bone('standard',(4,-2,4),'tail');m.box('standard',-.6,-9,-.6,1.2,23,1.2,'wood')
        for i in range(5):m.box('standard',1,-9+i*2,.1,8-(i%2)*1.5,1.8,.7,'red')
        m.box('standard',3,-6,-.3,1.3,4,.6,'gold')
    elif identity=='vindicator':
        for row in range(4):
            m.box('arm_1',-4,-3+row*1.5,-4.5,8,1.7,9,'metal')
            m.box('arm_1',-4.5,-3.4+row*1.5,-4.8,9,.6,9.6,'edge')
        m.bone('great_axe',(0,14,-2),'none','arm_-1');m.box('great_axe',-.8,-20,-.8,1.6,28,1.6,'wood')
        for side in (-1,1):
            for row in range(5):
                w=4+min(row,4-row)*1.2;m.box('great_axe',0 if side>0 else -w,-21+row*2,-1.4,w,2.1,2.8,'metal')
                m.box('great_axe',side*w-.5,-21+row*2,-1.6,1,2.2,3.2,'edge')
        m.box('great_axe',-1.2,-22,-1.8,2.4,12,3.6,'gold')
        for i in range(6):m.box('body',-5+i*2,2,-4.5,1.4,9,.7,'hem')
    else:
        m.box('body',-7,-3,-4.5,14,3.5,9,'gold');m.box('body',-6,-4,2.5,12,6,3,'robe')
        for side in (-1,1):
            m.box('arm_'+str(side),-3.5,4,-3.4,7,9,6.8,'robe')
            for i in range(5):m.box('arm_'+str(side),-3.3+i*1.4,12,-3.8,1,2,7.6,'gold')
        for i in range(7):m.box('body',-6+i*2,1,-4.8,.9,13,.6,'gold')
        for i in range(3):
            n='sigil_'+str(i);m.bone(n,(-11+i*11,-9-(i%2)*4,5),'orbit')
            m.box(n,-2.5,-4,-.5,5,8,1,'metal')
            for x in (-1.7,.5):m.box(n,x,-2,-1,1.2,5,.7,'teeth')
            m.box(n,-2,1,-1.1,4,1,.5,'soul')
    return m

def vex():
    pal=[('spirit','#C9D8DE','glass'),('bone','#EFF4E7','bone'),('shadow','#66768C','cloth'),('blue','#71CBE2','glass'),('dark','#35475F','void')]
    m=Mesh('vex',pal,'Pale floating revenant, riblike torso, ragged rectangular wings composed of individually separated torn feather-plates and paired spectral arm blades.')
    m.bone('body',(0,9,0),'float');m.box('body',-3,-3,-2,6,9,4,'spirit')
    m.bone('head',(0,3,-.2),'head');m.box('head',-3.5,-4,-3.2,7,7,6.4,'spirit')
    for side in (-1,1):m.box('head',side*1.8-.9,-1.5,-3.5,1.8,1,.5,'dark')
    for i in range(4):m.box('body',-3.3,-1+i*1.7,-2.4,6.6,.7,.8,'bone')
    for side in (-1,1):
        arm='arm_'+str(side);m.bone(arm,(side*4,6,0),'arm_l' if side>0 else 'arm_r')
        m.box(arm,-1,0,-1.1,2,9,2.2,'spirit');m.box(arm,side*1.1-.6,2,-2,.8,11,2,'blue')
        m.box(arm,-1.2,8,-1.5,2.4,2.4,3,'bone')
        wing='wing_'+str(side);m.bone(wing,(side*2.5,6,2),'wing_l' if side<0 else 'wing_r')
        for row in range(6):
            for col in range(4):
                x=side*(3+col*2.2);y=row*2.2+col*.5
                if not(row>3 and col%2==1):m.box(wing,x-1,-5+y,-.4,1.7,3+(col%2),.8,'spirit')
        for i in range(7):m.box(wing,side*(3+i*1.6)-.5,-5+i*.7,-.8,1,2,1.5,'blue')
        leg='tatter_'+str(side);m.bone(leg,(side*1.8,14,0),'tail');m.box(leg,-1,0,-1.1,2,6,2.2,'shadow')
    return m

BOAR=[('hide','#95725F','skin'),('dark','#624D43','skin'),('armor','#5C5550','stone'),('edge','#8D8A7B','metal'),
      ('fang','#E5D9AD','bone'),('moss','#A34C44','leaf'),('red','#A44644','cloth'),('wood','#554033','wood'),
      ('metal','#4A575C','metal'),('glow','#DC7756','fire'),('black','#232A2B','void')]

def quadruped_war(identity):
    pal=list(BOAR)
    if identity=='zoglin':pal=[(n,{'hide':'#92967B','moss':'#828D63','glow':'#9DBB62','fang':'#CFD2BB'}.get(n,c),p) for n,c,p in pal]
    m=Mesh(identity,pal,{'ravager':'Broad-nosed ironwood siege beast with layered forehead ram, giant bent horns, four armored hooves and back-standard frame.',
                        'hoglin':'Crimson forest great boar with layered fungus armor, stiff ridge bristles and enormous squared shovel tusks.',
                        'zoglin':'Exposed bone-ridged undead boar with decomposed hide panels, asymmetrical broken tusk and plague-green fractures.'}[identity])
    m.bone('body',(0,9,3),'body');m.box('body',-9,-7,-12,18,14,25,'hide')
    m.box('body',-7,-9,-8,14,3,18,'dark')
    m.bone('head',(0,8,-13),'head');m.box('head',-8,-6,-9,16,12,12,'hide')
    m.box('head',-6,-1,-13,12,6,5,'dark')
    for x in (-4.5,2.5):m.box('head',x,1,-13.4,2,1.8,.7,'black')
    for side in (-1,1):
        m.box('head',side*6-1.5,-3.6,-9.5,3,1.8,.7,'black')
        m.box('head',side*8-1,-5,0,2,6,4,'dark')
        leg='leg_'+str(side)+'_';
        for front in (-1,1):
            n=leg+str(front);m.bone(n,(side*6.8,15,front*9),'leg_fl' if side<0 and front<0 else 'leg_fr' if front<0 else 'leg_hl' if side<0 else 'leg_hr')
            m.box(n,-2.8,0,-3,5.6,7,6,'hide');m.box(n,-3.5,6,-4,7,3,8,'dark')
            m.plates(n,-3.6,3,-4.4,3,2,2.4,2.5,.9,'armor')
    if identity=='ravager':
        for side in (-1,1):
            for i in range(4):m.box('head',side*(7+i*.9)-1,-8-i*1.8,-3+i*.8,2.3,3,2.6,'fang')
            m.plates('body',side*8-1,-5,-8,1,4,2.4,3,17,'wood')
        m.plates('head',-8,-7,-10,4,3,4,3,1.4,'metal')
        m.box('head',-8.8,-1,-11.3,17.6,2.2,2,'edge')
        for x in (-6,0,6):m.box('head',x-.7,-5,-11,1.4,6,.8,'edge')
        m.bone('standard',(0,-1,6),'tail')
        for x in (-6,6):m.box('standard',x-.6,-10,-.6,1.2,19,1.2,'wood')
        for y in (-10,-3):m.box('standard',-6.5,y,-.6,13,1.2,1.2,'wood')
        for i in range(5):m.box('standard',-5+i*2.2,-9,.1,1.8,9+(i%2)*2,.7,'red')
    else:
        for side in (-1,1):
            for i in range(5):
                x=side*(6+i*.7);z=-10-i*.9;y=2-i*1.4
                if identity=='zoglin' and side<0 and i>2:continue
                m.box('head',x-1,y,z-1,2.2,2.6,2.2,'fang')
        for i in range(9):
            z=-9+i*2.5
            m.box('body',-1.2,-13+(i%2),z,2.4,5,1.4,'fang' if identity=='zoglin' else 'dark')
            if identity=='hoglin':
                m.box('body',-7,-10,z,14,2,2,'moss');m.box('body',-6,-12+(i%2),z,12,2.2,1.8,'armor')
        if identity=='hoglin':
            for i in range(7):
                m.box('body',-7+(i%3)*6,-11, -6+(i//3)*8,2,3,2,'wood')
                m.box('body',-8+(i%3)*6,-12,-7+(i//3)*8,4,1.4,4,'moss')
        else:
            for side in (-1,1):
                for i in range(5):m.box('body',side*8-.6,-4,-8+i*4,1.4,8,1,'fang')
            for i in range(6):m.box('body',-5+i*2,-2+(i%2),-13,1,6,.6,'glow')
    return m

def phantom():
    pal=[('back','#263C5E','skin'),('membrane','#52718F','cloth'),('bone','#ADBFC4','bone'),('glow','#7AD7D8','glass'),('eye','#B2E480','glass'),('dark','#142735','void')]
    m=Mesh('phantom',pal,'Full manta-like skeletal night flyer with large ragged squared wings, moonwhite ribs and a triple-stepped articulated tail.')
    m.bone('body',(0,10,0),'float');m.box('body',-4,-3,-8,8,6,16,'back')
    m.bone('head',(0,9,-9),'head');m.box('head',-4,-2,-5,8,4,6,'back')
    for side in (-1,1):m.box('head',side*2.3-.9,-1.2,-5.4,1.8,1.4,.6,'eye')
    for i in range(7):
        m.box('body',-3.8,-3.4,-6+i*2,7.6,.8,1,'bone')
        m.box('body',-.6,-4.3,-5+i*2,1.2,1.4,1.2,'glow')
    for side in (-1,1):
        wing='wing_'+str(side);m.bone(wing,(side*3,10,-3),'wing_l' if side<0 else 'wing_r')
        for col in range(9):
            x=side*(1+col*2.4)
            for row in range(3):
                length=8+col*.8-row
                m.box(wing,x-1,-1+row*.5,col*.65+row*length/3,2.1,.8,length/3+.3,'membrane' if row else 'back')
            m.box(wing,x-1,-1.8,col*.65,2.2,1,1.3,'bone')
        for i in range(8):m.box(wing,side*(4+i*2.1)-.5,-1.5,8+i*.5,.9,.9,3+(i%2)*2,'glow')
    m.bone('tail',(0,10,8),'tail')
    for i in range(8):m.box('tail',-1.5+i*.1,0,i*2,3-i*.2,1.8,2.5,'back')
    for side in (-1,1):
        for i in range(3):m.box('tail',side*(1+i)-.7,-.3,10+i*2,1.4,1.4,4,'bone')
    return m

def breeze():
    pal=[('stone','#303E4F','stone'),('edge','#617E8D','metal'),('wind','#B8E2E5','glass'),('light','#E5F3DE','glass'),('dark','#142736','void'),('eye','#A5E0D7','glass')]
    m=Mesh('breeze',pal,'A floating dark windhead surrounded by three individually segmented square cyclone rings and rising white wind ribbons; no solid humanoid torso.')
    m.bone('head',(0,3,0),'head');m.box('head',-4,-4,-4,8,8,8,'stone')
    m.box('head',-4.5,-2.5,-4.4,9,1,1,'edge')
    for side in (-1,1):m.box('head',side*2-.8,-.8,-4.6,1.6,1.1,.7,'eye')
    for idx,(y,r) in enumerate([(10,6),(16,8),(22,5)]):
        n='ring_'+str(idx);m.bone(n,(0,y,0),'orbit',rotation=(0,idx*22,0))
        for side in (-1,1):
            for i in range(5):
                t=-r+i*2*r/5
                m.box(n,t,-.8,side*r-.7,2*r/5-.25,1.6,1.4,'wind')
                m.box(n,side*r-.7,-.8,t,1.4,1.6,2*r/5-.25,'edge' if i%2 else 'wind')
        for j in range(4):m.box(n,(-1 if j<2 else 1)*(r-1),-2,j%2*2*r-r,2,2,2,'stone')
    m.bone('updraft',(0,12,0),'pulse')
    for side in (-1,1):
        for i in range(7):
            m.box('updraft',side*(2+i*.7)-.5,-8+i*2,-3+i*.5,1,2.5,1.1,'light')
            m.box('updraft',side*(1+i*.6)-.5,-7+i*2,3-i*.4,1,2.5,1,'wind')
    return m

def creaking():
    pal=[('bark','#ACA995','wood'),('dark','#625D50','wood'),('pale','#D0CFB9','wood'),('heart','#E08A39','fire'),
         ('eye','#F6B34B','glass'),('moss','#9C9F82','leaf'),('void','#403F35','void')]
    m=Mesh('creaking',pal,'Twisted pale-oak entity, unequal rooted legs, branching colossal left arm, knotty bark plates and an exposed amber heart. No smooth human armor.')
    m.bone('body',(0,0,0),'body');m.box('body',-4,-2,-3,8,15,6,'dark')
    for i in range(7):m.box('body',-4.5+(i%3)*2.5,-3+i*2, -3.5+(i%2)*.5,3.3,4.5,7,'bark')
    m.box('body',-1.5,2,-4.3,3,5,1.4,'heart');m.box('body',-.6,3,-5,1.2,3,.8,'eye')
    for side in (-1,1):
        for row in range(5):m.box('body',side*3.4-.65,row*2,-4,1.3,1.5,1.4,'pale')
        leg='leg_'+str(side);m.bone(leg,(side*2.8,13,0),'leg_l' if side>0 else 'leg_r')
        for i in range(5):m.box(leg,-1.6+(i%2)*.5,i*2,-1.7,3.2,2.7,3.4,'bark')
        for i in range(3):m.box(leg,-3+i*2,9,-4+(i%2),1.7,1.6,5,'dark')
    m.bone('head',(.8,-5,-.3),'head');m.box('head',-3.8,-4.5,-3.8,7.6,9,7.6,'bark')
    for x in (-2.8,1):m.box('head',x,-1.8,-4.2,1.8,1,.7,'eye')
    m.box('head',-.7,.5,-4.4,1.4,2,.8,'void')
    for i in range(5):m.box('head',-4+i*2,-5.2+(i%2),-4,1.7,2.2,8,'pale')
    for side in (-1,1):
        arm='arm_'+str(side);m.bone(arm,(side*6,-1,0),'arm_l' if side>0 else 'arm_r')
        length=19 if side<0 else 14
        for i in range(5):m.box(arm,-2.2+(i%2)*.4,i*length/5,-2.2,4.4,length/5+1,4.4,'bark')
        for finger in range(3):m.box(arm,-3.2+finger*2.2,length-.3,-3.3,1.7,5+(finger%2)*2,1.8,'dark')
        for j in range(3):
            m.box(arm,side*(1+j*1.4)-.8,-3-j*2,0,1.6,5,1.8,'dark')
            m.box(arm,side*(2+j*1.4)-.6,-6-j*2,-.3,1.2,3,1.4,'pale')
        for j in range(5):m.box(arm,-2.5+(j%3)*1.5,3+j*2,2,1.3,3.5,.7,'moss')
    return m

def warden():
    pal=[('skulk','#193D42','skin'),('dark','#12282E','void'),('plates','#29515A','stone'),('bone','#B8D0BE','bone'),
         ('soul','#63D1C6','glass'),('horn','#418D8F','skin'),('root','#365755','leaf')]
    m=Mesh('warden',pal,'Massive eyeless deep-dark guardian, a layered living ribcage revealing three imprisoned soul lights, bifurcated sensor horns and heavy root-encrusted limbs.')
    m.bone('body',(0,-1,0),'body');m.box('body',-9,0,-6,18,17,12,'skulk')
    m.box('body',-6,1,-6.5,12,12,1,'dark')
    for row in range(5):
        for side in (-1,1):m.box('body',side*4.3-2.4,1+row*2.2,-7,4.8,1.1,1.4,'bone')
    for i,(x,y) in enumerate([(-2.8,3),(1,5),(-1,8)]):
        m.box('body',x,y,-7.8,2.3,2.7,1.1,'soul');m.box('body',x+.5,y-.8,-8,.9,1,.5,'bone')
    m.bone('head',(0,-7,-1),'head');m.box('head',-7,-5,-5,14,10,10,'skulk')
    m.box('head',-5,1,-6,10,3,2,'dark')
    for i in range(5):m.box('head',-5+i*2,-5.8,-4.5,1.8,1.5,9,'plates')
    for side in (-1,1):
        horn='sensor_'+str(side);m.bone(horn,(side*6.5,-7,0),'tentacle','head')
        for j in range(4):m.box(horn,side*j*1.3-1,-j*2.5,-1,2,3.2,2,'horn')
        for j in range(3):m.box(horn,side*(j+1)*1.7-1,-5-j*1.9,1,1.5,3,1.5,'soul')
        arm='arm_'+str(side);m.bone(arm,(side*11,0,0),'arm_l' if side>0 else 'arm_r')
        m.box(arm,-4,-2,-4.8,8,13,9.6,'skulk');m.box(arm,-4.5,10,-5.3,9,8,10.6,'plates')
        m.plates(arm,-4.5,0,-5.3,3,3,3,3.2,.9,'plates')
        for j in range(4):m.box(arm,-4+j*2,16,-5.8,1.6,4,2,'bone')
        leg='leg_'+str(side);m.bone(leg,(side*5.2,16,0),'leg_l' if side>0 else 'leg_r')
        m.box(leg,-3.4,0,-4,6.8,6,8,'skulk');m.box(leg,-4,5,-5.4,8,3,10.8,'plates')
        for j in range(4):m.box(leg,-3.5+j*2,6.5,-5.8,1.4,1.6,2,'bone')
    for i in range(12):m.box('body',-10+(i%6)*4,10+(i//6)*3,5.8,1.3,6-(i%3),1.2,'root')
    for i in range(8):m.box('body',-8+i*2.2,-4+(i%3)*.5,3,1.8,5,4,'plates')
    return m

def blaze():
    pal=[('coal','#342D27','stone'),('gold','#E7AE39','metal'),('ember','#FF8E25','fire'),('core','#FFDA65','glass'),('black','#171A1D','void'),('bronze','#AF6C2C','metal')]
    m=Mesh('blaze',pal,'Complete suspended furnace core with three staggered rings of actual segmented gold blaze rods, a four-pillar furnace crown and exposed ember channels.')
    m.bone('head',(0,5,0),'head');m.box('head',-4,-4,-4,8,8,8,'coal')
    for side in (-1,1):m.box('head',side*2.2-.9,-1.5,-4.4,1.8,1.3,.7,'core')
    m.box('head',-2,1,-4.5,4,1.1,.7,'black');m.box('head',-1,-4.6,-1,2,1.2,2,'ember')
    m.bone('core',(0,13,0),'pulse');m.box('core',-3,-4,-3,6,8,6,'ember');m.box('core',-1.5,-3,-3.5,3,6,1,'core')
    for level,(y,r,count) in enumerate([(5,8,5),(13,10,6),(21,7,5)]):
        n='rod_ring_'+str(level);m.bone(n,(0,y,0),'orbit',rotation=(0,level*23,0))
        for i in range(count):
            a=math.tau*i/count;x=math.cos(a)*r;z=math.sin(a)*r
            m.box(n,x-1.1,-4,z-1.1,2.2,8,2.2,'gold')
            for k in (-3,0,3):m.box(n,x-1.4,k-.4,z-1.4,2.8,.8,2.8,'bronze')
            m.box(n,x-.5,-3.6,z-1.5,1,7.2,.5,'core')
    for x,z in [(-3,-3),(-3,3),(3,-3),(3,3)]:
        m.box('head',x-.8,-9,z-.8,1.6,5,1.6,'gold');m.box('head',x-1,-9.5,z-1,2,1,2,'coal')
    return m

def ghast():
    pal=[('white','#DEDECF','skin'),('shade','#B7B7B5','skin'),('black','#3C3D45','void'),('tear','#C2555F','fire'),
         ('stone','#3D3C48','stone'),('edge','#625A6E','stone'),('moss','#717963','leaf'),('core','#FFAD6B','glass')]
    m=Mesh('ghast',pal,'White floating fortress with nine articulated tentacles, crying rectangular face, a burning mouth and broken obsidian towers rooted into its upper corners.')
    m.bone('body',(0,-3,0),'float');m.box('body',-14,-12,-14,28,26,28,'white')
    m.box('body',-14.2,9,-14.2,28.4,5,28.4,'shade')
    for side in (-1,1):
        m.box('body',side*6-2.5,-2,-14.4,5,1.6,.8,'black')
        for i in range(3):m.box('body',side*5.8-.8,-.3+i*2.2,-14.5,1.6,1.8,.8,'tear')
    m.box('body',-3.8,4,-14.6,7.6,6,.9,'black');m.box('body',-2.3,6,-15,4.6,3.2,.8,'core')
    for side in (-1,1):m.box('body',side*4-.7,4,-14.9,1.4,6.5,1,'shade')
    for row in range(3):
        for col in range(3):
            n=f'tentacle_{row}_{col}';m.bone(n,(-9+col*9,11,-9+row*9),'tentacle')
            for k in range(6):
                w=3.4-k*.28;m.box(n,-w/2+(k%2)*.4,k*2.4,-w/2,w,2.7,w,'white' if k%2==0 else 'shade')
            m.box(n,-1.8,0,-1.8,3.6,1.1,3.6,'black')
    for sx,sz in [(-1,-1),(-1,1),(1,1),(1,-1)]:
        x=sx*10;z=sz*10
        for tier in range(4):
            m.box('body',x-3,-15-tier*3,z-3,6,2.7,6,'stone')
            m.box('body',x-3.3,-15.5-tier*3,z-3.3,6.6,.7,6.6,'edge')
        for dx,dz in [(-2,-2),(2,-2),(-2,2),(2,2)]:m.box('body',x+dx-.8,-28+(dx==dz),z+dz-.8,1.6,3,1.6,'stone')
        m.moss('body',x-2,-13,z-3.5,4)
    for i in range(7):m.box('body',-10+i*3.2,-14,10,2.8,2,4,'stone')
    return m

def magma():
    pal=[('crust','#322E2C','stone'),('edge','#58433B','stone'),('lava','#E76F22','fire'),('core','#FFB942','glass'),('dark','#1E2024','void')]
    m=Mesh('magma_cube',pal,'Seven stacked volcanic plate tiers separated by bright lava seams, a stepped crater rim and visible inner furnace. Every slab is separate for squash/expansion animation.')
    m.bone('core',(0,12,0),'pulse');m.box('core',-7,-8,-7,14,16,14,'lava')
    for layer in range(7):
        n='slab_'+str(layer);m.bone(n,(0,3+layer*3,0),'pulse')
        width=20 if layer in (0,6) else 22
        m.box(n,-width/2,-1,-width/2,width,2,width,'crust')
        for side in (-1,1):
            for k in range(4):
                m.box(n,-10+k*5,.8,side*10-1.2,4.6,.8,2.4,'lava')
                m.box(n,side*10-1.2,.8,-10+k*5,2.4,.8,4.6,'lava')
        if layer in (0,6):
            for side in (-1,1):
                for k in range(4):m.box(n,-10+k*5,-2.5,side*9-1.4,4.6,2,2.8,'edge')
    for x in (-6,2):m.box('core',x,-2,-8,3.4,3.4,1,'dark')
    m.box('core',-3,3,-8.3,6,2,1,'core')
    return m

PIGLIN=[('skin','#BC8C78','skin'),('darkskin','#87634F','skin'),('gold','#DBAE54','metal'),('edge','#F3CC75','metal'),
        ('black','#25262B','stone'),('red','#9C4D43','cloth'),('leather','#694936','cloth'),('bone','#D9CBAD','bone'),
        ('eye','#3A3230','void'),('green','#82AB65','fire'),('iron','#716C66','metal')]

def piglin(identity):
    pal=list(PIGLIN)
    if identity=='zombified_piglin':pal=[(n,{'skin':'#85926B','darkskin':'#626D52','gold':'#AF9656','red':'#885B51'}.get(n,c),p) for n,c,p in pal]
    m=Mesh(identity,pal,{'piglin':'Golden tusked clan warlord with asymmetric trophy armor, layered red war skirt and a forged gold blade.',
                        'piglin_brute':'Heavy blackstone/gold axe sentinel with a fortress-shaped backpack shield and segmented arm plates.',
                        'zombified_piglin':'Half-exposed ivory skull and rib bones, broken tarnished gold armor, red fungus infections and cracked sword.'}[identity])
    m.bone('body',(0,0,0),'body');m.box('body',-5.5,0,-3.6,11,13,7.2,'skin')
    m.bone('head',(0,-3,-1),'head');m.box('head',-4.8,-5,-4.4,9.6,9,8.8,'skin')
    m.box('head',-3.3,-.6,-6.8,6.6,3.7,3,'darkskin')
    for x in (-2.2,.9):m.box('head',x,.5,-7.1,1.3,1.1,.6,'eye')
    for side in (-1,1):
        m.box('head',side*5.8-1,-3,0,2,5,3,'skin')
        m.box('head',side*3.8-.7,.8,-7,1.4,3.7,1.8,'bone')
        m.box('head',side*2.7-.7,-2.1,-4.8,1.4,1.4,.7,'eye')
        n='leg_'+str(side);m.bone(n,(side*2.8,14,0),'leg_l' if side>0 else 'leg_r')
        m.box(n,-2.3,0,-2.7,4.6,8,5.4,'leather');m.box(n,-2.8,7,-4,5.6,3,7,'black')
        m.box(n,-2.8,5,-3,5.6,2.5,6,'gold')
        n='arm_'+str(side);m.bone(n,(side*7.4,1,0),'arm_l' if side>0 else 'arm_r')
        m.box(n,-2.4,-1,-2.8,4.8,14,5.6,'skin');m.box(n,-2.7,10,-3.1,5.4,3.5,6.2,'gold')
        for j in range(3):m.box(n,-2.5+j*1.8,13,-3.5,1.4,2.2,2,'darkskin')
    for i in range(7):m.box('body',-6+i*2,10,-4.6,1.7,6+(i%2),1.3,'red')
    m.box('body',-6,9,-4.8,12,1.6,9.6,'leather');m.box('body',-1.4,9,-5.3,2.8,2,.8,'edge')
    if identity=='piglin':
        m.plates('body',-5.3,.5,-4.1,3,3,3.5,2.8,1,'gold')
        for side in (-1,1):
            for i in range(3):m.box('arm_'+str(side),-3.5,-3+i*1.2,-4,7,1.5,8,'gold' if side>0 else 'black')
        sword(m,'arm_-1','gold','edge','green')
        for i in range(5):m.box('head',-4.5+i*2.2,-6,-3.5,1.8,1.5,2.4,'gold')
    elif identity=='piglin_brute':
        for side in (-1,1):
            m.plates('arm_'+str(side),-3.5,-2,-4.3,3,4,2.4,3,1.2,'black')
            for y in (0,7):m.box('arm_'+str(side),-3.8,y,-4.5,7.6,1,9,'edge')
        m.plates('body',-5.5,0,-4.8,3,4,3.8,3,1.4,'black');m.box('body',-.7,.5,-6,1.4,11,1,'edge')
        m.box('body',-8,-2,4,16,19,3,'black')
        for i in range(4):m.box('body',-8+i*4,-5,4,2.7,4,3,'gold')
        m.bone('axe',(0,14,-2),'none','arm_-1');m.box('axe',-.7,-17,-.7,1.4,24,1.4,'leather')
        for row in range(5):
            m.box('axe',-6-row*.5,-18+row*2,-1.5,8+row*.5,2.2,3,'black')
            m.box('axe',-6.7-row*.5,-18+row*2,-1.8,1.2,2.2,3.6,'edge')
    else:
        m.box('head',-4.9,-4.6,-4.7,4.5,7.5,1.3,'bone')
        m.box('head',-3.7,-2.5,-5,2.3,2,.7,'eye')
        for i in range(5):m.box('body',-4.7,1+i*2.1,-4.2,5.5,1,1.4,'bone')
        for i in range(6):m.box('body',-4.5+i*1.8,2+(i%3)*2,-4.8,1.4,1.5,.9,'green')
        m.plates('arm_1',-3.2,-1,-3.5,3,2,2.2,2.4,1,'gold')
        sword(m,'arm_-1','gold','bone','green')
    return m

def insects(identity):
    pal=[('shell','#8B9699','stone'),('plate','#BBC1B9','metal'),('dark','#3F4B51','void'),('jaw','#D7D7C3','bone'),('glow','#A389D3','glass')]
    if identity=='endermite':pal=[(n,{'shell':'#5B3C73','plate':'#8760A1','dark':'#27223B','jaw':'#AAA3BD'}.get(n,c),p) for n,c,p in pal]
    m=Mesh(identity,pal,'Full multisegment stone-borer with paired hooked legs, shielded spine segments and two squared excavation mandibles; void variant carries obsidian crystals.')
    m.bone('body',(0,18,0),'body')
    for segment in range(7):
        width=5+min(segment,6-segment)*1.7;n='segment_'+str(segment)
        m.bone(n,(0,0,-12+segment*4),'tail','body')
        m.box(n,-width/2,-3,-2,width,5.5,4.2,'shell');m.box(n,-width/2-.4,-4,-1.8,width+.8,1.6,3.8,'plate')
        for side in (-1,1):
            m.box(n,side*(width/2)-.7,-1,-1,1.4,2,2,'plate')
            m.box(n,side*(width/2+1.3)-1.4,1,-.7,2.8,1.4,1.4,'shell')
            m.box(n,side*(width/2+2.4)-.7,2,-.6,1.4,3.5,1.2,'dark')
        if identity=='endermite':m.box(n,-1,-7+(segment%2),-.7,2,4,1.4,'glow')
    m.bone('head',(0,17,-15),'head');m.box('head',-4,-3,-4,8,6,5,'shell')
    for side in (-1,1):
        m.box('head',side*2.3-.7,-1.5,-4.3,1.4,1.1,.6,'dark')
        m.box('head',side*3-.7,1,-7,1.4,2,4,'jaw');m.box('head',side*2-.8,2,-8,1.6,1.4,2.5,'jaw')
    return m

def shulker():
    pal=[('shell','#77548C','stone'),('edge','#AE8BB9','stone'),('dark','#42394D','void'),('seal','#D7B978','metal'),
         ('inside','#DAD4A1','skin'),('crystal','#B0A0D9','glass'),('eye','#342F39','void')]
    m=Mesh('shulker',pal,'An articulated two-piece stepped purple reliquary shell, chamfered corner blocks, golden geometric seals and a separate pale cuboid face/crystal suspended inside.')
    m.bone('lower_shell',(0,15,0),'body');m.box('lower_shell',-10,-2,-10,20,9,20,'shell')
    m.box('lower_shell',-10.8,5,-10.8,21.6,2.3,21.6,'edge')
    m.bone('upper_shell',(0,8,0),'jaw');m.box('upper_shell',-10,-7,-10,20,7,20,'shell')
    m.box('upper_shell',-10.8,-7.8,-10.8,21.6,1.8,21.6,'edge')
    for n in ('upper_shell','lower_shell'):
        for side in (-1,1):
            for col in range(5):
                for row in range(2):
                    y=(-6 if n=='upper_shell' else -1)+row*3
                    m.box(n,-10+col*4,y,side*10-.6,3.6,2.6,1.2,'edge')
                    m.box(n,side*10-.6,y,-10+col*4,1.2,2.6,3.6,'edge')
            for i in range(4):m.box(n,side*8-.6,-5 if n=='upper_shell' else -1,-8+i*5,1.2,5,1.3,'seal')
    m.bone('head',(0,13,-1),'head');m.box('head',-4,-3,-4,8,6,8,'inside')
    for side in (-1,1):m.box('head',side*2-.7,-1,-4.4,1.4,1.4,.7,'eye')
    m.box('head',-1.4,2.2,-4.4,2.8,.7,.6,'eye')
    m.bone('crystal',(0,12,4),'pulse');m.box('crystal',-2,-3,-1,4,6,3,'crystal')
    return m

def all_models():
    result=[]
    for identity in ('zombie','husk','zombie_villager'):result.append(zombie(identity))
    for identity in ('skeleton','stray','bogged','wither_skeleton'):result.append(skeleton(identity))
    result += [creeper(),spider(),spider('cave_spider'),enderman(),slime(),witch()]
    for identity in ('pillager','vindicator','evoker'):result.append(illager(identity))
    result += [vex(),quadruped_war('ravager'),phantom(),breeze(),creaking(),warden(),blaze(),ghast(),magma()]
    for identity in ('piglin','piglin_brute','zombified_piglin'):result.append(piglin(identity))
    result += [quadruped_war('hoglin'),quadruped_war('zoglin'),insects('silverfish'),insects('endermite'),shulker()]
    return result

if __name__=='__main__':
    models=all_models()
    expected={p['entity'] for p in json.loads((ROOT/'src/main/resources/boss_profiles.json').read_text()) if p['attitude']=='hostile' or p['entity'] in ('piglin','zombified_piglin')}
    assert {m.d['id'] for m in models}==expected
    for m in models:
        d=m.save()
        assert len(d['palette'])<=16
        assert all(all(x>0 for x in b['size']) for b in d['boxes'])
        assert {b['bone'] for b in d['boxes']} <= {b['name'] for b in d['bones']}
        print(f"{d['id']}: {len(d['bones'])} bones, {len(d['boxes'])} authored cuboids")
    print(f'Saved {len(models)} full hostile meshes, {sum(len(m.d["boxes"]) for m in models)} cuboids total.')
