#!/usr/bin/env python3
"""Audit replacement anatomy and useful, modeled loot. This is not a visual-quality certification."""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import struct
import sys
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RES = ROOT / "src/main/resources"
HEROES = {"cow", "pig", "sheep", "chicken", "wolf", "bee"}
CATEGORIES = {"weapon", "tool", "food", "equipment"}
ANIMATIONS = {"body", "head", "jaw", "tail", "leg_fl", "leg_fr", "leg_hl", "leg_hr", "leg_l", "leg_r",
              "arm_l", "arm_r", "wing_l", "wing_r", "float", "orbit", "pulse", "tentacle", "none"}
PATTERNS = {"stone", "skin", "fur", "wool", "ice", "metal", "honey", "glass", "bone", "cloth", "wood", "leaf", "fire", "void"}


def read(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def vector(value, length=3):
    return isinstance(value, list) and len(value) == length and all(
        isinstance(n, (int, float)) and not isinstance(n, bool) and math.isfinite(n) for n in value)


def identity():
    return [[1., 0., 0.], [0., 1., 0.], [0., 0., 1.]]


def mm(a, b):
    return [[sum(a[i][k]*b[k][j] for k in range(3)) for j in range(3)] for i in range(3)]


def mv(a, v):
    return [sum(a[i][j]*v[j] for j in range(3)) for i in range(3)]


def plus(a, b):
    return [x+y for x, y in zip(a, b)]


def rotation(degrees):
    x, y, z = [math.radians(n) for n in degrees]
    cx, sx, cy, sy, cz, sz = math.cos(x), math.sin(x), math.cos(y), math.sin(y), math.cos(z), math.sin(z)
    return mm(mm([[cz, -sz, 0], [sz, cz, 0], [0, 0, 1]],
                 [[cy, 0, sy], [0, 1, 0], [-sy, 0, cy]]),
              [[1, 0, 0], [0, cx, -sx], [0, sx, cx]])


def geometry_vertices(model):
    """Resolve own bone transforms to compare geometry independent of names and texture recolors."""
    bones = {b["name"]: b for b in model["bones"]}
    resolved = {"root": (identity(), [0., 0., 0.])}

    def pose(name):
        if name in resolved:
            return resolved[name]
        b = bones[name]
        pr, pt = pose(b.get("parent", "root"))
        result = (mm(pr, rotation(b.get("rotation", [0, 0, 0]))), plus(pt, mv(pr, b["pivot"])))
        resolved[name] = result
        return result

    all_boxes = []
    for box in model["boxes"]:
        br, bt = pose(box["bone"])
        pivot = box.get("pivot", [box["from"][i] + box["size"][i] / 2 for i in range(3)])
        cr = rotation(box.get("rotation", [0, 0, 0]))
        vertices = []
        for x in (0, 1):
            for y in (0, 1):
                for z in (0, 1):
                    local = [box["from"][i] + box["size"][i]*edge for i, edge in enumerate((x, y, z))]
                    local = plus(pivot, mv(cr, [local[i]-pivot[i] for i in range(3)]))
                    vertices.append(tuple(round(v, 3) for v in plus(bt, mv(br, local))))
        all_boxes.append(tuple(sorted(vertices)))
    return tuple(sorted(all_boxes))


def png_dimensions(path: Path):
    data = path.read_bytes()
    if data[:8] != b"\x89PNG\r\n\x1a\n":
        raise ValueError("not a PNG")
    return struct.unpack("!II", data[16:24])


def item_model_geometry(model):
    elements = model.get("elements", [])
    return tuple(sorted(json.dumps({k: e[k] for k in ("from", "to", "rotation") if k in e}, sort_keys=True)
                        for e in elements))


def namespace_file(resource_id: str, folder: str, suffix: str):
    namespace, name = resource_id.split(":", 1) if ":" in resource_id else ("minecraft", resource_id)
    return RES / "assets" / namespace / folder / (name + suffix)


def run():
    errors = []
    warnings = []
    metrics = {"models": {}, "items": {}, "limitations": [
        "Data checks cannot certify resemblance to concept art or animation quality.",
        "A matching declared action does not prove its runtime behavior; GameTests and visual review remain necessary."]}

    def require(condition, message):
        if not condition:
            errors.append(message)
        return condition

    profiles = read(RES / "boss_profiles.json")
    expected = {p["entity"] for p in profiles}
    require(len(expected) == 68, f"Expected the established 68 species, got {len(expected)}")
    model_dir = RES / "assets/worldbosses/boss_models"
    paths = {p.stem: p for p in model_dir.glob("*.json")}
    require(set(paths) == expected, f"Model coverage mismatch: missing={sorted(expected-set(paths))}, extra={sorted(set(paths)-expected)}")
    shapes = defaultdict(list)
    for entity in sorted(expected & set(paths)):
        try:
            model = read(paths[entity])
            prefix = f"model {entity}: "
            valid = require(model.get("id") == entity, prefix + "wrong ID")
            palette, bones, boxes = model.get("palette", []), model.get("bones", []), model.get("boxes", [])
            valid &= require(1 <= len(palette) <= 16, prefix + "palette must contain 1–16 authored materials")
            valid &= require(len(boxes) >= 24, prefix + "fewer than 24 anatomy/detail boxes; requires review")
            if entity in HEROES:
                valid &= require(len(boxes) >= 100, prefix + "hero reference needs substantial authored anatomy/detail")
            require(model.get("texture_size") == [1024, 1024], prefix + "expected 1024×1024 / 256px material tiles")
            require(vector(model.get("hitbox"), 2) and all(0.1 < n <= 16 for n in model.get("hitbox", [])),
                    prefix + "missing/invalid interactable core hitbox [width,height] in blocks")
            bone_names = [b.get("name") for b in bones]
            valid &= require(bool(bones) and len(set(bone_names)) == len(bone_names) and "root" not in bone_names,
                             prefix + "invalid/duplicate own bone names")
            parent = {b.get("name"): b.get("parent", "root") for b in bones}
            for b in bones:
                valid &= require(vector(b.get("pivot")), prefix + f"invalid pivot for {b.get('name')}")
                valid &= require(vector(b.get("rotation", [0, 0, 0])), prefix + f"invalid rotation for {b.get('name')}")
                valid &= require(b.get("animation", "none") in ANIMATIONS, prefix + f"unknown animation {b.get('animation')}")
                ancestor, seen = b.get("name"), set()
                while ancestor != "root":
                    if ancestor in seen or ancestor not in parent:
                        valid = False
                        errors.append(prefix + f"cyclic/missing bone parent from {b.get('name')}")
                        break
                    seen.add(ancestor)
                    ancestor = parent[ancestor]
            require(any(b.get("animation", "none") != "none" for b in bones), prefix + "no animation driver")
            for material in palette:
                require(isinstance(material.get("name"), str) and material["name"], prefix + "unnamed material")
                require(isinstance(material.get("color"), str) and len(material["color"]) in (7, 9)
                        and material["color"].startswith("#"), prefix + "bad material color")
                require(material.get("pattern") in PATTERNS, prefix + f"unknown pattern {material.get('pattern')}")
            box_signatures = Counter()
            for box in boxes:
                valid &= require(box.get("bone") in parent, prefix + f"box references missing bone {box.get('bone')}")
                valid &= require(vector(box.get("from")) and vector(box.get("size")) and all(0 < n <= 256 for n in box.get("size", [])),
                                 prefix + "nonfinite/zero/oversized geometry")
                valid &= require(isinstance(box.get("material"), int) and 0 <= box["material"] < len(palette), prefix + "bad material index")
                valid &= require(vector(box.get("rotation", [0, 0, 0])) and vector(box.get("pivot", [0, 0, 0])), prefix + "bad box rotation/pivot")
                if vector(box.get("size")):
                    w, h, d = box["size"]
                    require(2*(w+d) <= 256 and h+d <= 256, prefix + f"cuboid UV spills a material tile: {box['size']}")
                key = json.dumps({k: box.get(k) for k in ("bone", "from", "size", "rotation", "pivot")}, sort_keys=True)
                box_signatures[key] += 1
            duplicates = sum(n-1 for n in box_signatures.values() if n > 1)
            require(duplicates <= max(1, int(len(boxes)*.01)), prefix + f"{duplicates} duplicate boxes suggest z-fighting/count padding")
            for suffix in ("", "_emissive"):
                texture = RES / f"assets/worldbosses/textures/entity/boss/{entity}{suffix}.png"
                require(texture.exists(), prefix + f"missing own texture {texture.name}")
                if texture.exists():
                    require(png_dimensions(texture) == (1024, 1024), prefix + f"wrong atlas dimensions: {texture.name}")
            if valid:
                vertices = geometry_vertices(model)
                fingerprint = hashlib.sha256(repr(vertices).encode()).hexdigest()
                shapes[fingerprint].append(entity)
                all_vertices = [point for box in vertices for point in box]
                metrics["models"][entity] = {"bones": len(bones), "boxes": len(boxes), "materials": len(palette),
                    "bounds_px": [[min(p[i] for p in all_vertices) for i in range(3)],
                                  [max(p[i] for p in all_vertices) for i in range(3)]], "geometry_sha256": fingerprint}
        except Exception as exc:
            errors.append(f"model {entity}: {type(exc).__name__}: {exc}")
    for copies in shapes.values():
        require(len(copies) == 1, f"Recolored/reused complete model geometry: {copies}")

    manifest_path = RES / "loot_v2.json"
    if not manifest_path.exists():
        errors.append("Missing loot_v2.json")
    else:
        manifest = read(manifest_path)
        items = manifest.get("items", []) if isinstance(manifest, dict) else manifest
        ids = [item.get("id") for item in items]
        require(len(ids) == len(set(ids)), "Duplicate v2 item IDs")
        sources = {item.get("source") for item in items}
        require(expected <= sources, f"Species missing an individually designed loot item: {sorted(expected-sources)}")
        require(sources <= expected, f"Unknown v2 loot sources: {sorted(sources-expected)}")
        require({item.get("category") for item in items} == CATEGORIES, "Loot does not cover exactly weapon/tool/food/equipment")
        mechanics = defaultdict(list)
        item_shapes = defaultdict(list)
        actions = Counter()
        # New multilingual contributions can be merged into main language files or retained separately.
        langs = {}
        for p in (RES / "assets/worldbosses/lang").glob("*.json"):
            if p.stem.startswith("zh") or p.stem.endswith("zh"):
                langs.update(read(p))
        for p in RES.glob("loot_v2*zh*.json"):
            langs.update(read(p))
        for item in items:
            iid = item.get("id", "")
            short_id = iid.split(":")[-1]
            prefix = f"loot {short_id}: "
            require(item.get("category") in CATEGORIES, prefix + "unsupported category")
            require(bool(item.get("action")), prefix + "no runtime function/action")
            require(not any(s in (iid+' '+item.get("zh_name", '')).lower() for s in ("essence", "精粹", "精髓")),
                    prefix + "generic essence filler is prohibited")
            require(bool(item.get("description_zh") or item.get("description")), prefix + "no explanation of real utility")
            actions[item.get("action")] += 1
            ignored = {"id", "source", "category", "zh_name", "en_name", "description_zh", "description", "model_theme", "palette", "model", "texture", "rarity"}
            behavior = {k: v for k, v in item.items() if k not in ignored}
            mechanics[json.dumps({"category": item.get("category"), **behavior}, sort_keys=True)].append(short_id)
            require('item.worldbosses.'+short_id in langs, prefix + "missing Chinese item translation")
            definition_path = RES / f"assets/worldbosses/items/{short_id}.json"
            require(definition_path.exists(), prefix + "missing modern item definition")
            if not definition_path.exists():
                continue
            definition = read(definition_path)
            reference = definition.get("model", {}).get("model")
            require(isinstance(reference, str), prefix + "item definition is not a concrete 3D model")
            if not isinstance(reference, str):
                continue
            model_path = namespace_file(reference, "models", ".json")
            require(model_path.exists(), prefix + "missing 3D model file")
            if not model_path.exists():
                continue
            model = read(model_path)
            elements = model.get("elements", [])
            require(len(elements) >= 6, prefix + "flat sprite / insufficient independently modeled structure")
            geo = item_model_geometry(model)
            item_shapes[hashlib.sha256(repr(geo).encode()).hexdigest()].append(short_id)
            for element in elements:
                require(vector(element.get("from")) and vector(element.get("to")), prefix + "invalid 3D item element")
            texture_refs = [v for v in model.get("textures", {}).values() if isinstance(v, str) and not v.startswith("#")]
            require(bool(texture_refs), prefix + "model has no own material texture")
            for texture_id in texture_refs:
                require(texture_id.startswith("worldbosses:"), prefix + "reuses a vanilla item texture")
                path = namespace_file(texture_id, "textures", ".png")
                require(path.exists(), prefix + f"missing texture {texture_id}")
                if path.exists():
                    w, h = png_dimensions(path)
                    require(w >= 32 and h >= 32, prefix + "texture below the authored pixel-detail target")
            metrics["items"][short_id] = {"source": item.get("source"), "category": item.get("category"),
                                           "action": item.get("action"), "model_elements": len(elements)}
        require(len(actions) >= 20, f"Only {len(actions)} action types: need substantive variety, not renamed buff tokens")
        for copies in mechanics.values():
            require(len(copies) == 1, f"Identical noncosmetic item mechanics: {copies}")
        for copies in item_shapes.values():
            require(len(copies) == 1, f"Identical 3D item geometry with cosmetic changes only: {copies}")
        metrics["categories"] = dict(Counter(item.get("category") for item in items))
        metrics["actions"] = dict(actions)

    metrics["errors"], metrics["warnings"] = errors, warnings
    return metrics


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report", type=Path, default=ROOT / "build/reports/v2-content.json")
    args = parser.parse_args()
    result = run()
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(result, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    for error in result["errors"]:
        print("FAIL:", error)
    print(f"Models checked: {len(result['models'])}; loot items checked: {len(result['items'])}; errors: {len(result['errors'])}")
    print("This validates data and coverage, not final artistic fidelity or complete runtime correctness.")
    raise SystemExit(bool(result["errors"]))
