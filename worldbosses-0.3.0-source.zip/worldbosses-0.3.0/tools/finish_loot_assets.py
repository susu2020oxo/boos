#!/usr/bin/env python3
"""Finish worn materials, core bone rewards, and sculpted species-specific spawn eggs."""
import json, math
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw
from generate_loot_v2 import Mesh, item_mesh

ROOT=Path(__file__).resolve().parents[1]; RES=ROOT/'src/main/resources'; ASSETS=RES/'assets/worldbosses'
ITEMS=json.loads((RES/'loot_v2.json').read_text())['items']
PROFILES=json.loads((RES/'boss_profiles.json').read_text())
DISPLAY=json.loads((ASSETS/'models/item/v2_basalt_buckler.json').read_text())['display']

def put(path,data):
    path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(data,separators=(',',':'))+'\n')

def palette_texture(path,palette):
    a=np.zeros((64,64,4),dtype=np.uint8);a[:,:,3]=255
    yy,xx=np.mgrid[:16,:16]
    for i,color in enumerate(palette):
        n=np.where((xx%7==0)|(yy%7==0),-18,0)+np.where((xx+2*yy)%11==0,14,0)
        a[i//4*16:i//4*16+16,i%4*16:i%4*16+16,:3]=np.clip(np.array(color)[None,None,:]+n[:,:,None],0,255)
    path.parent.mkdir(parents=True,exist_ok=True);Image.fromarray(a).save(path)

def core_rewards():
    themes={'bone_helmet':'hood','bone_chestplate':'iron_chest','bone_leggings':'greaves','bone_boots':'charge_boots',
            'bone_sword':'greatsword','bone_bow':'bow','soul_longbow':'bow','purified_soup':'broth','blood_flesh':'cutlet'}
    for id,theme in themes.items():
        mesh=item_mesh(theme)
        if id=='blood_flesh':palette=[(118,29,39),(58,16,26),(201,53,57),(74,32,28),(207,144,128)]
        elif id=='purified_soup':palette=[(212,169,87),(76,49,29),(101,189,110),(87,67,43),(239,218,164)]
        else:palette=[(212,210,181),(46,58,63),(81,217,235),(65,70,74),(245,240,208)]
        palette_texture(ASSETS/f'textures/item/{id}.png',palette)
        put(ASSETS/f'models/item/{id}.json',{'textures':{'atlas':f'worldbosses:item/{id}','particle':f'worldbosses:item/{id}'},'elements':mesh.elements,'display':DISPLAY,'gui_light':'side'})
    mesh=Mesh()
    # A carved long bone, flared joints, two binding bands and inset soul runes.
    mesh.box(6,3,6,4,10,4,0)
    for y in (1,12):
        for x in (3.5,8):mesh.box(x,y,5.5,4.5,3.5,5,4)
    for y in (4,10):mesh.box(5.6,y,5.6,4.8,.8,4.8,1)
    for y in (5,7,9):mesh.box(7,y,5.5,2,.8,.8,2)
    palette_texture(ASSETS/'textures/item/soul_bone.png',[(205,208,181),(55,63,68),(89,228,235),(68,62,52),(244,237,208)])
    put(ASSETS/'models/item/soul_bone.json',{'textures':{'atlas':'worldbosses:item/soul_bone','particle':'worldbosses:item/soul_bone'},'elements':mesh.elements,'display':DISPLAY})

def worn_equipment():
    for item in ITEMS:
        if item['category']!='equipment' or item.get('slot')=='offhand':continue
        sculpture=json.loads((ASSETS/f"boss_models/{item['source']}.json").read_text())
        colors=[tuple(bytes.fromhex(p['color'].lstrip('#'))) for p in sculpture['palette']]
        base=colors[0];dark=tuple(int(v*.45) for v in base)
        accent=(115,210,246) if any(p['pattern']=='ice' for p in sculpture['palette']) else colors[min(2,len(colors)-1)]
        edge=(231,222,195)
        if item['action']=='piglin_pass':base=(225,162,43);accent=(164,52,36);edge=(255,224,112)
        for layer in ('humanoid','humanoid_leggings'):
            image=Image.new('RGBA',(128,64));draw=ImageDraw.Draw(image)
            # Detailed plates/fur scales in the native wearable UV layout.
            for yy in range(64):
                for xx in range(128):
                    seam=(xx%8==0 or yy%8==0);riv=(xx%16==3 and yy%16==3)
                    c=edge if riv else dark if seam else tuple(min(255,max(0,v+((xx*3+yy*7)%13-6))) for v in base)
                    image.putpixel((xx,yy),(*c,255))
            for yy in range(4,64,12):
                for xx in range(4,128,16):
                    draw.line([(xx,yy+4),(xx+4,yy),(xx+8,yy+4)],fill=(*accent,255),width=2)
            # Open faces on hoods/crowns; render the player's face through the garment.
            if item.get('slot')=='head':
                draw.rectangle((18,18,29,29),fill=(0,0,0,0))
                if item['action']=='piglin_pass':
                    draw.rectangle((0,0,63,11),fill=(0,0,0,0));draw.rectangle((16,12,31,18),fill=(*edge,255))
            path=ASSETS/f"textures/entity/equipment/{layer}/{item['id']}.png";path.parent.mkdir(parents=True,exist_ok=True);image.save(path)
        put(ASSETS/f"equipment/{item['id']}.json",{'layers':{layer:[{'texture':'worldbosses:'+item['id']}] for layer in ('humanoid','humanoid_leggings')}})

def matrix(rotation,pivot):
    x,y,z=[math.radians(v) for v in rotation];cx,sx=math.cos(x),math.sin(x);cy,sy=math.cos(y),math.sin(y);cz,sz=math.cos(z),math.sin(z)
    rx=np.array([[1,0,0],[0,cx,-sx],[0,sx,cx]]);ry=np.array([[cy,0,sy],[0,1,0],[-sy,0,cy]]);rz=np.array([[cz,-sz,0],[sz,cz,0],[0,0,1]])
    result=np.eye(4);result[:3,:3]=rz@ry@rx;result[:3,3]=pivot;return result

def eggs():
    for profile in PROFILES:
        id=profile['entity'];d=json.loads((ASSETS/f'boss_models/{id}.json').read_text())
        bones={b['name']:b for b in d['bones']};transforms={'root':np.eye(4)}
        def transform(name):
            if name not in transforms:
                b=bones[name];transforms[name]=transform(b.get('parent','root'))@matrix(b.get('rotation',[0,0,0]),b['pivot'])
            return transforms[name]
        chosen={'body','head'} if id=='iron_golem' else {'head'} if 'head' in bones else set(bones)
        for _ in range(len(bones)):
            chosen.update(b['name'] for b in d['bones'] if b.get('parent') in chosen)
        cubes=[]
        for box in d['boxes']:
            if box['bone'] not in chosen:continue
            lo=np.array(box['from']);hi=lo+np.array(box['size'])
            vertices=np.array([[x,y,z,1.] for x in (lo[0],hi[0]) for y in (lo[1],hi[1]) for z in (lo[2],hi[2])]).T
            local=np.eye(4)
            if any(box.get('rotation',[0,0,0])):
                pivot=np.array(box.get('pivot',(lo+hi)/2));local=matrix([0,0,0],pivot)@matrix(box['rotation'],[0,0,0])@matrix([0,0,0],-pivot)
            v=(transform(box['bone'])@local@vertices)[:3,:].T;v[:,1]*=-1
            cubes.append((v.min(0),v.max(0),box['material']))
        low=np.min([c[0] for c in cubes],0);high=np.max([c[1] for c in cubes],0)
        scale=min(13/(high-low)[0],11/(high-low)[1],12/(high-low)[2]);center=(low+high)/2
        shell=Mesh()
        # An open, eight-step sculpted egg cradle; the Boss's own head protrudes above it.
        for y,width,depth in [(0,4,4),(1,7,6),(2,9,8),(3,10,9),(4,10,9),(5,9,8),(6,7,6)]:
            shell.box(8-width/2,y,8-depth/2,width,1.15,depth,0 if y%2 else 1)
        for x,z in [(3.2,5),(11.8,5),(3.2,10),(11.8,10)]:shell.box(x,4,z,1,4,1,2)
        for e in shell.elements:
            for face in e['faces'].values():face['texture']='#shell'
        elements=shell.elements
        for lo,hi,material in cubes:
            frm=(lo-center)*scale+np.array([8,11,8]);to=(hi-center)*scale+np.array([8,11,8])
            tile=material%4*4,material//4*4;uv=[tile[0]+.05,tile[1]+.05,tile[0]+1,tile[1]+1]
            elements.append({'from':[round(float(v),3) for v in frm],'to':[round(float(v),3) for v in to],
                             'faces':{face:{'uv':uv,'texture':'#atlas'} for face in ('north','south','east','west','up','down')}})
        color=profile['color'];base=((color>>16)&255,(color>>8)&255,color&255)
        palette_texture(ASSETS/f'textures/item/{id}_spawn_egg.png',[base,tuple(int(v*.5) for v in base),(230,199,123),(84,66,47),(237,225,194)])
        # Item atlas discovers textures/item automatically. Keep the tiny head palette separate
        # from the 1024px entity atlas so eggs neither miss textures nor bloat the shared atlas.
        palette_texture(ASSETS/f'textures/item/{id}_egg_head.png',[tuple(bytes.fromhex(p['color'].lstrip('#'))) for p in d['palette']])
        put(ASSETS/f'models/item/{id}_spawn_egg.json',{'textures':{'atlas':f'worldbosses:item/{id}_egg_head','shell':f'worldbosses:item/{id}_spawn_egg','particle':f'worldbosses:item/{id}_spawn_egg'},'elements':elements,'display':DISPLAY,'gui_light':'side'})
        put(RES/f'assets/minecraft/items/{id}_spawn_egg.json',{'model':{'type':'minecraft:model','model':f'worldbosses:item/{id}_spawn_egg'}})

def legacy_conversions():
    # Old saves retain their items; three old placeholders can be salvaged into that species' finished reward.
    by_source={i['source']:i for i in ITEMS};done=set()
    for profile in PROFILES:
        material=profile['material']
        if material in {'blood_flesh','soul_bone'} or material in done:continue
        done.add(material)
        put(RES/f'data/worldbosses/recipe/reclaim_{material}.json',{'type':'minecraft:crafting_shapeless','category':'misc',
            'ingredients':['worldbosses:'+material]*3,'result':{'id':'worldbosses:'+by_source[profile['entity']]['id'],'count':1}})

def cooling_step():
    put(ASSETS/'blockstates/cooling_step.json',{'variants':{'':{'model':'worldbosses:block/cooling_step'}}})
    put(ASSETS/'models/block/cooling_step.json',{'parent':'minecraft:block/cube_all','textures':{'all':'minecraft:block/basalt_top'}})

if __name__=='__main__':
    core_rewards();worn_equipment();eggs();legacy_conversions();cooling_step()
    print('Finished 68 sculpted spawn eggs, all wearable materials, core 3D rewards and old-save salvage recipes.')
