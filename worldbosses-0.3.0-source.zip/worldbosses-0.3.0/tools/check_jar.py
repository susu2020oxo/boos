#!/usr/bin/env python3
"""Validate production packaging, especially split-source-set Mixin refmaps."""
import json
import sys
import zipfile
from pathlib import Path

version=next(line.split('=',1)[1].strip() for line in Path('gradle.properties').read_text().splitlines() if line.startswith('mod_version='))
path=Path(sys.argv[1] if len(sys.argv)>1 else f'build/libs/worldbosses-{version}.jar')
with zipfile.ZipFile(path) as jar:
    assert jar.testzip() is None
    mod=json.loads(jar.read('fabric.mod.json'))
    assert mod['depends']['minecraft']=='1.21.10'
    assert mod['version']==version
    assert not any('BossGameTests' in name for name in jar.namelist())
    for config_name in ['worldbosses.mixins.json','worldbosses.client.mixins.json']:
        config=json.loads(jar.read(config_name))
        refmap=json.loads(jar.read(config['refmap']))['mappings']
        for name in config.get('mixins',[])+config.get('client',[]):
            full_name=config['package'].replace('.','/')+'/'+name
            assert full_name in refmap, f'{config_name} points to the wrong refmap for {full_name}'
            assert refmap[full_name], f'Empty mappings for {full_name}'
    print(f'PASS: {path.name}: metadata, all production Mixin references, CRC, and test exclusion')
