from pathlib import Path
import urllib.request,json,hashlib,re,concurrent.futures,shutil,zipfile,os,platform
ROOT=Path('/workspace/boos');BASE=ROOT/'build/production-smoke';BASE.mkdir(exist_ok=True)
CACHE=Path('/workspace/tools/gradle-home');JAVA='/workspace/tools/jdk-21.0.9+10/bin/java'
def get_json(url):
 with urllib.request.urlopen(url,timeout=40) as r:return json.load(r)
def sha(p):return hashlib.sha1(p.read_bytes()).hexdigest()
def fetch(url,path,expected):
 path=Path(path)
 if path.exists() and sha(path)==expected:return path
 path.parent.mkdir(parents=True,exist_ok=True)
 with urllib.request.urlopen(url,timeout=60) as r:path.write_bytes(r.read())
 if sha(path)!=expected:raise RuntimeError('Artifact checksum mismatch: '+path.name)
 return path
manifest=get_json('https://piston-meta.mojang.com/mc/game/version_manifest_v2.json')
v=next(v for v in manifest['versions'] if v['id']=='1.21.10')
version_path=fetch(v['url'],BASE/'version.json',v['sha1']);version=json.loads(version_path.read_text())
fabric=get_json('https://meta.fabricmc.net/v2/versions/loader/1.21.10/0.17.3/profile/json')
jar_index={}
for p in CACHE.rglob('*.jar'):jar_index.setdefault(p.name,[]).append(p)
def use_artifact(url,path,expected):
 path=Path(path)
 if path.exists() and sha(path)==expected:return path
 for cached in jar_index.get(path.name,[]):
  if sha(cached)==expected:
   path.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(cached,path);return path
 return fetch(url,path,expected)
def allowed(lib):
 rules=lib.get('rules')
 if not rules:return True
 ok=False
 for rule in rules:
  cond=rule.get('os',{})
  match=cond.get('name','linux')=='linux'
  if 'arch' in cond:match &= bool(re.search(cond['arch'],platform.machine()))
  if 'version' in cond:match &= bool(re.search(cond['version'],platform.release()))
  if 'features' in rule:match &= all(value is False for value in rule['features'].values())
  if match:ok=rule['action']=='allow'
 return ok
jobs={}
for lib in version['libraries']:
 if not allowed(lib):continue
 artifact=lib.get('downloads',{}).get('artifact')
 if artifact:
  coord=lib['name'].split(':');jobs[tuple(coord[:2]+coord[3:])]=(artifact['url'],BASE/'libraries'/artifact['path'],artifact['sha1'])
for lib in fabric['libraries']:
 pieces=lib['name'].split(':');group,name,ver=pieces[:3]
 filename=f'{name}-{ver}'+('-'+pieces[3] if len(pieces)>3 else '')+'.jar'
 rel=group.replace('.','/')+'/'+name+'/'+ver+'/'+filename
 url=lib.get('url','https://maven.fabricmc.net/')+rel
 with urllib.request.urlopen(url+'.sha1',timeout=40) as r:expected=r.read().decode().split()[0]
 if not re.fullmatch('[0-9a-fA-F]{40}',expected):raise RuntimeError('Missing checksum '+filename)
 jobs[tuple(pieces[:2]+pieces[3:])]=(url,BASE/'libraries'/rel,expected.lower())
with concurrent.futures.ThreadPoolExecutor(6) as pool:libs=list(pool.map(lambda a:use_artifact(*a),jobs.values()))
client=use_artifact(version['downloads']['client']['url'],BASE/'minecraft-client.jar',version['downloads']['client']['sha1'])
natives=BASE/'natives';natives.mkdir(exist_ok=True)
for p in libs:
 if 'natives-linux' in p.name:
  with zipfile.ZipFile(p) as z:
   for n in z.namelist():
    if n.endswith('.so'):(natives/Path(n).name).write_bytes(z.read(n))
mods=BASE/'mods';mods.mkdir(exist_ok=True)
version_id=next(line.split('=',1)[1].strip() for line in (ROOT/'gradle.properties').read_text().splitlines() if line.startswith('mod_version='))
for old in mods.glob('worldbosses-*.jar'):old.unlink()
shutil.copy2(ROOT/f'build/libs/worldbosses-{version_id}.jar',mods/f'worldbosses-{version_id}.jar')
api=next(p for p in CACHE.rglob('fabric-api-0.138.4+1.21.10.jar') if 'files-2.1' in str(p))
shutil.copy2(api,mods/api.name)
if not (BASE/'saves/New World').exists():shutil.copytree(ROOT/'run/saves/New World',BASE/'saves/New World')
shutil.copy2(ROOT/'run/options.txt',BASE/'options.txt')
options=(BASE/'options.txt').read_text()
for key,value in {'lang':'zh_cn','guiScale':'2','tutorialStep':'none','renderDistance':'8'}.items():
 options=re.sub(r'(?m)^'+key+r':.*$',key+':'+value,options)
(BASE/'options.txt').write_text(options)
assets=CACHE/'caches/fabric-loom/assets'
asset_index_id=version['assetIndex']['id']
if not (assets/'indexes'/(asset_index_id+'.json')).exists():
 asset_index_id='1.21.10-'+asset_index_id
assert (assets/'indexes'/(asset_index_id+'.json')).exists(), 'Missing verified asset index'
cmd=[JAVA,'-Xmx2G','-Djava.library.path='+str(natives),'-cp',os.pathsep.join(str(p) for p in libs+[client]),fabric['mainClass'],
     '--username','Player97','--version','1.21.10','--gameDir',str(BASE),'--assetsDir',str(assets),'--assetIndex',asset_index_id,
     '--uuid','0b0a3338-3321-32ee-8738-58aa00379d42','--accessToken','0','--userType','legacy','--versionType','release',
     '--width','1280','--height','720','--quickPlaySingleplayer','New World']
print('Production launch: official Minecraft + Fabric Loader, only packaged mod/API; all artifact SHA1 checks passed.',flush=True)
(BASE/'smoke.pid').write_text(str(os.getpid()))
log=open(BASE/'launcher-output.log','w');os.dup2(log.fileno(),1);os.dup2(log.fileno(),2)
os.chdir(BASE);os.execv(JAVA,cmd)
