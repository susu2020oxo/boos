#!/usr/bin/env python3
"""v0.3 anatomy revisions: steel sentinel, flowing equine, boar and eight-legged spiders."""
import math
from models_animals import Model
from models_heroes import Sculpture, mat
from models_hostiles import spider


def beam(m, bone, a, b, width, material, depth=None):
    d=[b[i]-a[i] for i in range(3)]; length=math.sqrt(sum(v*v for v in d))
    c=[(a[i]+b[i])/2 for i in range(3)]; depth=depth or width
    rot=(math.degrees(math.atan2(d[2],math.hypot(d[0],d[1]))),0,-math.degrees(math.atan2(d[0],d[1])))
    m.b(bone,(c[0]-width/2,c[1]-length/2,c[2]-depth/2),(width,length,depth),material,rot)


def guardian():
    m=Model('iron_golem',[('steel','#C0CFD5','metal'),('silver','#E2ECEC','metal'),
        ('joint','#34434F','metal'),('rim','#768F9B','metal'),('red','#FF4B50','fire'),('gold','#BDAC79','metal')])
    m.bone('body',(0,-16,0),'body')
    # Rounded stepped barrel, broad sloping shoulders and an inset seven-light visor.
    for y,w,d,h in [(-30,16,12,3),(-27,24,16,5),(-22,30,20,7),(-15,32,22,12),(-3,26,18,7),(4,20,14,8)]:
        m.b('body',(-w/2,y,-d/2),(w,h,d),'steel')
        m.b('body',(-w/2+.4,y,-d/2-.35),(w-.8,.65,.7),'silver')
    m.b('body',(-8,-24,-10.7),(16,14,2),'joint')
    m.b('body',(-6.7,-25,-11),(13.4,1,1),'rim')
    for x,y in [(0,-22),(-4,-19),(4,-19),(0,-16),(-4,-13),(4,-13),(0,-10)]:
        m.b('body',(x-1.3,y-1.3,-11.7),(2.6,2.6,1),'black')
        m.b('body',(x-.8,y-.8,-12),(1.6,1.6,1),'red')
    for s in (-1,1):
        for row in range(4):
            m.b('body',(s*11-2,-10+row*3,-11.3),(4,2,.8),'rim')
            m.b('body',(s*10-1.1,-9.6+row*3,-11.7),(2.2,.6,.6),'silver')
        n='arm_l' if s<0 else 'arm_r';m.bone(n,(s*19,-32,0),n)
        for y,w,d,h,material in [(0,12,14,7,'silver'),(6,10,11,11,'steel'),(16,7,8,5,'joint'),(20,11,12,13,'steel'),(32,12,13,7,'rim')]:
            m.b(n,(-w/2,y,-d/2),(w,h,d),material)
        for y in (3,24,29):m.b(n,(-6.2,y,-6.2),(12.4,1.2,12.4),'silver')
        for finger in range(3):
            x=-4.6+finger*3.4;m.b(n,(x,36,-7),(2.8,6,6),'steel')
            m.b(n,(x+.2,39,-7.3),(2.4,1,1),'joint')
        m.b(n,(s*6-1.5,33,-5),(3,6,4),'steel')
        for y in range(8,17,3):m.b(n,(-2.5,y,-5.7),(5,1,1),'joint')
        leg='leg_l' if s<0 else 'leg_r';m.bone(leg,(s*7,-4,0),leg)
        m.b(leg,(-4,0,-4.5),(8,11,9),'joint')
        m.b(leg,(-5,2,-5.5),(10,9,11),'steel')
        m.b(leg,(-5.4,10,-6),(10.8,6,12),'rim')
        m.b(leg,(-4.8,15,-4.5),(9.6,10,10),'steel')
        m.b(leg,(-6,24,-9),(12,4,16),'joint')
        m.b(leg,(-5.7,22,-8.5),(11.4,4,15),'silver')
        for t in range(3):m.b(leg,(-4.8+t*3.5,25,-9.5),(2.8,3,4),'steel')
        for y in (5,18):m.b(leg,(-1.3,y,-5.9),(2.6,3,.8),'gold')
    for x in (-9,-3,3,9):
        m.b('body',(x-1,3,-9.5),(2,4,1),'joint')
        m.b('body',(x-.5,3.5,-10),(1,3,.7),'red')
    m.bone('head',(0,-45,0),'none');m.b('head',(-5,-2,-4),(10,2,8),'silver')
    m.write()


def river_horse():
    m=Model('horse',[('coat','#63C5D4','skin'),('shade','#318AA9','skin'),('light','#B8EEF0','skin'),
        ('mane','#7355B8','cloth'),('mane_light','#A389E0','cloth'),('crystal','#8DE4F1','ice'),('hoof','#2B4A66','metal')])
    m.bone('body',(0,-1,1),'body')
    for xyz,size,material in [((-6,-6,-11),(12,13,26),'coat'),((-5,-7,-8),(10,2,20),'light'),
        ((-5,6,-7),(10,3,17),'shade'),((-6.8,-4,-10),(13.6,11,8),'coat'),((-6.7,-3,7),(13.4,13,8),'coat')]:m.b('body',xyz,size,material)
    m.bone('neck',(0,-6,-9),'body')
    beam(m,'neck',(0,5,0),(0,-15,-8),7,'coat',8)
    beam(m,'neck',(0,3,-3),(0,-15,-10),4,'light',2)
    m.bone('head',(0,-23,-18),'head')
    m.b('head',(-3.5,-4,-4),(7,9,7),'coat',(10,0,0))
    m.b('head',(-2.8,0,-10),(5.6,5.3,8),'coat',(16,0,0))
    m.b('head',(-2.6,3,-11),(5.2,2,4),'light')
    for s in (-1,1):
        m.eye('head',s*3.4,-1.8,-3,s,True,1.6,1.3)
        m.b('head',(s*1.6-.45,2.5,-11.3),(.9,.7,.5),'black')
        m.ear('ear'+str(s),'head',(s*2.4,-3,0),7,2.2,'coat','shade',(0,0,s*12))
        # The open diamond crest and swept white streamers frame, rather than cover, the horse head.
        beam(m,'head',(0,-4,-3),(s*4,-10,-3),1.7,'crystal')
        beam(m,'head',(s*4,-10,-3),(0,-17,-3),1.4,'crystal')
        ribbon='ribbon'+str(s);m.bone(ribbon,(s*4,-18,-13),'tail')
        points=[(0,0,0),(s*4,-3,8),(s*6,-1,18),(s*5,3,27),(s*8,1,36)]
        for a,b in zip(points,points[1:]):beam(m,ribbon,a,b,.8,'white',2.3)
        for name,z in [('leg_fl',-7),('leg_hl',10)]:
            if s>0:name={'leg_fl':'leg_fr','leg_hl':'leg_hr'}[name]
            m.bone(name,(s*4.6,8,z),name)
            beam(m,name,(0,0,0),(s*.3,7,1 if z>0 else -.8),3.1,'coat')
            beam(m,name,(s*.3,7,1 if z>0 else -.8),(0,14,-.6),2.2,'light')
            m.b(name,(-1.6,6,-1.8),(3.2,2.5,3.6),'shade')
            m.b(name,(-1.8,13,-2.5),(3.6,3,4.7),'hoof')
            m.b(name,(-1.6,13,-2.6),(3.2,.7,4.8),'crystal')
        for z in (-6,3,10):m.b('body',(s*6.1-.2,-2,z),(.65,2.7,3.7),'white',(25,0,0))
    # Flowing overlapping mane blades follow the neck then sweep backward, leaving the torso legible.
    for i in range(12):
        y=-23+i*1.4;z=-12+i*1.1
        beam(m,'body',(-1.8,y,z),(-2.2,y+4,z+10+i*.45),2.8,'mane',4)
        beam(m,'body',(1.8,y,z),(2.2,y+3,z+11+i*.45),2.8,'mane_light' if i%3==0 else 'mane',3.4)
    m.bone('tail',(0,1,15),'tail')
    for i in range(7):
        beam(m,'tail',((i%3-1)*1.2,i*.6,i*2),((i%3-1)*1.8,4+i*.7,8+i*2),2.3,'mane_light' if i%3==0 else 'mane')
    m.write()


def boar():
    m=Sculpture('pig',[mat(n,c,p) for n,c,p in [
        ('hide','#7F4940','skin'),('hide_light','#B36B55','skin'),('hide_dark','#503633','fur'),
        ('bristle','#322A2C','fur'),('rock','#443237','stone'),('edge','#804A3B','stone'),
        ('lava','#FA6B24','fire'),('hot','#FFC966','fire'),('ivory','#E7D8B5','bone'),
        ('tip','#FFF0CF','bone'),('hoof','#29242B','stone'),('eye','#161119','void'),('glint','#FFF4DA','glass')]],
        ['long tapered wild-boar snout','high muscled forequarters and sloping back','four separated cloven hooves',
         'upturned side tusks','small upright ears','red-hot stiff dorsal bristles'])
    m.bone('torso',parent='root',animation='body');m.bone('head',(0,3,-19),animation='head')
    m.box('torso',(-11,-8,-18),(22,20,30),'hide')
    m.box('torso',(-12,-12,-16),(24,17,15),'hide_dark')
    m.box('torso',(-9,-5,10),(18,16,13),'hide')
    m.box('torso',(-9,9,-12),(18,5,27),'hide_dark')
    m.box('head',(-8,-7,-7),(16,15,14),'hide')
    # Long wedge-like nasal bridge, narrowing from cheek to a firm oval block snout.
    for xyz,size in [((-7,-3,-13),(14,10,8)),((-5.6,-1.5,-19),(11.2,8,8)),((-4.7,0,-24),(9.4,6.4,6))]:
        m.box('head',xyz,size,'hide_light')
    m.box('head',(-4.5,1,-24.6),(9,4.8,1),'hide_dark')
    for s in (-1,1):
        m.box('head',(s*2.7-.9,2.2,-25),(1.8,1.5,.6),'eye')
        m.box('head',(s*6.9-1,-4.3,-7.7),(2,2,1),'eye')
        m.box('head',(s*6.9-.5,-4,-8.1),(.55,.6,.5),'glint')
        m.box('head',(s*6-2,-5.9,-8),(4,1.2,2),'hide_dark',(0,0,s*12))
        m.bone('ear'+str(s),(s*6,-6,-1),parent='head',rotation=(-12,0,s*22))
        m.box('ear'+str(s),(-2.5,-7,-1),(5,8,2.5),'hide_dark')
        m.box('ear'+str(s),(-1.5,-6,-1.3),(3,5,.7),'hide_light')
        m.box('ear'+str(s),(-1,-9,-.8),(2,2,1.8),'bristle')
        for a,b,w in [((s*6,5,-13),(s*10,1,-17),3.6),((s*10,1,-17),(s*11,-5,-18),2.7),((s*11,-5,-18),(s*9.8,-10,-17),1.5)]:m.beam('head',a,b,w,'ivory' if w>2 else 'tip')
        m.beam('head',(s*6,1,-15),(s*8,-2,-18),1.5,'ivory')
        for i in range(4):m.box('head',(s*7-1,-1+i*1.8,-4+i*.7),(2,3,4),'bristle',(15,0,s*8))
        for front,z in [(True,-11),(False,15)]:
            name=('leg_f' if front else 'leg_h')+('l' if s<0 else 'r')
            m.bone(name,(s*8,9,z),animation=name)
            m.box(name,(-3,0,-3.2),(6,8,6.4),'hide_light')
            m.box(name,(-2.5,7,-2.5),(5,6,5),'hide_dark')
            for k in (-1,1):m.box(name,(k*1.7-1.45,12,-4),(2.9,3,6.6),'hoof')
            m.box(name,(-3.4,6,-3.4),(6.8,2.4,6.8),'rock')
            m.box(name,(-2.8,6.7,-3.7),(5.6,.5,.7),'lava')
        for i in range(6):
            z=-15+i*5;y=-12+i*1.05
            m.box('torso',(s*10-2,y,z),(4,4,4.5),'rock')
            m.box('torso',(s*10-1.5,y-.5,z+.4),(3,1,3.7),'edge')
            m.box('torso',(s*11.7-.3,y+1,z+.5),(.6,2,3.4),'lava')
    for i in range(11):
        z=-16+i*3.2;y=-13+i*.7;h=9-i*.35
        for x in (-3,0,3):
            m.beam('torso',(x,y,z),(x*.8,y-h,z+3),1.7,'bristle')
            if x==0:m.beam('torso',(x,y-1,z-.2),(x,y-h+1,z+2.4),.65,'lava')
    m.bone('tail',(0,4,22),animation='tail')
    m.beam('tail',(0,0,0),(1,-1,7),1.4,'hide_dark');m.beam('tail',(1,-1,7),(2,2,10),1.1,'bristle')
    m.save()


def arachnid(identity):
    m=spider(identity)
    m.d['bones']=[b for b in m.d['bones'] if not b['name'].startswith('leg_')]
    m.d['boxes']=[b for b in m.d['boxes'] if not b['bone'].startswith('leg_')]
    m.d['design']='Eight widely fanned articulated legs rooted in the cephalothorax; separate fore, mid and hind feet, low abdomen and eight eyes.'
    def segment(bone,a,b,width,material):
        d=[b[i]-a[i] for i in range(3)];length=math.sqrt(sum(v*v for v in d));c=[(a[i]+b[i])/2 for i in range(3)]
        rot=[math.degrees(math.atan2(d[2],math.hypot(d[0],d[1]))),0,-math.degrees(math.atan2(d[0],d[1]))]
        m.box(bone,c[0]-width/2,c[1]-length/2,c[2]-width/2,width,length,width,material,rot,c)
    for s in (-1,1):
        for i,(hz,kz,fz) in enumerate([(-5,-17,-25),(-2,-7,-10),(1,8,14),(4,19,29)]):
            name=f'leg_{s}_{i}';m.bone(name,(s*7,12,hz),('leg_fl','leg_hl','leg_fr','leg_hr')[(i+(s>0))%4])
            hip=(0,0,0);knee=(s*10,-6,kz-hz);foot=(s*20,12,fz-hz)
            segment(name,hip,knee,2.9,'carapace');segment(name,knee,foot,2,'carapace')
            for t in (.25,.6,.85):
                a=tuple(knee[j]*t for j in range(3));b=tuple(knee[j]*min(1,t+.13) for j in range(3));segment(name,a,b,3.4,'edge')
            m.box(name,knee[0]-2,knee[1]-2,knee[2]-2,4,4,4,'edge')
            segment(name,tuple(knee[j]+(foot[j]-knee[j])*.48 for j in range(3)),tuple(knee[j]+(foot[j]-knee[j])*.58 for j in range(3)),2.6,'edge')
            segment(name,tuple(knee[j]+(foot[j]-knee[j])*.86 for j in range(3)),foot,1.5,'black')
    m.save()


if __name__=='__main__':
    guardian();river_horse();boar();arachnid('spider');arachnid('cave_spider')
