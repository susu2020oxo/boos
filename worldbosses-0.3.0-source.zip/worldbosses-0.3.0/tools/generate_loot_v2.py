#!/usr/bin/env python3
"""Individual finished rewards: authored functions, volumetric item meshes and original material tiles."""
from pathlib import Path
import json,math,hashlib
import numpy as np
from PIL import Image
from loot_v3_upgrade import upgrade

ROOT=Path(__file__).resolve().parents[1];RES=ROOT/'src/main/resources'
ITEMS=[]
def add(source,id,name,category,action,theme,description,**params):
    base={'weapon':{'durability':320,'cooldown_ticks':200,'power':6},'tool':{'durability':96,'cooldown_ticks':120,'power':4},
          'food':{'nutrition':8,'saturation':.7,'duration_ticks':600,'power':1},'equipment':{'durability':280,'slot':'chest','power':2}}[category]
    ITEMS.append(dict(id='v2_'+id,source=source,zh_name=name,en_name=id.replace('_',' ').title(),category=category,
                      action=action,model_theme=theme,description_zh=description,**(base|params)))

add('cow','basalt_buckler','磐角壁垒','equipment','basalt_guard','shield','举盾抵挡攻击；开始格挡时击退近身敌人，冲击冷却20秒。',slot='offhand',cooldown_ticks=400)
add('pig','ember_cutlet','赤髓厚切猪排','food','ember_meal','cutlet','食用恢复饥饿与少量生命，立即灭火并获得20秒抗火。',nutrition=10,duration_ticks=400)
add('sheep','frost_mantle','霜绒披肩','equipment','frost_mantle','mantle','穿戴时免受细雪冻结；在雪地缓慢恢复，并降低冰霜减速时长。',slot='chest')
add('chicken','sunfeather_fan','赤冠金羽扇','tool','feather_glide','fan','空中展开获得短时缓降和一次轻微抬升；不能连续滞空，冷却12秒。',cooldown_ticks=240)
add('wolf','frostpack_greaves','霜鬃护胫','equipment','pack_guard','greaves','身边8格内自己的驯服伙伴获得少量伤害抵抗；伙伴受伤时护主者短时加速。',slot='legs')
add('bee','royal_comb','琥珀蜂王浆','food','royal_detox','honeycomb','食用解除中毒并恢复生命，30秒内不再受到中毒效果。',nutrition=6,duration_ticks=600)
add('rabbit','moonstep_boots','月跃绒靴','equipment','moonstep','rabbit_boots','穿戴提升跳跃，腾空时下蹲可追加一次短跃；落地重置，不能无限连跳。',slot='feet')
add('goat','cliff_anchor','崖角攀登镐','tool','cliff_climb','climbing_pick','指向近处岩壁使用，沿墙抬升一小段；需要真实岩壁，消耗耐久。',cooldown_ticks=80)
add('horse','storm_reins','雷鬃疾行缰','tool','mount_dash','reins','骑乘时让坐骑沿朝向短促加速，清除坐骑缓慢；不会传送或伤害坐骑。',cooldown_ticks=300)
add('donkey','packer_satchel','磐途拾遗囊','tool','vacuum_items','satchel','收集6格内掉落物至背包；满包时原物品保留在地上，冷却8秒。',cooldown_ticks=160)
add('mule','field_repair_kit','铁脊修补匣','tool','repair_offhand','repair_kit','消耗一个铁锭，为副手可损耗装备修复最多24耐久；修补匣也消耗耐久。',cooldown_ticks=80)
add('camel','dune_date','沙丘补给蜜枣','food','desert_provision','date','长途补给：解除饥饿，90秒内分段恢复少量饥饿值；增益不能重复叠加。',nutrition=8,duration_ticks=1800)
add('llama','caravan_bell','彩毯领队铃','tool','caravan_call','bell','让附近友好动物短时跟随使用者，不改变驯服归属、不激怒中立生物。',cooldown_ticks=200)
add('trader_llama','restock_pack','商旅行囊','tool','restock_offer','pack','对村民使用并支付一颗绿宝石，恢复一项已耗尽交易的次数；冷却5分钟。',cooldown_ticks=6000)
add('skeleton_horse','ghost_lance','幽骑骨矛','weapon','mounted_lance','spear','骑乘时命中额外造成少量伤害；主动向前短突刺，不能穿越方块。',cooldown_ticks=240)
add('zombie_horse','mire_boots','苔疫行靴','equipment','mire_walk','mire_boots','踩在菌丝或灰化土上可解除中毒；在泥地获得短时行走加速。',slot='feet')
add('cat','nightveil_hood','夜纹潜行兜帽','equipment','cat_stealth','hood','潜行时获得夜视；附近苦力怕更难持续锁定潜行者，已点燃的苦力怕仍危险。',slot='head')
add('ocelot','spotted_dagger','金斑伏击匕首','weapon','ambush_blade','dagger','从目标背后命中追加伤害，并使目标短时发光；每个使用者有内置冷却。',cooldown_ticks=160,power=4)
add('fox','ember_cookpot','焰尾便携烤炉','tool','field_cook','cookpot','支付一块煤，把副手最多8份生肉加工成熟肉；没有凭空生成食物。',cooldown_ticks=160)
add('panda','bamboo_cultivator','墨竹栽培杖','tool','bamboo_garden','bamboo_staff','消耗竹子，在脚边合适土壤栽下小片竹林；已有竹子只适度增高。',cooldown_ticks=200)
add('polar_bear','icewall_cuirass','冰垒护胸','equipment','ice_barrier','ice_chest','穿戴在雪地时周期获得短时投射物防护，抵挡后进入冷却。',slot='chest')
add('bat','echo_locator','回声测洞器','tool','echo_scan','sonar','显示12格内非玩家敌对生物的短时轮廓，便于寻找洞穴威胁；冷却20秒。',cooldown_ticks=400)
add('parrot','prismatic_decoy','虹羽拟声哨','tool','prismatic_decoy','whistle','召出持续数秒的无害幻影并吸引附近敌人；不会生成新的Boss或奖励。',cooldown_ticks=600)
add('frog','marsh_tongue_hook','沼冠舌钩','tool','tongue_pull','tongue','把视线前方的一只生物或掉落物拉近；距离有限、不能隔墙抓取。',cooldown_ticks=120)
add('armadillo','red_scute_kneepads','赤砂护膝','equipment','crouch_bulwark','scute','静止潜行蓄势后获得短时抗性和击退抵抗，起身移动会解除。',slot='legs')
add('sniffer','ancient_seed_spade','古苔寻种铲','tool','seed_excavate','shovel','对泥土消耗骨粉寻得古代植物种子；消耗铲子耐久并留下挖掘提示。',cooldown_ticks=240)
add('mooshroom','crimson_stew','绯菌滋养煲','food','fungal_stew','stew','解除中毒与凋零，获得短时伤害吸收；吃完返还碗。',nutrition=10,duration_ticks=900)
add('strider','thermal_spindle','熔绒织火梭','tool','thermal_patch','spindle','支付岩浆膏，为副手护具覆上一次临时隔热保护；护具受火伤时消耗保护。',cooldown_ticks=400)
add('allay','sorting_chime','晶歌分拣铃','tool','selective_magnet','songbell','只收集与副手同种的掉落物，范围比拾遗囊更远，避免捡入不需要的物品。',cooldown_ticks=160)
add('villager','emerald_signet','绿宝石议长印','equipment','trade_seal','seal','副手持有时可向村民支付绿宝石，获得短时交易优惠；有独立冷却。',slot='offhand',cooldown_ticks=2400)
add('wandering_trader','trail_chart','万宝旅图','tool','waypoint_chart','map','潜行使用记录当前位置；普通使用报告路标方向与距离，近处显示指引粒子。',cooldown_ticks=20)
add('iron_golem','vine_iron_plate','古藤守村胸铠','equipment','village_ward','iron_chest','穿戴后减轻击退，并为附近村民提供有限的防护，不提高村民攻击性。',slot='chest')
add('snow_golem','frost_lantern_staff','霜灯雪球杖','weapon','frost_snowball','snow_staff','消耗雪球发射霜灯弹，命中造成少量伤害并短时减速、积累冻结。',cooldown_ticks=40,power=2)
add('happy_ghast','cloud_harness','晴云安全带','equipment','cloud_rescue','harness','高处坠落时自动提供一次缓降救援，消耗耐久并进入40秒冷却。',slot='chest',cooldown_ticks=800)
add('copper_golem','copper_wrench','铜铸搬运钳','tool','rotate_block','wrench','调整可旋转方块的朝向或轴线，不破坏方块及容器内容。',cooldown_ticks=10)
add('zombie','tomb_maul','墓铠震地锤','weapon','tomb_slam','hammer','主动向前震击近身敌人并击退，收招后有冷却；另掉可食用的凝血腐肉。',cooldown_ticks=280,power=6)
add('husk','sand_plough','沙葬九宫耕犁','tool','till_plane','plough','一次开垦前方3×3的适宜土地，逐格消耗耐久；不破坏其他方块。',cooldown_ticks=40)
add('zombie_villager','purifying_broth','净疫肉羹','food','purifying_broth','broth','解除虚弱、饥饿和反胃，提供短时再生；90秒内减轻再次获得饥饿。',nutrition=8,duration_ticks=1800)
add('skeleton','soul_longbow','冥骨猎王长弓','weapon','soul_arrow','bow','真正的弓：命中使目标短时发光；Boss成品自带力量III与耐久II，少量升级为力量IV。',durability=560,cooldown_ticks=0)
add('stray','rime_longbow','霜弦封路弓','weapon','frost_arrow','frost_bow','真正的弓：命中附缓慢并积累冻结；不会无限冻结目标。',durability=480,cooldown_ticks=0)
add('bogged','bog_arbalest','苔毒机弩','weapon','toxic_arrow','toxic_crossbow','真正的弩：箭矢造成短时中毒；可与特殊箭配合，毒等级不反复叠加。',durability=420,cooldown_ticks=0)
add('creeper','crackshot_launcher','裂核投弹器','weapon','crack_grenade','bombcaster','消耗火药抛射有引信的裂核弹，短延迟爆破只伤实体、不炸建筑。',cooldown_ticks=120,power=6)
add('spider','thorn_grapnel','铁棘攀索','tool','grapple','hook','瞄准12格内实心表面牵引自己，受方块碰撞限制，消耗耐久。',cooldown_ticks=100)
add('cave_spider','venom_twinblade','碧毒双锋','weapon','venom_blade','twin_blade','近战施加短毒；攻击已经中毒的目标可小幅恢复自己，恢复有冷却。',cooldown_ticks=120,power=5)
add('enderman','rift_crown','虚冠折跃器','tool','safe_blink','teleporter','沿视线短距折跃至可站立的安全位置；不穿墙、不传入方块内部。',cooldown_ticks=400)
add('slime','ruin_bounce_boots','遗迹弹跳靴','equipment','slime_bounce','slime_boots','减轻摔落；落地前潜行可把一次落差转为小弹跳，不能永久免疫坠落。',slot='feet')
add('witch','distillation_flask','秘釜分馏瓶','tool','distill_potion','bottle','处理副手药水：去除有害效果并小幅延长保留的低阶效果，每瓶只能处理一次。',cooldown_ticks=200)
add('silverfish','vein_mallet','裂岩寻脉镐','tool','vein_mine','pick','对矿石使用，连锁挖掘最多8块同种相邻矿石，遵守工具等级与正常掉落。',cooldown_ticks=80)
add('endermite','rift_needle','虚蚀取物针','tool','remote_pickup','needle','把视线附近的一件远处掉落物送至自己脚边；不能穿墙吸取容器物品。',cooldown_ticks=100)
add('pillager','siege_arbalest','铁弩督军重弩','weapon','siege_arrow','crossbow','真正的弩：命中产生有限击退，成品附快速装填II与耐久II。',durability=520,cooldown_ticks=0)
add('vindicator','breach_cleaver','断城斧','weapon','shield_cleaver','axe','命中正在格挡的目标可使盾牌短时失效；主动近身横扫，不破坏建筑。',cooldown_ticks=240,power=7)
add('evoker','fang_scepter','灾纹獠牙杖','weapon','fang_line','fangstaff','沿前方依次召出五段有延迟的獠牙；消耗耐久，不召唤额外Boss。',cooldown_ticks=320,power=6)
add('vex','wraith_saber','裂帛魂刃','weapon','wraith_dash','soulblade','主动短冲后，下一次近战附少量穿甲灵伤；效果仅消耗一次。',cooldown_ticks=280,power=5)
add('ravager','siege_stomp_boots','破寨冲锋靴','equipment','siege_charge','charge_boots','持续冲刺蓄力后推开挡路的敌人，消耗耐久并冷却；不撞毁方块。',slot='feet',cooldown_ticks=600)
add('phantom','eclipse_cloak','月蚀翼披','equipment','phantom_glide','cape','腾空下蹲时可主动展开短时滑降；与自动救援安全带用途不同。',slot='chest',cooldown_ticks=400)
add('breeze','windeye_staff','风眼弹射杖','tool','wind_launch','windstaff','消耗风弹向上弹射并推开近身敌人，附短时缓降保护。',cooldown_ticks=300)
add('creaking','rootbinding_staff','苍林根缚杖','weapon','root_bind','rootstaff','限制视线内一只敌人的移动数秒；近身攻击仍可能发生，不控制其他玩家。',cooldown_ticks=320,power=3)
add('warden','sonic_maul','深暗回声锤','weapon','sonic_wave','sonicmaul','释放窄直线声波，最多命中三名非玩家目标；伤害有限，冷却较长。',cooldown_ticks=500,power=7)
add('blaze','furnace_staff','炽环炉杖','weapon','blaze_bolt','firestaff','消耗烈焰粉发射炽热弹，点燃命中的生物；不会在地面放火。',cooldown_ticks=60,power=4)
add('ghast','weeping_cannon','泣焰手炮','weapon','ghast_shell','cannon','消耗火药发射沉重爆弹，命中产生实体冲击，不破坏地形。',cooldown_ticks=180,power=7)
add('magma_cube','magma_treaders','熔层踏火靴','equipment','lava_step','lava_boots','在熔岩表面短暂形成会恢复的踏脚石，每次耗耐久；不能永久改造熔岩湖。',slot='feet',durability=192)
add('wither_skeleton','ash_greatsword','灰烬骨巨剑','weapon','ash_blade','greatsword','近战附短时凋零，并对已有护甲的目标造成少量额外灵伤；有内置冷却。',cooldown_ticks=100,power=7)
add('piglin','redgold_crown','赤金通行冠','equipment','piglin_pass','crown','作为猪灵认可的金质护具；主动花费金锭短时安抚附近普通猪灵，不影响蛮兵。',slot='head',cooldown_ticks=1800)
add('piglin_brute','blackgold_axe','黑金断壁斧','weapon','brute_charge','blackaxe','主动蓄积一次重劈，下一次命中追加击退和伤害；不能连续储存。',cooldown_ticks=360,power=8)
add('zombified_piglin','gravegold_saber','朽金回魂刀','weapon','undead_reap','saber','亲手击败亡灵时恢复少量生命并解除饥饿；恢复有冷却。',cooldown_ticks=160,power=6)
add('hoglin','crimson_war_ration','绯林战备肉排','food','war_ration','ration','提供短时力量；低血量食用还获得少量吸收护心，但会短暂减速。',nutrition=12,duration_ticks=400)
add('zoglin','rotspine_scythe','腐脊长镰','weapon','rot_sweep','scythe','主动扫击前方多个近身目标并附短时虚弱；不造成永久减益。',cooldown_ticks=260,power=5)
add('shulker','crystal_pocket','紫晶随身匣','tool','pocket_vault','vault','真正的九格随身容器，内容保存在物品中；禁止容器套娃和放入自身。',durability=0,cooldown_ticks=0)

class Mesh:
    def __init__(self):self.elements=[]
    def box(self,x,y,z,w,h,d,m=0,angle=None,axis='z'):
        uv=[m%4*4,m//4*4,m%4*4+4,m//4*4+4]
        e={'from':[round(v,3) for v in (x,y,z)],'to':[round(v,3) for v in (x+w,y+h,z+d)],
           'faces':{f:{'uv':uv,'texture':'#atlas'} for f in ['north','south','east','west','up','down']}}
        if angle:e['rotation']={'origin':[8,8,8],'axis':axis,'angle':angle,'rescale':True}
        self.elements.append(e)
    def rod(self,x=7,y=0,z=7,h=14,m=1):
        self.box(x,y,z,2,h,2,m)
        for yy in range(int(y+2),int(y+h),3):self.box(x-.3,yy,z-.3,2.6,.55,2.6,3)
    def gem(self,x,y,z,m=2):
        self.box(x-1,y,z-1,2,3,2,m);self.box(x-1.5,y+.6,z-1.5,3,1.8,3,m)

def item_mesh(theme):
    m=Mesh()
    if theme=='shield':
        m.box(2,2,7,12,12,2,0);m.box(3,3,6.5,10,10,1,1)
        for s in (2,12):m.box(s,0,6,2,6,2,4);m.box(s,10,6,2,6,2,4)
        for x in (3,7,11):
            for y in (3,7,11):m.box(x,y,6,1.5,1.5,.8,3)
        m.box(6,5,9,4,6,2,1);m.gem(8,6,5,2)
    elif theme in ('cutlet','ration'):
        m.box(2,4,5,12,7,5,0);m.box(3,3,5.5,10,9,4,0);m.box(4,5,4.6,8,5,1,1)
        for x,y in ((4,5),(8,7),(11,5),(6,9)):m.box(x,y,4.2,2,1,1,2)
        m.box(11,7,3.8,4,2,1.4,4)
        if theme=='ration':m.box(1.5,3.5,7,13,1.2,2,3);m.box(7,2,6,2,12,2,3);m.box(6,6,4,4,3,1,2)
    elif theme in ('mantle','cape','harness'):
        m.box(3,2,7,10,11,2,1)
        for x in range(2,15,3):m.box(x,1,6,2.7,4,4,0);m.box(x,10,6.5,2.7,4,3,0)
        for y in range(4,11,3):m.box(2,y,6,2,3,3,0);m.box(12,y,6,2,3,3,0)
        if theme=='mantle':
            for x,y in [(5,5),(9,7),(7,10)]:m.gem(x,y,5,2)
        elif theme=='cape':
            for x in (0,14):
                for y in range(2,13,3):m.box(x,y,6,2,4,1.2,2)
        else:
            m.box(4,1,5,1.5,13,2,3);m.box(10.5,1,5,1.5,13,2,3);m.box(4,7,4,8,2,2,3);m.gem(8,7,3,2)
    elif theme=='fan':
        m.rod(7,0,7,6)
        for i in range(7):
            x=1+i*2;y=6+abs(i-3)*.5
            m.box(x,y,7,1.8,7-abs(i-3),1.5,0 if i%2 else 4)
            m.box(x+.4,y+2,6.7,.7,5-abs(i-3),2,2)
        m.gem(8,4,6,3)
    elif theme in ('rabbit_boots','mire_boots','slime_boots','charge_boots','lava_boots'):
        for x in (2,9):
            m.box(x,3,6,5,10,4,0);m.box(x,1,3,5,4,7,1);m.box(x-.3,.5,2.7,5.6,1.2,7.6,3)
            for y in (5,8,11):m.box(x+.5,y,5.5,4,1,1,4)
            if theme=='rabbit_boots':m.box(x+1,12,6,1,5,1.5,4);m.box(x+3,12,6,1,4,1.5,4)
            elif theme=='mire_boots':
                for y in (4,8):m.box(x-1,y,7,1.5,3,2,2)
            elif theme=='slime_boots':m.box(x+.5,2,2,4,3,2,2);m.box(x+1,6,4.8,3,2,1,2)
            elif theme=='charge_boots':m.box(x+1,4,1,3,2,3,4);m.box(x-1,8,7,2,4,3,3)
            else:
                for y in range(4,13,2):m.box(x-.4,y,5.5,5.8,1.3,5,1);m.box(x+1,y,5,3,.8,1,2)
    elif theme=='greaves':
        m.box(2,11,7,12,3,3,3)
        for x in (2,9):
            m.box(x,2,7,5,10,3,0);m.box(x-.5,5,6,6,4,2,1);m.gem(x+2.5,5.5,4.8,2)
            for i in range(4):m.box(x+i,8+i*.5,6,1,4,1.5,4)
    elif theme=='honeycomb':
        for x,y in [(4,3),(8,3),(2,7),(6,7),(10,7),(4,11),(8,11)]:
            m.box(x,y,6,3.5,3.5,3.5,0);m.box(x+.6,y+.6,5.5,2.3,2.3,.8,2)
        for x in (5,9):m.box(x,0,6,1,3,1,2)
    elif theme=='climbing_pick' or theme=='pick':
        m.rod(7,0,7,13);m.box(2,11,6,12,2,4,0)
        for s in (-1,1):m.box(7+s*5,9,6,2,4,4,4)
        if theme=='climbing_pick':m.box(3,7,7,2,4,2,2);m.box(1,6,7,4,2,2,2)
        else:m.gem(8,10,4.5,2);m.box(0,9,6.5,4,2,3,0)
    elif theme=='reins':
        for x in (3,11):m.box(x,1,7,1.5,12,1.5,1);m.box(x-1,0,6,3.5,2,3.5,3)
        m.box(3,12,7,9.5,2,2,0);m.box(3,5,7,9.5,1,1.5,1);m.gem(8,11,5.5,2)
        for y in (3,8):m.box(2.5,y,6.5,2.5,1.2,2.5,4);m.box(10.5,y,6.5,2.5,1.2,2.5,4)
    elif theme in ('satchel','pack','repair_kit','vault'):
        m.box(3,2,4,10,11,7,0);m.box(2.5,10,3.5,11,3,8,1)
        for x in (3,11):m.box(x,1,3,2,13,1.5,3)
        m.box(6.5,8,2.8,3,3,1,2);m.box(5,13,6,6,2,2,1)
        if theme=='pack':m.box(0,3,5,3,8,5,1);m.box(13,3,5,3,8,5,1);m.box(2,0,4,12,2,7,4)
        elif theme=='repair_kit':m.box(1,13,5,2,4,2,4);m.box(10,13,6,2,3,2,4);m.box(9,15,5,4,1,4,4)
        elif theme=='vault':
            for x in (2,12):
                for y in (1,12):m.box(x,y,3,2,2,9,2)
            m.box(2,7,3.5,12,1,8,3);m.gem(8,6,2,2)
        else:m.box(5,4,3,2,3,1,4);m.box(9,3,3,2,4,1,4)
    elif theme=='date':
        for x,y in [(3,3),(7,2),(10,5),(4,8),(8,9)]:m.box(x,y,6,4,5,3,0);m.box(x+1,y+1,5.5,2,3,1,2)
        m.box(2,1,7,12,1.5,3,1);m.box(3,12,7,10,1.5,2,4)
    elif theme in ('bell','songbell'):
        m.box(6,11,7,4,4,2,3);m.box(4,6,5,8,6,6,0);m.box(2,4,4,12,3,8,1);m.box(1,3,3,14,1.5,10,4)
        m.box(7,1,7,2,3,2,3);m.gem(8,7,4,2)
        if theme=='songbell':
            for x in (2,12):m.box(x,9,7,2,5,1,2);m.box(x-.5,8,6.5,3,2,2,2)
    elif theme in ('spear','needle'):
        m.rod(7,0,7,12);m.box(6,10,6,4,3,4,3)
        for j in range(4):m.box(5+j*.6,12+j*1.5,6.5,6-j*1.2,2,3,4 if j>1 else 0)
        if theme=='spear':m.box(3,9,7,10,1,2,2);m.box(4,7,7,2,3,2,4)
        else:m.box(9,4,7,3,.6,1,2);m.box(3,5,7,4,.6,1,2)
    elif theme in ('hood','crown'):
        m.box(2,4,4,12,9,8,0);m.box(4,5,3.5,8,6,1,1)
        m.box(4,4.5,3.1,8,6,1,(3 if theme=='hood' else 2));m.box(5,5,2.8,6,5,.5,1)
        for x in (2,12):m.box(x,4,2.5,2,9,2.5,4)
        if theme=='hood':m.box(2,12,4,3,5,3,0);m.box(11,12,4,3,5,3,0);m.box(6,11,3,4,2,1,2)
        else:
            for x in (2,5,8,11):m.box(x,12,4,2,4+(x%2),2,4)
            m.gem(8,11,2,2)
    elif theme in ('dagger','twin_blade','soulblade','greatsword','saber'):
        m.rod(7,0,7,5);m.box(3,4,6,10,1.5,4,3)
        width=3 if theme=='dagger' else 5 if theme=='greatsword' else 4
        m.box(8-width/2,5,7,width,10,2,0)
        for j in range(5):m.box(8-width/2-.2,5+j*2,6.6,width+.4,.65,2.8,4)
        m.box(7.4,6,6.5,1.2,8,1,2)
        if theme=='twin_blade':m.box(2,7,7,2,8,2,4);m.box(3,6,7,2,2,2,3)
        elif theme=='soulblade':
            for j in range(4):m.box(10,7+j*2,7,2,1.3,2,2)
        elif theme=='greatsword':m.box(4,7,7,2,3,2,1);m.box(10,11,7,2,3,2,1)
        elif theme=='saber':m.box(10,10,7,2,4,2,4);m.box(5,14,7,6,1.5,2,4)
    elif theme=='cookpot':
        m.box(3,2,4,10,8,8,0);m.box(2,9,3,12,2,10,1);m.box(4,11,5,8,1.5,6,4);m.box(7,12,7,2,2,2,3)
        for x in (0,13):m.box(x,6,6,3,3,4,3)
        for x in (4,8,11):m.box(x,0,5,1.5,3,5,2)
    elif theme in ('bamboo_staff','snow_staff','windstaff','rootstaff','firestaff','fangstaff'):
        m.rod(7,0,7,12);m.box(5,10,5,6,2,6,3);m.gem(8,12,7,2)
        if theme=='bamboo_staff':
            for x in (3,11):m.box(x,7,7,1.5,8,1.5,0);m.box(x-1,12,6.5,3,1,2,4)
        elif theme=='snow_staff':m.box(4,11,4,8,5,8,0);m.box(5,12,3.8,6,3,.5,2)
        elif theme=='windstaff':
            for x,y in [(2,12),(4,15),(9,15),(12,12)]:m.box(x,y,7,3,2,2,0)
        elif theme=='rootstaff':
            for x in (3,10):m.box(x,8,6,2,7,3,0);m.box(x-1,14,6,4,1.5,3,4)
        elif theme=='firestaff':
            for j in range(4):m.box(3+j*3,11+abs(j-1.5),6,2,5-abs(j-1.5),4,2 if j%2 else 4)
        else:
            m.box(2,10,6,3,6,3,4);m.box(11,10,6,3,6,3,4);m.box(4,12,6,8,2,3,0)
    elif theme in ('ice_chest','iron_chest'):
        m.box(3,3,6,10,10,4,0);m.box(1,10,5,4,5,6,1);m.box(11,10,5,4,5,6,1)
        for y in (4,7,10):m.box(4,y,5,8,2,1.5,4)
        m.gem(8,7,4,2)
        if theme=='ice_chest':
            for x in (1,13):m.box(x,13,6,2,5,2,2)
        else:
            for x,y in [(3,5),(11,8),(6,12)]:m.box(x,y,4.7,2,3,1,2)
    elif theme=='sonar':
        m.box(5,0,6,6,8,4,1);m.box(2,7,4,12,7,8,0);m.box(4,8,3.6,8,5,1,3);m.gem(8,9,2.8,2)
        for x in (1,13):m.box(x,11,6,2,5,4,4)
    elif theme=='whistle':
        m.box(5,2,6,6,11,4,0);m.box(4,12,5,8,2,6,4);m.box(7,0,7,2,3,2,3)
        for x,y in [(1,4),(2,7),(11,7),(12,4)]:m.box(x,y,6,3,6,2,2 if x<8 else 4)
        for y in (4,7,10):m.box(7,y,5.7,2,1.5,.8,1)
    elif theme in ('tongue','hook'):
        m.rod(7,0,7,6);m.box(4,6,6,8,2,4,3)
        m.box(3,8,7,2,6,2,0);m.box(3,13,7,9,2,2,0);m.box(11,8,7,2,6,2,0);m.box(9,7,7,4,2,2,4)
        if theme=='tongue':m.box(6,9,6.5,2,4,3,2);m.box(6,9,6,4,2,4,2)
        else:
            for x in (3,11):m.box(x-1,12,6.5,1,3,3,4)
            for y in (2,4):m.box(6.5,y,6.5,3,1,3,1)
    elif theme=='scute':
        for x in (2,9):
            m.box(x,2,6,5,12,3,1)
            for i in range(4):m.box(x-.5,3+i*2.5,5-i*.3,6,2.2,2,0);m.box(x,3+i*2.5,4.5-i*.3,5,.6,1,4)
    elif theme=='shovel':
        m.rod(7,0,7,11);m.box(4,9,6,8,6,4,0);m.box(5,14,6.5,6,2,3,4)
        for x in (5,8,11):m.box(x,10,5.5,1,3,1,2)
        m.box(6,1,6.5,4,2,3,3)
    elif theme in ('stew','broth'):
        m.box(3,3,4,10,4,8,1);m.box(2,6,3,12,3,10,0);m.box(3,8.5,4,10,.5,8,2)
        for x,y,z in [(5,9,6),(9,9,8),(11,9,5)]:m.box(x,y,z,2.5,1.5,2,4)
        if theme=='stew':m.box(5,10,7,1,2,1,3);m.box(3.5,12,6,4,1.5,3,4)
        else:m.box(8,9,5,2,4,1,3);m.box(7,12,4,4,1,3,4)
    elif theme=='spindle':
        m.rod(7,0,7,16);m.box(3,3,4,10,2,8,3);m.box(3,12,4,10,2,8,3)
        for y in range(5,12,2):m.box(4,y,5,8,1.5,6,0)
        m.box(5,6,4.5,6,5,1,2)
    elif theme=='seal':
        m.box(4,2,4,8,3,8,3);m.box(5,5,5,6,6,6,0);m.box(6,11,6,4,4,4,1);m.gem(8,14,7,2)
        for x,z in [(3,3),(11,3),(3,11),(11,11)]:m.box(x,2,z,2,2,2,4)
    elif theme=='map':
        m.box(2,3,7,12,10,.8,0)
        for x in (1,13):m.box(x,2,6,2,12,3,1);m.box(x-.4,1,5.6,2.8,2,3.8,4);m.box(x-.4,13,5.6,2.8,2,3.8,4)
        for x,y in [(4,5),(6,7),(9,8),(11,6)]:m.box(x,y,6.5,2,1,.7,3)
        m.gem(8,9,6,2)
    elif theme=='wrench':
        m.rod(7,0,7,10,0);m.box(4,9,6,8,3,4,3)
        for x in (3,11):m.box(x,11,6,2,5,4,0);m.box(x-.3,14,5.5,2.6,1,5,2)
        for y in (2,5,8):m.box(6.5,y,6.5,3,1,3,1)
    elif theme in ('hammer','sonicmaul'):
        m.rod(7,0,7,12);m.box(1,10,4,14,6,8,0)
        for x in (0,13):m.box(x,9.5,3.5,3,7,9,1)
        for x in (3,7,11):m.box(x,11,3.2,1.2,3,1,2)
        if theme=='sonicmaul':m.box(4,16,6,2,4,4,2);m.box(10,16,6,2,4,4,2);m.gem(8,10,2.5,4)
    elif theme=='plough':
        m.rod(7,0,7,11);m.box(1,10,6,14,2,4,0)
        for x in (1,4,7,10,13):m.box(x,8,6,1.5,6,4,4)
        m.box(6,6,6,4,2,4,3)
    elif theme in ('bow','frost_bow','crossbow','toxic_crossbow'):
        if 'crossbow' in theme:
            m.box(6.5,1,6.5,3,12,3,1);m.box(0,8,7,16,2,2,0);m.box(1,6,7,2,4,2,4);m.box(13,6,7,2,4,2,4)
            m.box(1,5,7.5,14,.5,1,3);m.box(7,12,6,2,3,4,2)
            if theme=='toxic_crossbow':m.box(3,10,6,2,4,4,2);m.box(11,10,6,2,4,4,2)
        else:
            for x,y,h in [(4,0,3),(7,2,4),(9,5,6),(7,10,4),(4,13,3)]:m.box(x,y,7,2,h,2,0)
            m.box(4.7,1,7.5,.5,14,1,3);m.gem(9,6,5.5,2)
            if theme=='frost_bow':
                for x,y in [(3,1),(8,4),(8,11),(3,14)]:m.box(x,y,6,1.5,3,3,4)
    elif theme in ('bombcaster','cannon'):
        m.box(4,1,7,4,7,3,1);m.box(3,7,4,10,6,8,0);m.box(2,8,2,12,4,3,3)
        m.box(4,9,1,8,2,1,1);m.box(5,12,6,6,3,4,4);m.gem(8,9,3,2)
        if theme=='bombcaster':m.box(1,6,6,3,8,5,1);m.box(12,6,6,3,8,5,1)
        else:
            for x in (3,11):m.box(x,6,4,2,8,8,4)
            m.box(6,3,6,4,2,2,2)
    elif theme=='teleporter':
        for x,y in [(3,2),(2,5),(3,10),(6,12),(10,10),(12,5),(9,2)]:m.box(x,y,6,3,3,4,0)
        m.box(6,4,7,4,7,2,2)
        for x,y in [(2,14),(8,15),(13,12)]:m.box(x,y,7,1.5,1.5,1.5,4)
    elif theme=='bottle':
        m.box(4,2,5,8,8,6,0);m.box(3,4,4,10,4,8,0);m.box(5,3,4.8,6,5,6.4,2)
        m.box(6,9,6,4,4,4,0);m.box(5.5,12,5.5,5,2,5,1);m.box(6,14,6,4,2,4,3)
        m.box(3.5,4,3.6,1,5,1,4)
    elif theme in ('axe','blackaxe','scythe'):
        m.rod(7,0,7,15);m.box(3,9,6,10,5,4,0)
        if theme=='scythe':m.box(0,13,7,12,2,2,4);m.box(-2,10,7,3,4,2,4);m.box(-3,8,7,2,3,2,4)
        elif theme=='blackaxe':m.box(1,8,5,4,8,6,1);m.box(12,10,6,3,5,4,4);m.gem(8,10,4.5,2)
        else:m.box(0,7,6,4,7,4,4);m.box(1,6,6,3,2,4,3)
    else:raise ValueError('Unauthored model theme '+theme)
    return m

def generate():
    upgrade(ITEMS)
    profiles=json.loads((RES/'boss_profiles.json').read_text());ids={p['entity'] for p in profiles}
    assert {i['source'] for i in ITEMS}==ids and len(ITEMS)==len(ids)
    colors={p['entity']:p['color'] for p in profiles}
    zh=json.loads((RES/'assets/worldbosses/lang/zh_cn.json').read_text());en=json.loads((RES/'assets/worldbosses/lang/en_us.json').read_text())
    display={'gui':{'rotation':[25,225,0],'translation':[0,0,0],'scale':[.72,.72,.72]},
             'ground':{'rotation':[0,0,0],'translation':[0,3,0],'scale':[.4,.4,.4]},
             'thirdperson_righthand':{'rotation':[0,90,-35],'translation':[0,1,0],'scale':[.85,.85,.85]},
             'firstperson_righthand':{'rotation':[0,-90,25],'translation':[1.2,2,1],'scale':[.75,.75,.75]},
             'head':{'rotation':[0,180,0],'translation':[0,0,0],'scale':[1,1,1]},
             'fixed':{'rotation':[0,180,0],'translation':[0,0,0],'scale':[.7,.7,.7]}}
    for item in ITEMS:
        mesh=item_mesh(item['model_theme']);item['model_elements']=len(mesh.elements)
        color=colors[item['source']];base=np.array([(color>>16)&255,(color>>8)&255,color&255])
        palette=[base,np.clip(base*.35,0,255),np.array([95,227,231]) if item['source'] not in ('pig','blaze','magma_cube','ghast','creeper') else np.array([255,153,43]),np.array([97,75,59]),np.array([235,225,193])]
        a=np.zeros((64,64,4),dtype=np.uint8);a[:,:,3]=255
        yy,xx=np.mgrid[:16,:16]
        for j,c in enumerate(palette):
            n=np.where((xx+yy*2)%7==0,13,-3)+np.where((xx%8==0)|(yy%8==0),9,0)
            a[j//4*16:j//4*16+16,j%4*16:j%4*16+16,:3]=np.clip(c[None,None,:]+n[:,:,None],0,255)
        texture=RES/f"assets/worldbosses/textures/item/{item['id']}.png";texture.parent.mkdir(parents=True,exist_ok=True)
        Image.fromarray(a).save(texture)
        model={'textures':{'atlas':'worldbosses:item/'+item['id'],'particle':'worldbosses:item/'+item['id']},'elements':mesh.elements,'display':display,'gui_light':'side'}
        for path,data in [(RES/f"assets/worldbosses/models/item/{item['id']}.json",model),
                          (RES/f"assets/worldbosses/items/{item['id']}.json",{'model':{'type':'minecraft:model','model':'worldbosses:item/'+item['id']}})]:
            path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(data,separators=(',',':'))+'\n')
        zh['item.worldbosses.'+item['id']]=item['zh_name'];en['item.worldbosses.'+item['id']]=item['en_name']
    (RES/'loot_v2.json').write_text(json.dumps({'items':ITEMS},ensure_ascii=False,indent=2)+'\n')
    for lang,data in [('zh_cn',zh),('en_us',en)]:
        (RES/f'assets/worldbosses/lang/{lang}.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
    # Crown is functional piglin-safe armor, in addition to its active gold-paid appeasement.
    p=RES/'data/minecraft/tags/item/piglin_safe_armor.json';p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps({'replace':False,'values':['worldbosses:v2_redgold_crown']})+'\n')
    lines=['# 逐种专属掉落：武器、工具、增益食物、装备','','每项均对应独立三维物品模型；以下描述由运行时清单同步生成。','','| 生物 | 分类 | 专属掉落 | 实际作用 |','|---|---|---|---|']
    names={p['entity']:p['name'] for p in profiles};cats={'weapon':'武器','tool':'工具','food':'增益食物','equipment':'装备'}
    for i in ITEMS:lines.append(f"| {names[i['source']]} | {cats[i['category']]} | {i['zh_name']} | {i['description_zh']} |")
    (ROOT/'design/loot-v2-catalog.md').write_text('\n'.join(lines)+'\n')
    print('Authored',len(ITEMS),'finished drops;',len({i['action'] for i in ITEMS}),'mechanics;',sum(i['model_elements'] for i in ITEMS),'3D item elements')

if __name__=='__main__':generate()
