#!/usr/bin/env python3
"""Material-atlas authoring pass for new skeletal geometry; creates original textures from scratch."""
from pathlib import Path
import json,hashlib,math,sys
import numpy as np
from PIL import Image
from check_v2_content import geometry_vertices

ROOT=Path(__file__).resolve().parents[1]
RES=ROOT/'src/main/resources'
OUT=RES/'assets/worldbosses/textures/entity/boss'
OUT.mkdir(parents=True,exist_ok=True)

def tile(material,seed):
    rng=np.random.default_rng(seed);y,x=np.mgrid[:256,:256]
    base=np.array([int(material['color'][i:i+2],16) for i in (1,3,5)],dtype=float)
    pat=material['pattern'];noise=rng.integers(-5,6,size=(64,64)).repeat(4,0).repeat(4,1).astype(float)
    shade=noise+np.where((x%8==0)|(y%8==0),-4,0)
    glow=np.zeros((256,256),dtype=np.uint8)
    if pat=='stone':
        seams=(y%8==7)|((x+(y//8%2)*4)%12==11);shade+=np.where(seams,-20,0)
        shade+=np.where((y%8==0)&~seams,10,0)
    elif pat in ('fur','wool'):
        shade+=np.where((x+(y//4%2)*2)%6==0,9,-1);shade+=np.where(y%5==4,-8,0)
    elif pat=='skin':shade+=np.where((x*3+y*7)%29==0,-9,0)
    elif pat=='metal':
        shade+=np.where((x%16==0)|(y%16==0),19,0);shade+=np.where((x%16==15)|(y%16==15),-20,0)
        shade+=np.where((x%16==2)&(y%16==2),32,0)
    elif pat=='ice':
        veins=((x+y*2)%19==0)|((x*3-y)%31==0);shade+=np.where(veins,35,0);glow=np.where(veins,130,45).astype(np.uint8)
    elif pat=='honey':
        seams=(y%10==0)|((x+(y//10%2)*5)%10==0);shade+=np.where(seams,28,-3);glow=np.where(seams,90,15).astype(np.uint8)
    elif pat=='glass':shade+=np.where((x+y)%17<2,45,0)
    elif pat=='bone':shade+=np.where((x*2+y)%19==0,-16,0);shade+=np.where(x%7==0,10,0)
    elif pat=='cloth':shade+=np.where((x+y)%2==0,4,-4);shade+=np.where(y%16==0,-14,0)
    elif pat=='wood':shade+=np.where((x+((y//9)%3))%6==0,-18,0)
    elif pat=='leaf':shade+=np.where((x//3+y//3)%3==0,12,-8)
    elif pat=='fire':
        fissure=(x%9==0)|((x+y*2)%17<2);shade+=np.where(fissure,45,-8);glow=np.where(fissure,240,100).astype(np.uint8)
    elif pat=='void':
        stars=(x*17+y*23)%113==0;shade+=np.where(stars,36,-5)
        if base.max()>100:glow=np.where(stars,230,110).astype(np.uint8)
    rgb=np.clip(base[None,None,:]+shade[:,:,None],0,255).astype(np.uint8)
    alpha=np.full((256,256,1),150 if pat=='glass' else 255,dtype=np.uint8)
    rgba=np.concatenate([rgb,alpha],2)
    # Opaque dark eyes are never self-lit. Explicit light/glow materials may use any pattern.
    name=material['name'].lower()
    if 'glint' in name or name in ('glow','soul','lava_hot'):
        glow=np.maximum(glow,170)
    if ('eye' in name and 'glint' not in name) or name in ('black','dark','nostril'):
        glow[:]=0
    emission=np.concatenate([rgb,np.asarray(glow,dtype=np.uint8)[:,:,None]],2)
    return rgba,emission

def finish():
    total=removed=0
    for path in sorted((RES/'assets/worldbosses/boss_models').glob('*.json')):
        model=json.loads(path.read_text());model['texture_size']=[1024,1024]
        unique=[];seen=set()
        for box in model['boxes']:
            key=json.dumps({k:box.get(k) for k in ('bone','from','size','rotation','pivot')},sort_keys=True)
            if key in seen:removed+=1;continue
            seen.add(key);unique.append(box)
        model['boxes']=unique
        core={**model,'boxes':[b for b in unique if b['bone'] in ('body','torso','head','neck','lower_shell')
              and model['palette'][b['material']]['pattern'] not in ('glass','ice','fire','void','leaf')]}
        if not core['boxes']:core={**model,'boxes':unique}
        vertices=[v for box in geometry_vertices(core) for v in box]
        width=max(max(v[0] for v in vertices)-min(v[0] for v in vertices),
                  (max(v[2] for v in vertices)-min(v[2] for v in vertices))*.65)/16
        height=(24-min(v[1] for v in vertices))/16
        overrides={'cow':[2.15,2.55],'pig':[2.15,2.9],'sheep':[2,2.55],'chicken':[1.35,2.45],
                   'wolf':[1.65,2.0],'bee':[1.7,1.5],'iron_golem':[2.1,4.45]}
        model['hitbox']=overrides.get(model['id'],[round(max(.6,min(3.5,width)),3),round(max(.7,min(4,height)),3)])
        path.write_text(json.dumps(model,ensure_ascii=False,separators=(',',':'))+'\n')
        atlas=np.zeros((1024,1024,4),dtype=np.uint8);emission=np.zeros_like(atlas)
        for i,material in enumerate(model['palette']):
            seed=int.from_bytes(hashlib.sha256((model['id']+material['name']).encode()).digest()[:8],'big')
            image,light=tile(material,seed);yy=i//4*256;xx=i%4*256
            atlas[yy:yy+256,xx:xx+256]=image;emission[yy:yy+256,xx:xx+256]=light
        Image.fromarray(atlas).save(OUT/(model['id']+'.png'),optimize=True)
        Image.fromarray(emission).save(OUT/(model['id']+'_emissive.png'),optimize=True)
        total+=len(unique)
    print('Finished',len(list((RES/'assets/worldbosses/boss_models').glob('*.json'))),'independent models;',total,'nonduplicate cuboids; removed',removed,'duplicate surfaces')

if __name__=='__main__':finish()
