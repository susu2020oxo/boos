#!/usr/bin/env python3
"""Deterministically draw ORIGINAL pixel sprites and write catalogs/recipes. No external images are edited."""
import json
import random
import struct
import zlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RES = ROOT / 'src/main/resources'
PROFILES = []

def profile(entity, name, attitude='passive', health=0, scale=1.3, ability='none',
            material=None, utility='resistance', color=0x78B898, drops=(), family=None):
    PROFILES.append(dict(entity=entity, name=name, attitude=attitude, health=health, scale=scale,
                         ability=ability, material=material or entity+'_essence', utility=utility,
                         color=color, family=family or entity,
                         vanilla=[dict(item='minecraft:'+i, min=lo, max=hi) for i,lo,hi in drops]))

profile('cow','磐角山君',health=16,material='rockhide',drops=[('beef',48,80),('leather',16,32)],color=0x888D75)
profile('pig','赤脊獠王',health=16,material='red_marrow',utility='regeneration',drops=[('porkchop',72,96)],color=0xE78791)
profile('sheep','霜绒领主',health=12,material='frost_fleece',utility='resistance',drops=[('mutton',40,64),('white_wool',12,24)],color=0xCAE8ED)
profile('chicken','赤冠天鸣',health=8,material='golden_feather',utility='slow_falling',drops=[('chicken',32,48),('feather',24,40)],color=0xEEC659)
profile('rabbit','月晶跃王',health=6,material='moon_hide',utility='jump_boost',drops=[('rabbit',16,32),('rabbit_hide',8,16)],color=0xD7BEDF)
profile('wolf','霜鬃狼王','neutral',scale=1.25,material='frost_mane',utility='resistance',color=0x9BC5E3)
profile('bee','琥珀蜂后','neutral',scale=1.5,material='amber_nectar',utility='regeneration',color=0xF3BD42)
profile('goat','崖角震主','neutral',scale=1.25,material='cliff_shard',utility='jump_boost',color=0xD8CC9B)
profile('horse','雷蹄战骏',material='storm_mane',utility='speed',drops=[('leather',12,24)],color=0x859ECD)
for entity,name in [('donkey','磐途驮王'),('mule','铁脊远征者'),('camel','沙丘行宫')]:
    profile(entity,name,material='sand_fiber',utility='resistance',drops=[('leather',12,24)],color=0xC7A172)
for entity,name in [('llama','彩毯高主'),('trader_llama','彩毯旅主')]:
    profile(entity,name,'neutral',material='prismatic_fiber',utility='speed',drops=[('leather',8,16)],color=0xCC9CA8)
profile('skeleton_horse','幽骨夜骏',material='soul_bone',utility='resistance',drops=[('bone',16,24)],color=0x9CCACA)
profile('zombie_horse','苔疫荒骏',material='blood_flesh',utility='regeneration',drops=[('rotten_flesh',16,32)],color=0x63845E)
for entity,name in [('cat','夜纹灵君'),('ocelot','金斑林影'),('fox','焰尾幻君')]:
    profile(entity,name,material='shadow_fur',utility='night_vision',color=0xBA84C8)
profile('panda','墨竹山主','neutral',material='bamboo_fiber',utility='regeneration',drops=[('bamboo',32,64)],color=0x83A66E)
profile('polar_bear','冰垒熊王','neutral',material='frost_fleece',utility='resistance',drops=[('cod',16,24)],color=0xC6E8EF)
profile('bat','回声夜翼',scale=1.6,material='echo_dust',utility='night_vision',color=0xA486C5)
profile('parrot','虹羽风君',scale=1.5,material='rainbow_feather',utility='slow_falling',drops=[('feather',12,24)],color=0x53C6BE)
profile('frog','沼冠蟾王',scale=1.5,material='marsh_dew',utility='jump_boost',color=0x9BBE6B)
profile('armadillo','赤砂堡垒',material='red_scute',utility='resistance',drops=[('armadillo_scute',4,8)],color=0xC28872)
profile('sniffer','古苔森主',material='ancient_seed',utility='regeneration',color=0x83A16B)
profile('mooshroom','绯菌牧主',health=16,material='fungal_hide',utility='regeneration',drops=[('beef',48,80),('leather',16,32),('red_mushroom',16,32)],color=0xCF6661)
profile('strider','熔绒渡主',material='thermal_thread',utility='fire_resistance',drops=[('string',24,40)],color=0xCC7774)
profile('allay','晶歌领主',health=24,scale=1.4,material='song_crystal',utility='slow_falling',color=0x78D8F4)
profile('villager','绿宝石议长',health=24,scale=1.15,material='village_seal',utility='regeneration',color=0x74C18A)
profile('wandering_trader','万宝旅主',health=24,scale=1.15,material='traveler_seal',utility='speed',color=0x759ED4)
profile('iron_golem','古藤铁卫','neutral',health=120,scale=1.12,material='vine_iron',utility='resistance',drops=[('iron_ingot',8,16),('poppy',8,16)],color=0xA4C694)
profile('snow_golem','霜灯守望',health=6,material='frost_crystal',utility='resistance',drops=[('snowball',32,64)],color=0xA9E4E9)
profile('happy_ghast','晴空云堡',health=24,scale=1.1,material='cloud_fiber',utility='slow_falling',color=0xBDDCF3)
profile('copper_golem','铜铸工坊长',health=24,material='copper_filament',utility='haste',color=0xBD8660)

profile('zombie','墓铠尸王','hostile',50,1.4,'slam','blood_flesh','regeneration',0x72995C,[('rotten_flesh',48,80)],'zombie')
profile('husk','沙葬古王','hostile',50,1.4,'slam','sand_fiber','resistance',0xC3AC75,[('rotten_flesh',48,80)],'zombie')
profile('zombie_villager','疫袍镇主','hostile',44,1.35,'slam','blood_flesh','regeneration',0x8A9E62,[('rotten_flesh',32,64)],'zombie')
profile('skeleton','冥骨猎王','hostile',44,1.4,'volley','soul_bone','resistance',0xAFD2CD,[('bone',48,80),('arrow',32,64)],'skeleton')
profile('stray','霜弦亡侯','hostile',44,1.4,'frost','frost_bone','resistance',0xA2D5EE,[('bone',40,64),('arrow',32,48)],'skeleton')
profile('bogged','毒苔弓主','hostile',40,1.4,'poison','toxic_bone','regeneration',0x8AA665,[('bone',32,64),('arrow',24,48)],'skeleton')
profile('creeper','裂核爆君','hostile',48,1.4,'blast','core_powder','strength',0x66B85C,[('gunpowder',32,64)])
profile('spider','铁棘蛛母','hostile',46,1.4,'leap','thorn_silk','slow_falling',0xAA4C58,[('string',32,64),('spider_eye',8,16)],'spider')
profile('cave_spider','碧毒穴母','hostile',40,1.6,'poison','toxic_silk','regeneration',0x63B58B,[('string',24,48),('spider_eye',8,16)],'spider')
profile('enderman','虚冠行者','hostile',64,1.18,'teleport','void_pearl','slow_falling',0xAC6DE1,[('ender_pearl',8,16)])
profile('slime','遗迹胶王','hostile',42,1.25,'pulse','elastic_slime','jump_boost',0x7DD875,[('slime_ball',24,48)])
profile('witch','秘釜巫后','hostile',54,1.35,'poison','concentrated_brew','regeneration',0xB783D1,[('redstone',16,32),('glowstone_dust',16,32),('sugar',16,32)])
profile('silverfish','裂岩虫皇','hostile',24,1.8,'slam','rock_segment','resistance',0xA2A6A1)
profile('endermite','虚蚀螨皇','hostile',24,1.8,'teleport','void_dust','night_vision',0xA67ECB)
profile('pillager','铁弩督军','hostile',48,1.3,'volley','reinforced_limb','strength',0xAA7D70,[('arrow',24,48)])
profile('vindicator','断城斧侯','hostile',60,1.3,'slam','cleaver_shard','strength',0x7C9EA9,[('emerald',1,3)])
profile('evoker','灾纹祭主','hostile',66,1.3,'pulse','calamity_paper','resistance',0xB9A665,[('emerald',2,4)])
profile('vex','裂帛怨灵','hostile',30,1.4,'leap','wraith_silk','slow_falling',0xA4DBE5)
profile('ravager','破寨巨兽','hostile',120,1.1,'slam','siege_hide','resistance',0x9D8C81,[('leather',24,40)])
profile('phantom','月蚀翼魇','hostile',44,1.5,'leap','eclipse_membrane','slow_falling',0x7E9AB8,[('phantom_membrane',8,16)])
profile('breeze','风眼领主','hostile',60,1.35,'wind','wind_core','jump_boost',0x9DCBD7,[('breeze_rod',8,16)])
profile('creaking','苍林诡主','hostile',0,1.2,'none','ancient_heart','resistance',0xC9BBA1)
profile('warden','深暗震主','hostile',500,1.08,'none','echo_core','resistance',0x4B9D9B)
profile('blaze','炽环炉主','hostile',48,1.35,'fire','blazing_rod','fire_resistance',0xE8AC4B,[('blaze_rod',8,16)])
profile('ghast','泣焰浮堡','hostile',36,1.12,'blast','molten_tear','regeneration',0xC7C6DA,[('ghast_tear',4,8),('gunpowder',24,48)])
profile('magma_cube','熔层霸主','hostile',48,1.25,'pulse','molten_cream','fire_resistance',0xE2884A,[('magma_cream',16,32)])
profile('wither_skeleton','灰烬剑侯','hostile',56,1.3,'slam','ash_bone','resistance',0x7A8991,[('bone',32,64),('coal',24,48)])
profile('piglin','赤金酋王','neutral',0,1.25,'none','redgold_shard','resistance',0xDBAE62,[('gold_nugget',16,32)])
profile('piglin_brute','黑金壁垒','hostile',64,1.25,'slam','blackgold_handle','strength',0xA88E56,[('gold_nugget',24,48)])
profile('zombified_piglin','朽金亡主','neutral',0,1.25,'none','decayed_gold','resistance',0xA0A76D,[('gold_nugget',16,32),('rotten_flesh',32,48)])
profile('hoglin','绯林獠主','hostile',60,1.25,'slam','thick_hide','resistance',0xC38576,[('porkchop',64,96),('leather',16,32)])
profile('zoglin','腐脊荒兽','hostile',60,1.25,'slam','rotted_bone','resistance',0xA69C80,[('rotten_flesh',48,80)])
profile('shulker','紫晶禁匣','hostile',48,1.25,'wind','crystal_shell','slow_falling',0xB68AC4,[('shulker_shell',2,4)])

def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n', encoding='utf-8')

class Sprite:
    def __init__(self,w=32,h=32):
        self.w,self.h=w,h; self.p=[[(0,0,0,0) for _ in range(w)] for _ in range(h)]
    def rect(self,x,y,w,h,c):
        for yy in range(max(0,y),min(self.h,y+h)):
            for xx in range(max(0,x),min(self.w,x+w)): self.p[yy][xx]=tuple(c)+(255,) if len(c)==3 else c
    def line(self,x1,y1,x2,y2,c,width=1):
        n=max(abs(x2-x1),abs(y2-y1),1)
        for t in range(n+1):self.rect(round(x1+(x2-x1)*t/n),round(y1+(y2-y1)*t/n),width,width,c)
    def save(self,path):
        path.parent.mkdir(parents=True,exist_ok=True)
        def chunk(t,d):return struct.pack('!I',len(d))+t+d+struct.pack('!I',zlib.crc32(t+d)&0xffffffff)
        raw=b''.join(b'\0'+bytes(c for px in row for c in px) for row in self.p)
        path.write_bytes(b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('!2I5B',self.w,self.h,8,6,0,0,0))+chunk(b'IDAT',zlib.compress(raw))+chunk(b'IEND',b''))

def rgb(v): return ((v>>16)&255,(v>>8)&255,v&255)
def shade(c,k):return tuple(min(255,int(v*k)) for v in c)

def egg_sprite(p):
    s=Sprite();c=rgb(p['color']);dark=shade(c,.32);rng=random.Random(p['entity'])
    for y in range(3,29):
        width=round(9*(1-((y-17)/16)**2)**.5) if abs(y-17)<16 else 0
        for x in range(16-width,17+width):
            edge=abs(x-16)>=width-1
            col=dark if edge or y==28 else shade(c,1.25 if x<13 else .85)
            s.rect(x,y,1,1,col)
    for _ in range(15):
        x,y=rng.randint(10,21),rng.randint(9,23);s.rect(x,y,2,2,shade(c,.55))
    # Pixelated stone/bone shell trim and signature face.
    s.rect(9,10,2,14,dark);s.rect(22,10,2,14,dark)
    s.rect(12,14,3,3,(29,24,36));s.rect(18,14,3,3,(29,24,36))
    if p['entity']=='creeper':
        s.rect(15,17,3,5,dark);s.rect(12,20,3,4,dark);s.rect(18,20,3,4,dark)
    elif p['entity'] in ('cow','pig','sheep','goat','hoglin'):
        s.rect(8,2,3,7,(230,221,190));s.rect(21,2,3,7,(230,221,190))
        s.rect(13,20,7,3,shade(c,1.4))
    elif p['entity']=='chicken':s.rect(14,0,4,5,(205,60,51))
    elif p['entity'] in ('wolf','cat','fox','ocelot'):
        s.rect(8,2,4,7,dark);s.rect(21,2,4,7,dark)
    elif p['entity'] in ('skeleton','stray','wither_skeleton','bogged'):
        s.rect(15,0,3,6,(87,233,235));s.line(7,25,23,7,(225,216,182),2)
    elif p['entity']=='bee':
        for y in (12,19,25):s.rect(9,y,15,2,(53,42,29))
        s.rect(3,11,4,7,(206,237,246,180));s.rect(26,11,4,7,(206,237,246,180))
    s.rect(12,6,3,2,shade(c,1.6));return s

def item_sprite(name,color):
    s=Sprite();c=rgb(color);dark=shade(c,.35);light=shade(c,1.35)
    if 'bone' in name and not any(x in name for x in ('helmet','chestplate','leggings','boots','bow','sword')):
        s.line(7,25,22,8,dark,5);s.line(8,24,23,7,(226,222,190),3)
        for x,y in [(5,22),(8,25),(21,4),(24,7)]:s.rect(x,y,4,4,(235,228,201))
        s.rect(14,15,2,2,(76,221,224))
    elif 'bow' in name:
        for x,y in [(9,3),(13,6),(17,10),(19,15),(17,20),(13,24),(9,27)]:s.rect(x,y,4,4,(225,218,188))
        s.line(9,4,9,29,(110,220,237));s.rect(19,13,3,4,(73,209,218))
    elif 'helmet' in name:
        s.rect(5,9,22,15,dark);s.rect(7,7,18,7,(228,223,193));s.rect(5,11,5,13,(217,209,177));s.rect(22,11,5,13,(217,209,177));s.rect(7,14,3,3,c);s.rect(23,14,3,3,c)
    elif 'chestplate' in name:
        s.rect(5,6,22,21,dark);s.rect(12,5,8,5,(0,0,0,0))
        for y in (10,15,20):s.rect(7,y,18,3,(223,218,188))
        s.rect(14,9,4,5,c)
    elif 'leggings' in name or 'boots' in name:
        s.rect(6,6,20,5,(225,218,188))
        for x in (6,19):s.rect(x,10,7,17,dark);s.rect(x+1,12,5,12,(225,218,188));s.rect(x+2,18,3,3,c)
    elif 'sword' in name:
        s.line(10,24,24,7,(225,218,188),4);s.line(7,25,12,20,dark,3);s.line(7,18,17,26,c,2)
    elif 'soup' in name:
        s.rect(5,14,22,7,(111,62,36));s.rect(8,21,16,5,(91,49,31));s.rect(6,12,20,5,(141,65,52));s.rect(11,10,5,4,(213,195,145));s.rect(20,11,3,2,(124,176,83))
    else:
        rng=random.Random(name)
        for y in range(6,27):
            for x in range(6,27):
                if (x-16)**2+(y-16)**2 < 95+rng.randrange(15):
                    s.rect(x,y,1,1,dark if x>23 or y>24 else c if rng.random()>.2 else shade(c,.7))
        s.rect(10,9,5,3,light);s.rect(17,16,3,6,shade(c,1.5))
    return s

def model(name,texture,namespace='worldbosses'):
    write(RES/f'assets/worldbosses/models/item/{name}.json',dict(parent='minecraft:item/generated',textures={'layer0':texture}))
    write(RES/f'assets/{namespace}/items/{name}.json',{'model':{'type':'minecraft:model','model':f'worldbosses:item/{name}'}})

def shaped(name,pattern,key,result,count=1):
    write(RES/f'data/worldbosses/recipe/{name}.json',{'type':'minecraft:crafting_shaped','category':'equipment',
          'pattern':pattern,'key':key,'result':{'id':result,'count':count}})

def shapeless(name,ingredients,result,count=1):
    write(RES/f'data/worldbosses/recipe/{name}.json',{'type':'minecraft:crafting_shapeless','category':'misc',
          'ingredients':ingredients,'result':{'id':result,'count':count}})

def generate():
    write(RES/'boss_profiles.json',PROFILES)
    zh={};en={};materials={}
    for p in PROFILES:
        name=p['material'];materials.setdefault(name,p)
        zh['entity.worldbosses.'+p['entity']]=p['name']
        # Replace vanilla egg appearance, preserving vanilla item identity, spawner interactions and placement.
        egg=p['entity']+'_spawn_egg'
        egg_sprite(p).save(RES/f'assets/worldbosses/textures/item/{egg}.png')
        model(egg,f'worldbosses:item/{egg}','minecraft')
        zh['item.minecraft.'+egg]=p['name']+' Boss 刷怪蛋'
    for name,p in materials.items():
        item_sprite(name,p['color']).save(RES/f'assets/worldbosses/textures/item/{name}.png')
        model(name,f'worldbosses:item/{name}')
        zh['item.worldbosses.'+name]=p['name']+'·精粹'
        en['item.worldbosses.'+name]=name.replace('_',' ').title()
    names={'blood_flesh':'凝血腐肉','soul_bone':'冥骨','core_powder':'裂核火药','thorn_silk':'铁棘蛛丝','void_pearl':'凝空珍珠',
           'elastic_slime':'韧性黏液','rockhide':'岩纹皮革','red_marrow':'赤髓精华','frost_fleece':'霜绒','golden_feather':'赤金羽毛',
           'purified_soup':'净化肉羹','bone_helmet':'冥骨头盔','bone_chestplate':'冥骨胸甲','bone_leggings':'冥骨护腿','bone_boots':'冥骨靴',
           'bone_sword':'冥骨剑','bone_bow':'冥骨弓','soul_longbow':'冥骨长弓'}
    for name,label in names.items():
        zh['item.worldbosses.'+name]=label;en['item.worldbosses.'+name]=name.replace('_',' ').title()
        if name not in materials:
            item_sprite(name,0x60D0D5 if name.startswith('bone') or 'bow' in name else 0xBD6A55).save(RES/f'assets/worldbosses/textures/item/{name}.png')
            model(name,f'worldbosses:item/{name}')
    zh['tooltip.worldbosses.relic']='右键消耗：%s I，持续 6 秒；精粹共享冷却 30 秒。'
    en['tooltip.worldbosses.relic']='Consume: %s I for 6s. All essences share a 30s cooldown.'
    write(RES/'assets/worldbosses/lang/zh_cn.json',zh);write(RES/'assets/worldbosses/lang/en_us.json',en)
    patterns={'helmet':['BBB','B B'],'chestplate':['B B','BBB','BBB'],'leggings':['BBB','B B','B B'],'boots':['B B','B B']}
    for slot,pattern in patterns.items():shaped('bone_'+slot,pattern,{'B':'worldbosses:soul_bone'},'worldbosses:bone_'+slot)
    shaped('bone_sword',['B','B','S'],{'B':'worldbosses:soul_bone','S':'minecraft:stick'},'worldbosses:bone_sword')
    shaped('bone_bow',[' BS','B S',' BS'],{'B':'worldbosses:soul_bone','S':'minecraft:string'},'worldbosses:bone_bow')
    shapeless('purified_soup',['worldbosses:blood_flesh']*4+['minecraft:brown_mushroom','minecraft:bowl'],'worldbosses:purified_soup')
    shapeless('bone_meal',['worldbosses:soul_bone'],'minecraft:bone_meal',6)
    for material in ('frost_bone','ash_bone','toxic_bone','rotted_bone'):
        shapeless(material+'_to_bone',['worldbosses:'+material],'worldbosses:soul_bone')
    # Every profile material has a useful consumable effect; these additionally retain explicit vanilla uses.
    for special,vanilla,count in [('thorn_silk','string',3),('rockhide','leather',2),('golden_feather','feather',2),
                                  ('blazing_rod','blaze_powder',3),('molten_cream','magma_cream',2),('crystal_shell','shulker_shell',1),
                                  ('wind_core','wind_charge',4),('thermal_thread','string',3),('copper_filament','copper_ingot',1)]:
        shapeless(special+'_processing',['worldbosses:'+special],'minecraft:'+vanilla,count)
    # Original equipment textures, independent from the vanilla armor atlas.
    for layer in ('humanoid','humanoid_leggings'):
        s=Sprite(64,32)
        for y in range(32):
            for x in range(64):
                c=(45,53,58) if x%8==0 or y%7==0 else (217,214,187)
                if (x%16==5 and y%8 in (3,4)):c=(80,215,224)
                s.rect(x,y,1,1,c)
        s.save(RES/f'assets/worldbosses/textures/entity/equipment/{layer}/soul_bone.png')
    write(RES/'assets/worldbosses/equipment/soul_bone.json',{'layers':{layer:[{'texture':'worldbosses:soul_bone'}] for layer in ('humanoid','humanoid_leggings')}})
    print(f'Generated {len(PROFILES)} profiles, {len(materials)} unique materials, eggs, recipes and original pixel sprites.')

if __name__=='__main__':generate()
