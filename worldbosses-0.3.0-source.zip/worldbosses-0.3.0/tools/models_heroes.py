#!/usr/bin/env python3
"""Six individually sculpted boss silhouettes from the approved wildlife sheet.

The geometry, skeletal proportions and material assignments are original.  Nothing
is copied from Minecraft model data; only the game's cuboid vocabulary is used.
Run from any directory to regenerate these six files only.
"""
from __future__ import annotations

import json
import math
from pathlib import Path

OUT = Path(__file__).resolve().parents[1] / "src/main/resources/assets/worldbosses/boss_models"


class Sculpture:
    def __init__(self, entity, palette, features):
        self.data = {"id": entity, "texture_size": [1024, 1024],
                     "reference_features": features, "palette": palette,
                     "bones": [], "boxes": []}
        self.materials = {p["name"]: i for i, p in enumerate(palette)}

    def bone(self, name, pivot=(0, 0, 0), parent="torso", rotation=(0, 0, 0), animation="none"):
        self.data["bones"].append({"name": name, "parent": parent,
                                   "pivot": list(pivot), "rotation": list(rotation), "animation": animation})
        return name

    def box(self, bone, xyz, size, material, rotation=None, pivot=None):
        if min(size) <= 0:
            raise ValueError((self.data["id"], size))
        box = {"bone": bone, "from": [round(v, 3) for v in xyz],
               "size": [round(v, 3) for v in size], "material": self.materials[material]}
        if rotation:
            box["rotation"] = [round(v, 3) for v in rotation]
            box["pivot"] = list(pivot or [xyz[i] + size[i] / 2 for i in range(3)])
        self.data["boxes"].append(box)

    def beam(self, bone, start, end, width, material, depth=None):
        """A cuboid between two deliberately placed skeletal points, not a smooth cylinder."""
        delta = [end[i] - start[i] for i in range(3)]
        length = math.sqrt(sum(v * v for v in delta))
        center = [(start[i] + end[i]) / 2 for i in range(3)]
        pitch = math.degrees(math.atan2(delta[2], math.hypot(delta[0], delta[1])))
        roll = -math.degrees(math.atan2(delta[0], delta[1]))
        depth = width if depth is None else depth
        self.box(bone, (center[0] - width / 2, center[1] - length / 2, center[2] - depth / 2),
                 (width, length, depth), material, (pitch, 0, roll), center)

    def save(self):
        OUT.mkdir(parents=True, exist_ok=True)
        path = OUT / (self.data["id"] + ".json")
        path.write_text(json.dumps(self.data, ensure_ascii=False, separators=(",", ":")) + "\n")
        return path


def mat(name, color, pattern):
    return {"name": name, "color": color, "pattern": pattern}


def cow():
    m = Sculpture("cow", [
        mat("charcoal_hide", "#26252B", "skin"), mat("white_hide", "#E8E3D3", "skin"),
        mat("hide_shadow", "#484148", "skin"), mat("muzzle", "#D99294", "skin"),
        mat("muzzle_light", "#EFB1AD", "skin"), mat("basalt", "#36383D", "stone"),
        mat("basalt_edge", "#55565B", "stone"), mat("basalt_dark", "#202229", "stone"),
        mat("horn_ivory", "#EDE0BC", "bone"), mat("horn_tip", "#FFF0CB", "bone"),
        mat("horn_root", "#A39172", "bone"), mat("moss", "#637F2F", "leaf"),
        mat("moss_light", "#93A84A", "leaf"), mat("hanging_vine", "#3F5E28", "leaf"),
        mat("eye", "#11151C", "void"), mat("eye_glint", "#FFFEF0", "glass")],
        ["black/white bovine body", "layered basalt shoulder cliffs", "two monumental ivory horns",
         "moss and hanging vines", "wide stone-plated split hooves", "pink block muzzle"])
    m.bone("torso", parent="root", animation="body")
    m.bone("head", (0, 1, -22), animation="head")
    m.bone("jaw", (0, 4, -7), parent="head", animation="jaw")
    m.box("torso", (-12, -7, -19), (24, 18, 38), "charcoal_hide")
    m.box("torso", (-11, 9, -15), (22, 4, 29), "white_hide")
    m.box("torso", (-12.2, -5, -16), (1, 13, 11), "white_hide")
    m.box("torso", (11.2, -6, 2), (1, 14, 12), "white_hide")
    # Individually arranged patch plates follow the flanks rather than a tiled noise blanket.
    for s, patches in [(-1, [(-12, -2, 5, 8), (-5, 2, 8, 7), (6, -5, 7, 9), (12, 3, 5, 5)]),
                       (1, [(-13, 1, 6, 8), (-3, -4, 8, 6), (8, 2, 9, 9)])]:
        for z, y, length, height in patches:
            m.box("torso", ((-12.45 if s < 0 else 11.9), y, z), (.55, height, length), "white_hide")
    # Forechest drops beneath the armor to give the massive high-shouldered silhouette.
    m.box("torso", (-9, -2, -23), (18, 15, 7), "charcoal_hide")
    m.box("torso", (-5, 7, -23.4), (10, 7, 1), "white_hide")
    # Basalt mantle: separated overlapping blocks, several real stepped courses.
    for side in (-1, 1):
        x = -16 if side < 0 else 10
        for course, (y, width, depth) in enumerate([(-11, 6, 18), (-7, 7, 21), (-2, 6, 19)]):
            for lane in range(4):
                z = -18 + lane * 5.0 + (1 if course % 2 else 0)
                xx = x - (.6 if side < 0 and course == 1 else 0)
                m.box("torso", (xx, y, z), (width, 4.4, 4.7), "basalt" if (lane + course) % 2 else "basalt_edge")
                m.box("torso", (xx - .15, y + 3.8, z), (width + .3, .55, 4.7), "basalt_dark")
        # Shoulder crown and a long outer cheek to make the mountain armor hang visibly.
        m.box("torso", (-16 if side < 0 else 10, -14, -14), (6, 4, 11), "basalt_dark")
        m.box("torso", (-17 if side < 0 else 14, 1, -17), (3, 10, 8), "basalt")
        m.box("torso", (-17.3 if side < 0 else 16.8, 4, -17), (.5, 5, 8), "basalt_edge")
    for z, width, rise in [(-15, 19, -13), (-9, 22, -12), (-3, 24, -10), (3, 21, -9), (9, 19, -9), (14, 16, -8)]:
        m.box("torso", (-width / 2, rise, z), (width, 4, 5), "basalt")
        m.box("torso", (-width / 2 + 1, rise - .65, z + .6), (width - 2, .8, 3.5), "basalt_edge")
    for x, z, height in [(-10,-14,4),(9,-10,3),(-8,-5,3),(7,1,2),(-7,7,2),(5,13,3)]:
        surface={-14:-13,-10:-13,-5:-12,1:-10,7:-9,13:-9}[z]
        m.box("torso", (x - 1.5, surface - height, z), (3, height + 1, 4), "basalt_dark")
    # Moss covers selected upper faces; dangling stems are attached to those faces.
    moss_sites = [(-16,-11,-16,5,5),(-13,-14,-11,5,6),(11,-13,-13,4,7),
                  (-10,-13,-3,6,5),(7,-11,2,5,5),(-8,-10,11,5,5),(10,-9,13,5,4)]
    for i, (x,y,z,w,d) in enumerate(moss_sites):
        m.box("torso", (x,y-.4,z), (w,.7,d), "moss")
        m.box("torso", (x+1,y-.85,z+1), (max(1,w-2),.6,max(1,d-2)), "moss_light")
        for dx, length in [(0,6+(i%4)),(w-1,4+(i%3))]:
            m.box("torso", (x+dx,y,z+.2), (.65,length,.7), "hanging_vine")
            m.box("torso", (x+dx-.5,y+length-2,z-.1), (1.7,1.3,1.1), "moss")
    # Outer trailing growth stays outside the cliff mantle, so it is visible from the sides.
    for side in (-1,1):
        for index,z in enumerate((-16,-10,-4,8,15)):
            edge=(17.5 if z<-8 else 16.9 if z<2 else 12.9)
            x=side*edge;y=-8 if z<2 else -4;length=10+index%3*2
            m.box("torso",(x-1.7,y-1,z-1),(3.4,2.2,3.1),"moss")
            m.box("torso",(x-.3,y,z),(.65,length,.7),"hanging_vine")
            for dy,shift in ((3,-.5),(length-2,.4)):
                m.box("torso",(x-.9+shift,y+dy,z-.4),(1.9,1.3,1.5),"moss_light" if dy==3 else "moss")
    # Broad square head, clear front-facing eyes and muzzle.
    m.box("head", (-8,-6,-9), (16,15,15), "charcoal_hide")
    m.box("head", (-3,-6,-9.2), (6,8,.5), "white_hide")
    m.box("head", (-7,2,-11), (14,7,4), "muzzle")
    m.box("head", (-6,2,-11.4), (12,2,.7), "muzzle_light")
    for side in (-1,1):
        x = -6.3 if side < 0 else 3.7
        m.box("head", (x,-3,-9.6), (2.8,2.7,.8), "eye")
        m.box("head", (x+.45,-2.75,-10.05), (.8,.8,.5), "eye_glint")
        m.box("head", ((-5 if side<0 else 2),4,-11.6), (3,1.8,.6), "charcoal_hide")
        m.box("head", ((-13 if side<0 else 8),-4,-3), (5,3,5), "charcoal_hide", (0,0,side*10))
        m.box("head", ((-12 if side<0 else 9),-3.6,-3.4), (3,1.3,3), "muzzle")
        # Four narrowing square growth stages give the horns a deliberate stepped taper.
        hx = side*7
        for y,w,h,d,z,material in [(-10,4,5,4,-4,"horn_root"),(-20,3.5,11,3.5,-5,"horn_ivory"),
                                  (-26,2.6,7,2.6,-6,"horn_ivory"),(-30,1.5,5,1.5,-7,"horn_tip")]:
            m.box("head", (hx-w/2,y,z-d/2), (w,h,d), material)
        for y in (-13,-18,-23):
            m.box("head", (hx-1.85,y,-6.9), (3.7,.45,3.8), "horn_tip")
        # Rock collar roots the horns into the head and connects to the body mantle.
        m.box("head", (hx-3,-9,-4.8), (6,3,7), "basalt")
        m.box("head", (hx-2,-10,-3.8), (4,1.2,5), "moss")
    m.box("jaw", (-5,0,-3), (10,4,6), "charcoal_hide")
    m.box("jaw", (-4,3.4,-2.8), (8,.8,5), "white_hide")
    for name,x,z,phase in [("leg_fl",-10,-14,"leg_fl"),("leg_fr",10,-14,"leg_fr"),
                           ("leg_hl",-10,14,"leg_hl"),("leg_hr",10,14,"leg_hr")]:
        m.bone(name,(x,8,z),animation=phase)
        m.box(name,(-3,0,-3),(6,11,6),"charcoal_hide")
        m.box(name,(-3.5,1,-3.5),(7,5,7),"white_hide" if x*z<0 else "hide_shadow")
        m.box(name,(-4,6,-4),(8,4.5,8),"basalt_dark")
        m.box(name,(-5,10,-5),(10,6,10),"basalt")
        m.box(name,(-5.2,10,-5.2),(10.4,1.4,10.4),"basalt_edge")
        for xx in (-4.5,.4):
            m.box(name,(xx,13,-5.4),(4.1,3.2,.8),"basalt_dark")
            m.box(name,(xx+.5,12.3,-5.6),(3,1.2,.8),"basalt_edge")
        m.box(name,(-3,9,-4.1),(2.5,.8,2.2),"moss")
    m.bone("tail",(0,3,19),animation="tail")
    m.box("tail",(-1.2,0,0),(2.4,11,2.4),"white_hide",(-18,0,0))
    m.box("tail",(-2.5,8,2),(5,5,4),"charcoal_hide")
    return m


def pig():
    m = Sculpture("pig", [
        mat("pink", "#ECA5A5", "skin"),mat("pink_light", "#FFC1BC", "skin"),
        mat("pink_shadow", "#C87D86", "skin"),mat("nose", "#DF8D95", "skin"),
        mat("nostril", "#6E3E49", "void"),mat("rock", "#423A3D", "stone"),
        mat("red_rock", "#6B4340", "stone"),mat("rock_edge", "#966151", "stone"),
        mat("rock_dark", "#25262B", "stone"),mat("lava", "#F58625", "fire"),
        mat("lava_hot", "#FFD26B", "fire"),mat("ivory", "#EFE3C5", "bone"),
        mat("ivory_tip", "#FFF1D6", "bone"),mat("eye", "#181522", "void"),
        mat("eye_glint", "#FFF3E7", "glass"),mat("tusk_root", "#B49E7D", "bone")],
        ["broad pink block snout", "four independent ivory tusks", "overlapping volcanic dorsal plates",
         "orange fissures between dark red rock", "plated short legs", "folded pink ears"])
    m.bone("torso",parent="root",animation="body")
    m.bone("head",(0,2,-21),animation="head")
    m.bone("jaw",(0,7,-7),parent="head",animation="jaw")
    m.box("torso",(-13,-7,-19),(26,18,38),"pink")
    m.box("torso",(-11,8,-15),(22,5,30),"pink_shadow")
    m.box("torso",(-11,-7,-17),(22,2,34),"pink_light")
    # Heavy overlapping red-rock saddle. Each plate has an edge, dark fracture and hot seam.
    for side in (-1,1):
        for i,z in enumerate((-16,-9,-2,5,12)):
            x=-15 if side<0 else 9
            y=-10+(i%2)
            m.box("torso",(x,y,z),(6,5,6.5),"red_rock" if i%2 else "rock")
            m.box("torso",(x-.25,y+4,z),(6.5,1.1,6.5),"rock_dark")
            m.box("torso",(x+.4,y-.8,z+.4),(5.2,1.1,5.4),"rock_edge")
            m.box("torso",(x+(0 if side<0 else 5.5),y+1,z+.5),(.55,3.6,4.9),"lava")
            if i in (0,2,4):
                m.box("torso",(x+(0 if side<0 else 3),y+4,z+1),(3,6.8,4.6),"rock")
                m.box("torso",(x+(0 if side<0 else 5.4),y+5,z+2),(.6,4.8,1),"lava_hot")
    for i,z in enumerate((-16,-10,-4,2,8,14)):
        width=14 if i in (1,2,3) else 12
        height=(8,11,13,11,8,6)[i]
        m.box("torso",(-width/2,-11,z),(width,4,5.6),"rock_dark")
        m.box("torso",(-width/2+.4,-12,z+.4),(width-.8,2,4.8),"red_rock")
        m.box("torso",(-4,-11-height,z+.6),(8,height,4.5),"rock")
        m.box("torso",(-3,-14-height,z+1),(6,4,3.7),"red_rock")
        m.box("torso",(-1.3,-17-height,z+1.5),(2.6,4,2.6),"rock_edge")
        m.box("torso",(-4.3,-8-height,z+1),(1,height-1,1.2),"lava")
        m.box("torso",(-3.4,-10-height,z+1),(1,3.2,1.2),"lava_hot")
    for x,z,y in [(-9,-11,-8),(8,-4,-8),(-7,3,-8),(6,11,-7)]:
        m.box("torso",(x,y,z),(2.2,1,5),"lava")
        m.box("torso",(x+.5,y-.4,z+1),(.8,.8,2),"lava_hot")
    # Snout is wider than the forehead and has layered nostril rims.
    m.box("head",(-10,-6,-9),(20,16,17),"pink")
    m.box("head",(-8,-7,-8),(16,2.2,12),"pink_light")
    m.box("head",(-10,-1,-16),(20,9,8),"nose")
    m.box("head",(-9,-1.5,-16.5),(18,2.2,.9),"pink_light")
    m.box("head",(-9,6.7,-16.5),(18,1.6,.9),"pink_shadow")
    for x in (-6.8,3):
        m.box("head",(x,1.1,-17),(3.8,3.8,.8),"pink_shadow")
        m.box("head",(x+.6,1.6,-17.3),(2.6,2.5,.6),"nostril")
    for side in (-1,1):
        ex=-8.8 if side<0 else 5.6
        m.box("head",(ex,-3.8,-9.6),(3.2,2.7,.8),"eye")
        m.box("head",(ex+.5,-3.5,-10.1),(.9,.9,.6),"eye_glint")
        m.box("head",(ex-1,-5.2,-9.4),(5.1,1.5,1.7),"pink_shadow",(0,0,side*8))
        m.bone("ear_"+str(side),(side*9,-5,-1),parent="head",rotation=(0,0,side*22))
        m.box("ear_"+str(side),(-3,-6,-1),(6,8,3),"pink_shadow")
        m.box("ear_"+str(side),(-2.1,-5,-1.3),(4.2,5.6,.7),"pink_light")
        # Large outer pair: first straight root, then upturned and narrowing ivory sections.
        hx=side*11.5
        m.box("head",(hx-2,3,-13),(4,6,4),"tusk_root",(0,0,-side*12))
        m.beam("head",(hx,6,-12),(hx+side*1.5,-3,-16),3.5,"ivory")
        m.beam("head",(hx+side*1.5,-3,-16),(hx+side*1.2,-10,-18),2.5,"ivory_tip")
        m.box("head",(hx+side*.7-1,-13,-19),(2,4,2),"ivory_tip")
        # Inner pair starts at the bottom lip and bends farther toward the viewer.
        ix=side*5.7
        m.box("jaw",(ix-1.8,0,-7),(3.6,4.6,4),"tusk_root")
        m.beam("jaw",(ix,3,-6),(ix+side*1.2,-3,-10),3.2,"ivory")
        m.beam("jaw",(ix+side*1.2,-3,-10),(ix+side*1.7,-7,-11),2,"ivory_tip")
    m.box("jaw",(-8,0,-6),(16,4,9),"pink_shadow")
    m.box("jaw",(-7,3,-6),(14,1.5,8),"pink")
    for name,x,z in [("leg_fl",-10,-13),("leg_fr",10,-13),("leg_hl",-10,13),("leg_hr",10,13)]:
        m.bone(name,(x,11,z),animation=name)
        m.box(name,(-3,0,-3),(6,8,6),"pink")
        m.box(name,(-4,5,-4),(8,3,8),"rock_dark")
        m.box(name,(-4.7,7,-4.7),(9.4,6,9.4),"rock")
        for xoff in (-4.4,.5):
            m.box(name,(xoff,9,-5),(3.9,4,1),"red_rock")
            m.box(name,(xoff+.4,8.3,-5.4),(3.1,1,1),"rock_edge")
        m.box(name,(-.55,7.8,-5.5),(1.1,4.4,.8),"lava")
        m.box(name,(-4.9,7.4,-3),(1,1,5),"lava_hot")
    m.bone("tail",(0,3,19),animation="tail")
    for xyz,size in [((-1,0,0),(2,2,5)),((-1,-3,3),(2,4,2)),((-1,-3,1),(2,2,3))]:
        m.box("tail",xyz,size,"pink_shadow")
    return m


def sheep():
    m = Sculpture("sheep", [
        mat("wool", "#E8E6DC", "wool"),mat("wool_light", "#FFFBEF", "wool"),
        mat("wool_shadow", "#C7C6C1", "wool"),mat("face", "#555963", "fur"),
        mat("face_shadow", "#383C45", "fur"),mat("muzzle", "#A49A99", "skin"),
        mat("horn", "#73716B", "stone"),mat("horn_ridge", "#96928A", "stone"),
        mat("horn_dark", "#4D4D4D", "stone"),mat("ice", "#A1D7F2", "ice"),
        mat("ice_light", "#D7F2FB", "ice"),mat("ice_blue", "#6BA8E2", "ice"),
        mat("hoof", "#34363F", "stone"),mat("nose", "#D9A6AB", "skin"),
        mat("eye", "#121823", "void"),mat("eye_glint", "#FFFFFF", "glass")],
        ["cascading cliff-like white fleece", "two massive squared spiral ram horns",
         "dark gray face", "sparse blue ice clusters", "dark short hooves"])
    m.bone("torso",parent="root",animation="body")
    m.bone("head",(0,0,-21),animation="head")
    m.box("torso",(-11,-7,-16),(22,19,32),"wool_shadow")
    # A layered pelt with separated stepped locks, rather than a scaled-up vanilla wool cube.
    for z_index,z in enumerate((-16,-10,-4,2,8,14)):
        for x_index,x in enumerate((-10,-5,0,5)):
            rise=1.2 if (x_index+z_index)%3==0 else 0
            m.box("torso",(x,-10-rise,z),(4.8,5.3+rise,5.6),"wool_light" if (x_index+z_index)%2 else "wool")
    for side in (-1,1):
        for row,y in enumerate((-6,-1,4)):
            for column,z in enumerate((-17,-12,-7,-2,3,8,13)):
                xx=(-14.4+row*.5 if side<0 else 9.5-row*.5)
                depth=4.7 if column%2 else 5.4
                m.box("torso",(xx,y,z),(4.9,5.5,depth),"wool" if (row+column)%3 else "wool_light")
                if row==2:
                    m.box("torso",(xx+.5,y+4.5,z+.4),(3.6,4+(column%3),3.8),"wool_light")
        for z,length in [(-14,8),(-4,9),(6,7),(13,6)]:
            m.box("torso",((-12.5 if side<0 else 9.2),6,z),(3.5,length,3.8),"wool_shadow")
    for x in (-7,-2,3,8):
        m.box("torso",(x,1,-19.4),(4.4,9,4.2),"wool_light")
        m.box("torso",(x,1,15.3),(4.4,10,4.2),"wool")
    # Crystals grow out of the fleece; taller trunks have asymmetric blue facets.
    for i,(x,z,h) in enumerate([(-7,-13,8),(4,-9,5),(-3,-4,10),(7,1,7),(-8,4,6),(0,9,11),(7,14,5)]):
        y=-10
        m.box("torso",(x-2,y-h,z-2),(4,h+1,4),"ice",(0,(i%3-1)*12,(i%2*2-1)*7))
        m.box("torso",(x-1.1,y-h-3,z-1.1),(2.2,4,2.2),"ice_light")
        m.box("torso",(x-2.1,y-h+1,z-2.2),(1.1,max(2,h-2),1),"ice_blue")
        m.box("torso",(x+1,y-3,z),(2.4,3.4,2.6),"ice_light",(0,0,18))
    m.box("head",(-6,-5,-9),(12,13,11),"face")
    m.box("head",(-5,4,-11),(10,5,3),"muzzle")
    m.box("head",(-2,5,-11.6),(4,2,.8),"nose")
    m.box("head",(-7,-9,-8),(14,5,12),"wool")
    for x,z in [(-7,-7),(-3,-9),(1,-9),(5,-7)]:
        m.box("head",(x,-10.5,z),(4.5,4,4.5),"wool_light")
    for side in (-1,1):
        ex=-5.6 if side<0 else 2.7
        m.box("head",(ex,-1,-9.5),(2.9,2.8,.8),"eye")
        m.box("head",(ex+.45,-.75,-9.95),(.8,.8,.5),"eye_glint")
        m.box("head",((-10 if side<0 else 5),-1,-2),(5,3,4),"face",(0,0,side*12))
        # A deliberately square spiral in the Y/Z plane, built from distinct joined sections.
        path=[(-5,0),(-10,-1),(-13,-6),(-12,-11),(-7,-15),(-1,-16),(4,-12),(5,-7),(2,-4),(-1,-6)]
        hx=side*9.3
        m.box("head",(hx-2.7,-8,-2),(5.4,6,5),"horn_dark")
        for i in range(len(path)-1):
            a,b=path[i],path[i+1]
            width=4.6-i*.17
            m.beam("head",(hx,a[0],a[1]),(hx,b[0],b[1]),width,"horn" if i%2 else "horn_ridge")
            # Thin raised growth bands emphasize the curls in side view.
            cy=(a[0]+b[0])/2;cz=(a[1]+b[1])/2
            m.box("head",(hx-width/2-.15,cy-.4,cz-width/2-.15),(width+.3,.85,width+.3),"horn_dark")
        m.box("head",(hx-1.2,-2,-7.2),(2.4,2.4,2.4),"horn_ridge")
    for name,x,z in [("leg_fl",-8,-12),("leg_fr",8,-12),("leg_hl",-8,12),("leg_hr",8,12)]:
        m.bone(name,(x,12,z),animation=name)
        m.box(name,(-2,0,-2),(4,9,4),"face")
        m.box(name,(-3.2,-1,-3.2),(6.4,5,6.4),"wool")
        m.box(name,(-3.5,8,-3.8),(7,4,7.6),"hoof")
        m.box(name,(-.4,8,-4),(.8,4,.6),"face_shadow")
    m.bone("tail",(0,4,17),animation="tail")
    m.box("tail",(-3,0,0),(6,6,5),"wool")
    m.box("tail",(-2,4,1),(4,5,4),"wool_light")
    return m


def feather(m, bone, start, end, width, white="white_feather", gold="gold", depth=1.7):
    delta=[end[i]-start[i] for i in range(3)]
    split=[start[i]+delta[i]*.78 for i in range(3)]
    m.beam(bone,start,end,width,"gold_shadow",depth)
    m.beam(bone,start,split,max(1,width-.45),white,depth+.3)
    m.beam(bone,split,end,max(.8,width-.25),gold,depth+.35)


def chicken():
    m = Sculpture("chicken", [
        mat("white_feather", "#F6F0DF", "fur"),mat("white_light", "#FFFEF4", "fur"),
        mat("white_shadow", "#D7CCBA", "fur"),mat("gold", "#E9BA43", "metal"),
        mat("gold_light", "#FFDE77", "metal"),mat("gold_shadow", "#9D732F", "metal"),
        mat("red_comb", "#BB292F", "skin"),mat("red_light", "#E44742", "skin"),
        mat("red_shadow", "#821B29", "skin"),mat("beak", "#E3AB35", "bone"),
        mat("leg", "#C89938", "skin"),mat("talon", "#6C572F", "bone"),
        mat("eye", "#101820", "void"),mat("eye_glint", "#FFFFFF", "glass"),
        mat("ember", "#F9C456", "fire")],
        ["white-gold layered wing feather fans", "jagged red rooster crown", "hanging red wattle",
         "thick gold legs and individual talons", "full tail feather fan", "block chicken face"])
    m.bone("torso",parent="root",animation="body")
    m.bone("head",(0,-10,-7),animation="head")
    m.bone("jaw",(0,4,-6),parent="head",animation="jaw")
    m.box("torso",(-7,-7,-6),(14,17,13),"white_shadow")
    m.box("torso",(-6,-10,-5),(12,6,11),"white_feather")
    # Stepped breast and mantle feathers, each tier overlaps the one below.
    for row,(y,width) in enumerate([(-5,14),(0,13),(5,11)]):
        for column in range(5):
            x=-width/2+column*width/5
            m.box("torso",(x,y,-7-row*.3),(width/5-.25,6,2.2),"white_light" if column%2 else "white_feather")
            m.box("torso",(x+.2,y+4.7,-7.4-row*.3),(width/5-.6,1.4,2.4),"gold" if row!=1 else "white_shadow")
    for side in (-1,1):
        for row in range(4):
            x=(-9.5+row*.4 if side<0 else 6-row*.4)
            m.box("torso",(x,-5+row*3,-3+row*.7),(3.5,4,8-row),"white_feather")
            m.box("torso",(x+.25,-2+row*3,-3+row*.7),(3,1.2,7.4-row),"gold_light" if row%2 else "gold")
    m.box("head",(-5.7,-5.5,-6),(11.4,12,12),"white_feather")
    m.box("head",(-5,-6.5,-5),(10,2,10),"white_light")
    m.box("head",(-4,0,-12),(8,4.5,7),"beak")
    m.box("head",(-3.2,-.5,-12.4),(6.4,1.1,5),"gold_light")
    m.box("head",(-2,1.2,-14),(4,2.5,2.2),"gold")
    for side in (-1,1):
        ex=-5.8 if side<0 else 3
        m.box("head",(ex,-2.5,-6.4),(2.8,3.1,.8),"eye")
        m.box("head",(ex+.3,-2.3,-6.9),(.9,.9,.5),"eye_glint")
        m.box("head",((-6.2 if side<0 else 4.2),1,-5.5),(2,4,4),"white_shadow")
    # An actual comb fan: five unequal plates and their smaller branch points.
    for z,y,h in [(-5,-13,8),(-2,-17,12),(1,-18,13),(4,-15,10),(6,-11,6)]:
        m.box("head",(-1.6,y,z),(3.2,h,2.6),"red_comb")
        m.box("head",(-1.1,y-.9,z+.3),(2.2,2.2,2),"red_light")
    for side in (-1,1):
        for z,y in [(-2,-12),(2,-14),(4,-10)]:
            m.box("head",(side*2.6-1.1,y,z),(2.2,5,2.8),"red_comb",(0,0,side*18))
    m.box("jaw",(-2.4,0,-1),(4.8,8,3.5),"red_shadow")
    m.box("jaw",(-3.2,5,-1.2),(6.4,4.6,3.9),"red_comb")
    m.box("jaw",(-1.5,8,-1.4),(3,2.5,3.5),"red_light")
    # Long primaries fan upward/outward. They are individually edged feather blades.
    for side,anim in [(-1,"wing_l"),(1,"wing_r")]:
        name="wing_"+str(side)
        m.bone(name,(side*7,-4,0),rotation=(0,side*5,side*-8),animation=anim)
        m.box(name,((-5 if side<0 else 0),-1,-2),(5,8,5),"gold_shadow")
        for i in range(9):
            angle=-68+i*13
            length=17+(3-abs(4-i))*.9
            end=(side*(8+math.cos(math.radians(angle))*length),-2+math.sin(math.radians(angle))*length,4+i*.8)
            feather(m,name,(side*2,0,1.4+i*.35),end,3.3,depth=1.9)
        for i in range(6):
            end=(side*(8+i*1.5),-6+i*2.8,1+i*.65)
            feather(m,name,(side*.5,1,0),end,3.4,"white_light","gold_light",2.0)
    m.bone("tail",(0,-1,6),animation="tail")
    for i in range(9):
        spread=(i-4)*3.4
        feather(m,"tail",(spread*.12,2,0),(spread,-13+abs(i-4)*1.4,16-abs(i-4)*1.3),3.4,"white_feather","gold",2.0)
    for side,anim in [(-1,"leg_l"),(1,"leg_r")]:
        name="leg_"+str(side)
        m.bone(name,(side*4.5,10,0),animation=anim)
        m.box(name,(-2.2,-1,-2.2),(4.4,4.5,4.4),"white_feather")
        m.box(name,(-1.4,2,-1.3),(2.8,9,2.6),"leg")
        for y in (3,5,7,9):m.box(name,(-1.7,y,-1.6),(3.4,.8,3.2),"gold_light")
        for toe,dx in enumerate((-3,0,3)):
            m.beam(name,(0,11,-.7),(dx,12,-7+abs(dx)*.35),1.6,"leg")
            m.box(name,(dx-.8,11.4,-8+abs(dx)*.35),(1.6,1.7,2.5),"talon")
        m.beam(name,(0,11,0),(side*.6,12,4),1.5,"gold_shadow")
    return m


def wolf():
    m = Sculpture("wolf", [
        mat("fur_gray", "#7A8595", "fur"),mat("fur_silver", "#B6C1CE", "fur"),
        mat("fur_light", "#DBE2E5", "fur"),mat("fur_dark", "#4C586C", "fur"),
        mat("back_plate", "#596477", "stone"),mat("plate_edge", "#8493A7", "stone"),
        mat("ice", "#8FC7EC", "ice"),mat("ice_light", "#D0EDFB", "ice"),
        mat("ice_dark", "#4E8FC7", "ice"),mat("nose", "#26313F", "skin"),
        mat("eye", "#B8F5FF", "ice"),mat("eye_socket", "#25364C", "void"),
        mat("inner_ear", "#778595", "skin"),mat("claw", "#D7E0DE", "bone"),
        mat("paw", "#566276", "fur")],
        ["layered outward-pointing blue ice mane", "silver-gray wolf face and muzzle",
         "dark dorsal plates", "oversized individual-toed square paws", "frosted bushy raised tail"])
    m.bone("torso",parent="root",animation="body")
    m.bone("head",(0,0,-21),animation="head")
    m.bone("jaw",(0,3,-9),parent="head",animation="jaw")
    m.box("torso",(-9,-4,-17),(18,14,34),"fur_gray")
    m.box("torso",(-7,7,-13),(14,4,27),"fur_silver")
    m.box("torso",(-10,-5,-17),(20,15,12),"fur_dark")
    m.box("torso",(-8,-6,3),(16,4,13),"fur_silver")
    for i,z in enumerate((-14,-8,-2,4,10)):
        m.box("torso",(-7,-7,z),(14,3,5.6),"back_plate")
        m.box("torso",(-6,-7.6,z+.5),(12,.9,4.6),"plate_edge")
        m.box("torso",(-3,-9,z+1.2),(6,2.3,3),"fur_dark")
    for side in (-1,1):
        for y,z in [(0,-11),(4,-7),(2,1),(4,8),(0,13)]:
            xx=-10.5 if side<0 else 7
            m.box("torso",(xx,y,z),(3.5,4,5),"fur_silver")
            m.box("torso",(xx+.5,y+3,z+1),(2.5,2.2,3),"fur_light")
    # Thirty distinct ice directions create a thick neck collar, not a ring of equal sticks.
    crystals=[]
    for side in (-1,1):
        for row,z in enumerate((-16,-11,-6)):
            crystals += [((side*6,-2,z),(side*(13+row),-11+row,z-3),4.4),
                         ((side*7,1,z),(side*(15-row),-4+row,z-1),4.0),
                         ((side*6,5,z),(side*(12+row),9,z+1),3.8)]
    crystals += [((-4,-5,-16),(-6,-17,-18),4.2),((1,-5,-15),(1,-20,-16),4.8),
                 ((5,-5,-12),(7,-17,-13),4.0),((-3,-5,-8),(-4,-16,-8),4.2),
                 ((2,-5,-5),(2,-14,-3),3.8)]
    for i,(base,tip,width) in enumerate(crystals):
        middle=tuple(base[k]+(tip[k]-base[k])*.68 for k in range(3))
        m.beam("torso",base,middle,width,"ice_dark" if i%4==0 else "ice")
        m.beam("torso",middle,tip,width*.53,"ice_light")
        # A shorter offset facet makes the crystals read as volumes in 3/4 view.
        facet=tuple(base[k]+(tip[k]-base[k])*.45 for k in range(3))
        m.beam("torso",base,(facet[0]+.8,facet[1]-.4,facet[2]-.8),width*.5,"ice_light")
    m.box("head",(-7,-5,-8),(14,11,13),"fur_gray")
    m.box("head",(-6,-6,-7),(12,2.5,9),"fur_silver")
    m.box("head",(-4,-.5,-14),(8,6,7),"fur_light")
    m.box("head",(-4.2,-.8,-16),(8.4,3,2.8),"nose")
    m.box("head",(-2.5,-1.1,-16.3),(5,1,1),"fur_dark")
    for side in (-1,1):
        ex=-6.2 if side<0 else 3.4
        m.box("head",(ex,-3.8,-8.6),(2.8,2.7,.8),"eye_socket")
        m.box("head",(ex+.35,-3.3,-9.05),(2.1,1.5,.6),"eye")
        m.box("head",(ex-.6,-5,-8.7),(4,1.3,1.2),"fur_light",(0,0,side*-9))
        for y,z in [(0,-4),(3,-1)]:
            m.box("head",((-9 if side<0 else 6),y,z),(3,4.5,5),"fur_light",(0,0,side*-18))
        m.box("head",((side*5)-2.2,-12,-.5),(4.4,8,3.4),"fur_dark",(0,0,side*8))
        m.box("head",((side*5)-1.4,-11.3,-.9),(2.8,5.2,.8),"inner_ear")
        m.box("head",((side*5)-1.1,-15,-.1),(2.2,4,2.6),"fur_silver")
    m.box("jaw",(-3.5,0,-4),(7,3.6,7),"fur_silver")
    m.box("jaw",(-3,2.6,-4),(6,1.4,6),"fur_light")
    for name,x,z in [("leg_fl",-7,-13),("leg_fr",7,-13),("leg_hl",-7,13),("leg_hr",7,13)]:
        m.bone(name,(x,8,z),animation=name)
        m.box(name,(-2.5,-1,-2.8),(5,12,5.6),"fur_gray")
        m.box(name,(-3.4,-2,-3.6),(6.8,6,7.2),"fur_silver")
        m.box(name,(-4.5,10,-5),(9,6,10),"paw")
        m.box(name,(-4.7,9.5,-4.5),(9.4,2.4,8.5),"fur_light")
        for toe in range(4):
            xx=-3.8+toe*2.1
            m.box(name,(xx,12.5,-5.7),(1.7,3.4,3),"fur_silver")
            m.box(name,(xx+.3,14.7,-6.7),(1.1,1.3,2),"claw")
        m.box(name,(-2,7,-3.9),(4,3,1.4),"ice")
    m.bone("tail",(0,1,17),rotation=(-18,0,0),animation="tail")
    m.box("tail",(-3.4,-1,0),(6.8,7,10),"fur_gray")
    m.box("tail",(-4,-3,7),(8,7,9),"fur_silver")
    m.box("tail",(-3,-5,14),(6,6,7),"fur_light")
    for x,z,h in [(-3,8,5),(2,12,6),(-1,17,7)]:
        m.box("tail",(x-1.5,-5-h,z),(3,h,3),"ice")
        m.box("tail",(x-.9,-7-h,z+.4),(1.8,3,1.8),"ice_light")
    return m


def honey_cell(m, bone, x, y, z, size=6):
    """Stepped octagonal wax rim surrounding a recessed amber center."""
    half=size/2;edge=1.0
    m.box(bone,(x-half+edge,y+.8,z-half+edge),(size-2*edge,.7,size-2*edge),"honey")
    for xyz,sz in [((x-half+1,y,z-half),(size-2,1,1)),((x-half+1,y,z+half-1),(size-2,1,1)),
                   ((x-half,y,z-half+1),(1,1,size-2)),((x+half-1,y,z-half+1),(1,1,size-2))]:
        m.box(bone,xyz,sz,"wax_light")
    for xx,zz in [(x-half+.4,z-half+.4),(x+half-1.4,z-half+.4),
                  (x-half+.4,z+half-1.4),(x+half-1.4,z+half-1.4)]:
        m.box(bone,(xx,y,zz),(1,1,1),"wax")


def bee():
    m = Sculpture("bee", [
        mat("yellow", "#EAC343", "fur"),mat("yellow_light", "#FFE27A", "fur"),
        mat("stripe", "#3A302B", "fur"),mat("stripe_light", "#5D4B37", "fur"),
        mat("honey", "#D98D24", "honey"),mat("wax", "#F2B536", "honey"),
        mat("wax_light", "#FFE291", "honey"),mat("wax_dark", "#9F661F", "honey"),
        mat("wing_glass", "#D6ECF0", "glass"),mat("wing_edge", "#F3DE9C", "metal"),
        mat("wing_vein", "#B8CBCD", "glass"),mat("eye", "#2C4252", "glass"),
        mat("eye_glint", "#DEF7FF", "glass"),mat("stinger", "#393348", "stone"),
        mat("pollen", "#FFD25B", "fire")],
        ["yellow-black cubic bee body", "tiered amber honeycomb fortress shell", "four translucent rectangular wings",
         "individual articulated legs and antennae", "heavy dark rectangular stinger", "honey drips"])
    m.bone("torso",(0,2,0),parent="root",animation="float")
    m.bone("head",(0,0,-10),animation="head")
    # Thick banding is part of the actual body construction, not a tinted generic orb.
    for i,z in enumerate((-12,-8,-4,0,4,8)):
        m.box("torso",(-10,-7,z),(20,15,4.05),"yellow" if i%2==0 else "stripe")
    m.box("torso",(-8,7,-10),(16,2,20),"yellow_light")
    m.box("head",(-10,-7,-3),(20,15,4),"yellow")
    m.box("head",(-9,-6,-3.5),(18,2,.8),"yellow_light")
    for side in (-1,1):
        x=-8.4 if side<0 else 2.4
        m.box("head",(x,-3.5,-4),(6,7,1.3),"stripe")
        m.box("head",(x+.6,-2.9,-4.6),(4.8,5.8,.9),"eye")
        m.box("head",(x+.8,-2.7,-5.1),(1.6,2,.7),"eye_glint")
        m.box("head",(x+3.3,.5,-5),(1,1.3,.6),"eye_glint")
        name="antenna_"+str(side)
        m.bone(name,(side*5,-7,-1),parent="head",rotation=(-13,0,side*17),animation="none")
        m.box(name,(-.8,-8,-.8),(1.6,8,1.6),"stripe")
        m.box(name,(-1.5,-11,-1.4),(3,4,2.8),"stripe_light")
        m.box(name,(-.7,-11.6,-1.8),(1.4,1.4,1),"wax_light")
    # Fortress shell has terraced roof sections and two visible rows of individual cells.
    m.box("torso",(-9,-10,-8),(18,4,21),"wax_dark")
    m.box("torso",(-7,-14,-5),(14,4.5,16),"wax")
    m.box("torso",(-4,-17,-2),(8,3.5,9),"honey")
    for x,z in [(-6,-5),(0,-5),(6,-5),(-6,1),(0,1),(6,1),(-6,7),(0,7),(6,7)]:
        honey_cell(m,"torso",x,-14.5 if abs(x)<3 else -10.8,z,5.8)
    honey_cell(m,"torso",0,-17.8,3,6.2)
    for side in (-1,1):
        # Deep side walls have stepped amber blocks and inset lighter honey faces.
        for row,y in enumerate((-7,-3,1)):
            for col,z in enumerate((-6,0,6,11)):
                x=-11.3 if side<0 else 9.3
                m.box("torso",(x,y,z),(2.2,4,4.8),"honey" if (row+col)%2 else "wax")
                m.box("torso",(x-.2 if side<0 else x+1.7,y+.5,z+.6),(.7,2.7,3.6),"wax_light")
        for z,length in [(-7,6),(-1,8),(6,5)]:
            x=-11.5 if side<0 else 10.2
            m.box("torso",(x,-3,z),(1.3,length,1.6),"honey")
            m.box("torso",(x-.5,length-4,z-.5),(2.3,2,2.6),"wax")
    # Four rectangular glass panes, separately rooted/flapped, with real frame and branching veins.
    for side in (-1,1):
        for front in (True,False):
            name=("front_wing_" if front else "rear_wing_")+str(side)
            m.bone(name,(side*8,-7,-5 if front else 6),
                   rotation=(12 if front else -14,side*(8 if front else -9),side*(25 if front else 52)),
                   animation="wing_l" if side<0 else "wing_r")
            width=22 if front else 18; height=12 if front else 10
            left=-width if side<0 else 0
            m.box(name,(left,-height,-.25),(width,height,.5),"wing_glass")
            for xyz,size in [((left,-height,-.5),(width,.7,1)),((left,-.7,-.5),(width,.7,1)),
                             ((left,-height,-.5),(.7,height,1)),((left+width-.7,-height,-.5),(.7,height,1))]:
                m.box(name,xyz,size,"wing_edge")
            m.beam(name,(side*.5,-.5,0),(side*(width-1),-height+1,0),.6,"wing_vein",.75)
            for fraction in (.35,.65):
                x=side*width*fraction
                m.beam(name,(x,-height*fraction,0),(x+side*3,-height+.8,0),.55,"wing_edge",.7)
                m.beam(name,(x,-height*fraction,0),(x+side*4,-.8,0),.55,"wing_vein",.7)
    for side in (-1,1):
        for i,z in enumerate((-7,0,7)):
            name=f"leg_{side}_{i}"
            m.bone(name,(side*6.5,7,z),rotation=(0,0,-side*15),
                   animation=("leg_fl" if i%2==0 else "leg_hr") if side<0 else ("leg_fr" if i%2==0 else "leg_hl"))
            m.box(name,(-.8,0,-.8),(1.6,5.4,1.6),"stripe")
            m.box(name,(-1.2,4.5,-1),(2.4,2,2),"stripe_light")
            m.beam(name,(0,5,0),(side*2,9,1),1.3,"stripe")
            m.box(name,(side*2-1,8.5,-.5),(2,1.3,3),"wax_dark")
    m.bone("stinger",(0,3,12),animation="tail")
    m.box("stinger",(-2.5,-2.5,0),(5,5,7),"stinger")
    m.box("stinger",(-1.6,-1.6,6),(3.2,3.2,4),"stripe")
    m.box("stinger",(-.7,-.7,9),(1.4,1.4,3),"stinger")
    return m


def rotate(point, degrees):
    x,y,z=point
    a,b,c=[math.radians(v) for v in degrees]
    y,z=y*math.cos(a)-z*math.sin(a),y*math.sin(a)+z*math.cos(a)
    x,z=x*math.cos(b)+z*math.sin(b),-x*math.sin(b)+z*math.cos(b)
    return (x*math.cos(c)-y*math.sin(c),x*math.sin(c)+y*math.cos(c),z)


def bounds(data):
    bones={b["name"]:b for b in data["bones"]}
    def to_world(point,name):
        if name=="root":return point
        b=bones[name];r=rotate(point,b.get("rotation",[0,0,0]));p=b["pivot"]
        return to_world(tuple(r[i]+p[i] for i in range(3)),b["parent"])
    points=[]
    for b in data["boxes"]:
        for xx in (0,1):
            for yy in (0,1):
                for zz in (0,1):
                    p=tuple(b["from"][i]+b["size"][i]*v for i,v in enumerate((xx,yy,zz)))
                    if "rotation" in b:
                        pivot=b["pivot"];r=rotate(tuple(p[i]-pivot[i] for i in range(3)),b["rotation"])
                        p=tuple(r[i]+pivot[i] for i in range(3))
                    points.append(to_world(p,b["bone"]))
    return [[round(min(p[i] for p in points),2),round(max(p[i] for p in points),2)] for i in range(3)]


def main():
    for factory in (cow,pig,sheep,chicken,wolf,bee):
        sculpture=factory();d=sculpture.data
        names={b["name"] for b in d["bones"]}
        assert len(names)==len(d["bones"])
        assert all(b["parent"]=="root" or b["parent"] in names for b in d["bones"])
        assert all(b["bone"] in names for b in d["boxes"])
        sculpture.save()
        print(d["id"],"bones",len(d["bones"]),"boxes",len(d["boxes"]),"bounds xyz",bounds(d))


if __name__=="__main__":main()
