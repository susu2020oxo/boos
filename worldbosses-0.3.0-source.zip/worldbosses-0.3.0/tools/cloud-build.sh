#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
if [[ -z "${JAVA_HOME:-}" && -x /workspace/tools/jdk-21.0.9+10/bin/javac ]]; then
  export JAVA_HOME=/workspace/tools/jdk-21.0.9+10
fi
export GRADLE_USER_HOME="${GRADLE_USER_HOME:-/workspace/tools/gradle-home}"
if [[ $# -eq 0 ]]; then set -- build; fi
exec ./gradlew "$@"
