#!/usr/bin/env python3
"""Cross-reference catalogs, recipes, PNG dimensions and exclusions without requiring Minecraft downloads."""
import json
import struct
import unittest
from pathlib import Path

RES=Path(__file__).resolve().parents[1]/'src/main/resources'
PROFILES=json.loads((RES/'boss_profiles.json').read_text())

class ResourceTests(unittest.TestCase):
    def test_excluded_aquatic_species(self):
        ids={p['entity'] for p in PROFILES}
        self.assertFalse(ids & {'cod','salmon','pufferfish','tropical_fish','squid','glow_squid','dolphin',
                               'turtle','axolotl','tadpole','guardian','elder_guardian','drowned'})

    def test_materials_recipes_and_models_cross_reference(self):
        items={p['material'] for p in PROFILES}|{'purified_soup','bone_helmet','bone_chestplate','bone_leggings',
                                               'bone_boots','bone_sword','bone_bow','soul_longbow'}
        items|={i['id'] for i in json.loads((RES/'loot_v2.json').read_text())['items']}
        lang=json.loads((RES/'assets/worldbosses/lang/zh_cn.json').read_text())
        for item in items:
            with self.subTest(item=item):
                self.assertIn('item.worldbosses.'+item,lang)
                for relative in [f'items/{item}.json',f'models/item/{item}.json',f'textures/item/{item}.png']:
                    self.assertTrue((RES/'assets/worldbosses'/relative).is_file())
        for path in (RES/'data/worldbosses/recipe').glob('*.json'):
            recipe=json.loads(path.read_text())
            ingredients=list(recipe.get('key',{}).values())+recipe.get('ingredients',[])+[recipe['result']['id']]
            for ingredient in ingredients:
                if ingredient.startswith('worldbosses:'):self.assertIn(ingredient.split(':')[1],items,str(path))

    def test_every_profile_has_an_egg_and_valid_bounded_loot(self):
        self.assertEqual(len(PROFILES),len({p['entity'] for p in PROFILES}))
        for p in PROFILES:
            with self.subTest(entity=p['entity']):
                self.assertTrue((RES/f"assets/minecraft/items/{p['entity']}_spawn_egg.json").exists())
                self.assertGreaterEqual(p['scale'],1)
                for drop in p['vanilla']:
                    self.assertGreater(drop['min'],0)
                    self.assertLessEqual(drop['min'],drop['max'])
                    self.assertLessEqual(drop['max'],128)

    def test_pig_is_easy_and_has_over_a_stack_of_pork(self):
        p=next(p for p in PROFILES if p['entity']=='pig')
        self.assertEqual(p['health'],16)
        self.assertEqual(p['ability'],'none')
        drop=next(d for d in p['vanilla'] if d['item']=='minecraft:porkchop')
        self.assertGreater(drop['min'],64)

    def test_all_item_textures_are_valid_pixel_pngs(self):
        for path in (RES/'assets/worldbosses/textures/item').glob('*.png'):
            data=path.read_bytes()
            self.assertEqual(data[:8],b'\x89PNG\r\n\x1a\n')
            self.assertIn(struct.unpack('!II',data[16:24]),{(32,32),(64,64)},str(path))

if __name__=='__main__':unittest.main(verbosity=2)
