#!/usr/bin/env python3
"""Independently authored skeletal models for 29 wildlife/civilian Bosses.

All geometry is new. Shared helpers describe anatomy (eyes, toes, equine legs),
not a stock model with recolours. Material tiles are supplied by the atlas pass.
"""
from pathlib import Path
import json
import math

OUT = Path(__file__).resolve().parents[1] / 'src/main/resources/assets/worldbosses/boss_models'

class Model:
    def __init__(self, ident, materials):
        self.ident = ident
        self.palette = []
        self.mat = {}
        self.bones = []
        self.boxes = []
        common = [('black','#1B2029','skin'),('white','#F2EFE4','fur'),('ivory','#DFD3B2','bone'),('glow','#82E9EE','ice')]
        for name, color, pattern in common + materials:
            if name in self.mat: continue
            self.mat[name] = len(self.palette)
            self.palette.append(dict(name=name,color=color,pattern=pattern))
        assert len(self.palette) <= 16
    def bone(self,name,pivot=(0,0,0),animation='none',parent='root',rotation=(0,0,0)):
        self.bones.append(dict(name=name,parent=parent,pivot=list(pivot),rotation=list(rotation),animation=animation))
        return name
    def b(self,bone,xyz,size,material,rot=None):
        data=dict(bone=bone,**{'from':list(xyz)},size=list(size),material=self.mat[material])
        if rot: data['rotation']=list(rot)
        self.boxes.append(data)
    def eye(self,bone,x,y,z,side=1,glow=False,w=2,h=2):
        self.b(bone,(x,y,z),(.55,h+1,w+1),'black')
        self.b(bone,(x+side*.13,y+.3,z+.4),(.65,h,w),'glow' if glow else 'white')
        self.b(bone,(x+side*.24,y+.5,z+.35),(.72,h*.72,w*.46),'black')
        self.b(bone,(x+side*.32,y+.5,z+.35),(.76,.5,.5),'white')
    def face_eyes(self,bone,y,z,separation=3,glow=False):
        for s in (-1,1):
            self.b(bone,(s*separation-1.3,y,z),(2.6,2.4,.7),'black')
            self.b(bone,(s*separation-.8,y+.3,z-.12),(1.6,1.5,.8),'glow' if glow else 'white')
            self.b(bone,(s*separation-.35,y+.5,z-.22),(.8,1.2,.9),'black')
            self.b(bone,(s*separation-.55,y+.4,z-.3),(.45,.5,1),'white')
    def leg(self,name,x,z,y=13,length=11,width=3,material='skin',foot='black',claws=False):
        self.bone(name,(x,y,z),name)
        self.b(name,(-width/2,0,-width/2),(width,length-1,width),material)
        self.b(name,(-width/2-.4,length*.42,-width/2-.4),(width+.8,2,width+.8),material)
        self.b(name,(-width/2-.6,length-2,-width/2-1),(width+1.2,2,width+2),foot)
        self.b(name,(-width/2-.7,length-2.5,-width/2-1.1),(width+1.4,.8,width+2.2),material)
        if claws:
            for i in range(3):self.b(name,(-width/2+i*width/3,length-1,-width/2-2),(width/4,1,2),'ivory')
        else:
            self.b(name,(-.18,length-2.1,-width/2-1.2),(.36,2.2,width+2.3),'black')
    def ear(self,name,parent,pivot,length,width,material,inner='ivory',rotation=(0,0,0)):
        self.bone(name,pivot,'none',parent,rotation)
        self.b(name,(-width/2,-length,-1),(width,length,2),material)
        self.b(name,(-width/2+.6,-length+1,-1.1),(width-1.2,length-1.5,.5),inner)
        self.b(name,(-width/2+.3,-length-1,-.7),(width-.6,1.2,1.4),material)
    def ridge(self,bone,axis,start,count,step,width,height,depth,mat):
        for i in range(count):
            x,y,z=start
            if axis=='x':x+=i*step
            if axis=='y':y+=i*step
            if axis=='z':z+=i*step
            self.b(bone,(x,y,z),(width,height,depth),mat)
    def write(self):
        names={b['name'] for b in self.bones}|{'root'}
        assert len(names)==len(self.bones)+1,self.ident
        assert all(b['parent'] in names for b in self.bones)
        assert all(b['bone'] in names and all(v>0 for v in b['size']) for b in self.boxes)
        obj=dict(id=self.ident,texture_size=[1024,1024],palette=self.palette,bones=self.bones,boxes=self.boxes)
        OUT.mkdir(parents=True,exist_ok=True)
        (OUT/(self.ident+'.json')).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
        print(f'{self.ident:20s} {len(self.bones):3d} bones {len(self.boxes):4d} boxes')

def rabbit():
    m=Model('rabbit',[('fur','#DAD4E2','fur'),('silver','#9194A9','metal'),('pink','#DAB4CE','skin'),('crystal','#AC99E7','ice')])
    m.bone('body',(0,12,1),'body');m.b('body',(-5,-5,-7),(10,10,14),'fur')
    m.b('body',(-6,-3,0),(12,9,10),'fur');m.b('body',(-4,-6,-5),(8,2,11),'white')
    m.bone('head',(0,5,-8),'head');m.b('head',(-4,-4,-4),(8,8,7),'fur')
    m.b('head',(-3,0,-6),(6,4,3),'white');m.b('head',(-1,.4,-6.7),(2,1.8,1),'pink')
    m.face_eyes('head',-1.5,-4.5,2.5)
    for s in (-1,1):
        m.ear('ear'+str(s),'head',(s*2,-3,0),15,3.6,'fur','crystal',(0,0,s*8))
        m.b('head',(s*2.6,-1,-5.3),(.6,.6,3),'silver')
        for i in range(3):m.b('head',(s*(2.5+i*.6),1+i*.7,-5.4),(1.8,.35,.35),'silver')
        hind='leg_hl' if s<0 else 'leg_hr';m.bone(hind,(s*4,15,5),hind)
        m.b(hind,(-2.5,-3,-3),(5,7,6),'fur');m.b(hind,(-2,3,-7),(4,6,10),'fur')
        m.b(hind,(-2.2,7,-8),(4.4,2,11),'white')
        for t in range(3):m.b(hind,(-1.6+t*1.15,8,-8.5),(.55,.8,1),'silver')
        for i in range(4):m.b(hind,(-2.5,3+i,-5.5+i*.9),(5,.9,1.3),'pink')
        front='leg_fl' if s<0 else 'leg_fr';m.leg(front,s*3,-6,17,7,2.4,'fur','white',True)
    m.bone('tail',(0,14,10),'tail');
    for x,y,z,w,h,d in [(-2,-2,0,4,4,4),(-3,-1,1,6,2,2),(-1,-3,1,2,6,2)]:m.b('tail',(x,y,z),(w,h,d),'white')
    for i in range(7):m.b('body',(-2+i%3*1.5,-6-(i%2),-4+i*1.4),(1,1.8,2),'crystal')
    return m

def goat():
    m=Model('goat',[('fur','#C4C2B5','fur'),('rock','#838279','stone'),('gold','#D8B36D','metal')])
    m.bone('body',(0,8,1),'body');m.b('body',(-6,-5,-10),(12,12,22),'fur')
    m.b('body',(-7,-3,-5),(14,10,13),'white')
    m.bone('head',(0,3,-11),'head');m.b('head',(-4,-4,-5),(8,9,8),'fur');m.b('head',(-3,1,-9),(6,5,5),'fur')
    m.b('head',(-2,2,-9.4),(4,2,.8),'black');m.face_eyes('head',-1,-5.4,2.7)
    for s in (-1,1):
        m.ear('ear'+str(s),'head',(s*4,-2,-1),4,3,'fur','gold',(0,0,s*55))
        for i in range(10):
            y=-5-i*.95;z=1+i*1.05
            m.b('head',(s*(2.4+i*.1)-1,y,z),(2.6,2.1,2.5),'rock')
            if i%2==0:m.b('head',(s*(2.4+i*.1)-1.15,y-.1,z-.1),(2.9,.4,2.7),'gold')
        for i in range(5):m.b('head',(s*.6-1,5+i*.8,-6+i*.35),(1.5,1.8,2),'white')
        for k,z in [('fl',-7),('hl',8)]:m.leg('leg_'+('l' if False else k.replace('l','l') if s<0 else k.replace('l','r')),s*4.5,z,14,10,2.8,'fur','rock')
        for row in range(2):
            for z in range(-8,10,3):m.b('body',(s*6-1,-1+row*3,z),(2,5+row,3),'white')
    for i in range(5):m.b('body',(-3,-7-i%2,-8+i*4),(6,3+i%2,3),'rock')
    m.bone('tail',(0,8,12),'tail');m.b('tail',(-1,-3,0),(2,6,5),'fur')
    return m

def equine_base(ident,skin='#8A8584',kind='horse'):
    m=Model(ident,[('skin',skin,'skin'),('mane','#394452','fur'),('armor','#626C80','metal'),('cloth','#7588A7','cloth'),('wood','#7C6047','wood'),('sand','#BB9C72','stone'),('leaf','#71825A','leaf'),('gold','#D2B46F','metal')])
    m.bone('body',(0,3,0),'body')
    if kind=='skeleton':
        m.b('body',(-1,-4,-12),(2,3,26),'ivory')
        for z in range(-10,12,4):
            for s in (-1,1):
                m.b('body',(s*3-1,-3,z),(2,9,2),'ivory', (0,0,s*-22))
                m.b('body',(s*4-1,4,z),(2,4,2),'ivory',(0,0,s*35))
        m.b('body',(-2,7,-8),(4,2,16),'ivory')
        m.b('body',(-1.8,-1,-3),(3.6,4,4),'glow')
    else:
        m.b('body',(-7,-5,-12),(14,13,25),'skin')
        m.b('body',(-6,-6,-10),(12,3,21),'skin');m.b('body',(-6,6,-8),(12,3,16),'skin')
        m.b('body',(-8,-1,6),(16,10,8),'skin')
    m.bone('neck',(0,0,-10),'body');m.b('neck',(-4,-12,-3),(8,15,7),'ivory' if kind=='skeleton' else 'skin',(18,0,0))
    m.bone('head',(0,-10,-17),'head');m.b('head',(-4,-5,-4),(8,10,8),'ivory' if kind=='skeleton' else 'skin')
    m.b('head',(-3.5,-1,-11),(7,7,8),'ivory' if kind=='skeleton' else 'skin',(12,0,0))
    m.b('head',(-3,3,-12),(6,3,2),'mane')
    for s in (-1,1):
        m.eye('head',s*3.8,-2,-3,s,kind=='skeleton',2,2)
        m.b('head',(s*2,3,-12.2),(1,1.4,.6),'black')
        m.ear('ear'+str(s),'head',(s*2.6,-4,-.5),9 if kind=='donkey' else 5,2.8,'skin','cloth',(0,0,s*8))
        for k,z in [('fl',-8),('hl',9)]:
            name='leg_'+(k if s<0 else k.replace('l','r'))
            m.leg(name,s*4.8,z,11,13,2.8,'ivory' if kind=='skeleton' else 'skin','armor')
            if kind=='skeleton':m.b(name,(-2,4,-2),(4,2,4),'glow')
    m.bone('tail',(0,3,13),'tail');m.b('tail',(-1.5,-1,0),(3,4,6),'skin')
    for i in range(6):m.b('tail',(-2,1+i*1.7,3+i*.7),(4,3,3),'glow' if kind=='skeleton' else 'mane')
    return m

def horse():
    m=equine_base('horse','#75889B')
    for i in range(12):
        m.b('neck',(-2,-13+i*1.1,3),(4,2.6,4+i%3),'armor')
        m.b('neck',(-.8,-13.8+i*1.1,4),(1.6,1.5,3),'glow')
    for s in (-1,1):
        for i in range(4):m.b('body',(s*6-1,-6+i*.45,-9+i*4),(2,2,4),'armor')
        for name in ['leg_fl','leg_fr','leg_hl','leg_hr']:
            m.b(name,(-2.1,8,-2.5),(4.2,3,5),'armor');m.b(name,(-1,8.2,-2.7),(2,2.4,.5),'glow')
    for y in range(-4,4,2):m.b('head',(-.8,y,-4.4),(1.6,1.8,.7),'white')
    return m

def crate(m,bone,x,y,z,w=6,h=8,d=7,mat='wood'):
    m.b(bone,(x,y,z),(w,h,d),mat)
    trim='armor' if 'armor' in m.mat else mat
    for xx in (x,x+w-1):m.b(bone,(xx,y-.3,z-.3),(1,h+.6,d+.6),trim)
    for yy in (y,y+h-1):m.b(bone,(x-.3,yy,z-.3),(w+.6,1,d+.6),trim)
    m.b(bone,(x+w*.35,y+h*.4,z-.5),(w*.3,h*.2,.7),'gold')

def donkey():
    m=equine_base('donkey','#8A8171','donkey')
    for s in (-1,1):
        crate(m,'body',-12 if s<0 else 7,-3,-2,5,10,12)
        m.b('body',(s*7-1,-7,-8),(2,4,17),'sand')
        for i in range(4):m.b('body',(s*7-1,-6-i*.5,-8+i*4),(2,2,3),'sand')
        for i in range(4):m.b('ear'+str(s),(-.6,-8+i*2,-1.2),(1.2,1.3,.7),'gold')
    for z in range(-10,10,4):m.b('body',(-7,-7,z),(14,2,2),'cloth')
    m.b('head',(-3,4,-11.8),(6,1,.7),'ivory')
    return m

def mule():
    m=equine_base('mule','#57594F','donkey')
    for z in range(-10,12,4):
        m.b('body',(-6,-7,z),(12,3,3.5),'armor')
        m.b('body',(-2,-7.4,z+.7),(4,.7,1),'gold')
    for s in (-1,1):
        crate(m,'body',-13 if s<0 else 7,-2,-6,6,8,11,'cloth')
        for name in ['leg_fl','leg_fr','leg_hl','leg_hr']:
            m.b(name,(-1.8,3,-2),(3.6,4,4),'armor')
            m.b(name,(-1,4,-2.3),(2,1,.5),'gold')
    for i in range(6):m.b('neck',(-1.5,-11+i*2,3),(3,2,3),'armor')
    return m

def skeleton_horse():
    m=equine_base('skeleton_horse','#CBC7A8','skeleton')
    for i in range(9):
        m.b('neck',(-1.4,-14+i*1.8,2),(2.8,3,4),'glow')
        m.b('neck',(-.6,-15+i*1.8,4),(1.2,2,2),'white')
    for s in (-1,1):
        for i in range(5):m.b('head',(s*2.6-.4,2,-10+i*1.1),(.8,2,1),'ivory')
        m.b('body',(s*5-1,-5,8),(2,5,4),'ivory')
    return m

def zombie_horse():
    m=equine_base('zombie_horse','#627C52','zombie')
    for s in (-1,1):
        for i in range(7):m.b('body',(s*7-1,-3,-10+i*3),(2,7,1.3),'ivory' if i%2 else 'wood')
        for i in range(6):m.b('body',(s*5-1,-7,-10+i*4),(3,2+i%2,3),'leaf')
    for i in range(8):m.b('neck',(-2,-12+i*1.6,3),(4,3,5),'leaf')
    for name in ['leg_fl','leg_fr','leg_hl','leg_hr']:
        m.b(name,(-2,4,-2),(4,1.5,4),'wood');m.b(name,(-2.3,8,-2),(1,3,3),'leaf')
    return m

def camel():
    m=Model('camel',[('skin','#BC9867','skin'),('sand','#D1B47D','stone'),('cloth','#2D718E','cloth'),('gold','#DDB850','metal')])
    m.bone('body',(0,3,1),'body');m.b('body',(-8,-5,-16),(16,13,32),'skin')
    for z in (-9,7):
        for level,(w,d,h) in enumerate([(15,13,3),(11,10,3),(7,7,3),(3,4,2)]):
            m.b('body',(-w/2,-7-level*3,z-d/2),(w,h,d),'sand')
            m.b('body',(-w/2-.1,-6.3-level*3,z-d/2),(w+.2,.6,d),'gold')
    m.bone('neck',(0,-1,-15),'body');m.b('neck',(-3,-13,-3),(6,17,6),'skin',(10,0,0))
    m.bone('head',(0,-13,-20),'head');m.b('head',(-4,-3,-3),(8,7,8),'skin');m.b('head',(-3,0,-8),(6,4,7),'skin')
    for s in (-1,1):
        m.eye('head',s*3.8,-1,-3,s,False,2,1.6)
        m.ear('ear'+str(s),'head',(s*3,-2,1),4,2.5,'skin','sand',(0,0,s*35))
        for k,z in [('fl',-11),('hl',11)]:m.leg('leg_'+(k if s<0 else k.replace('l','r')),s*5.5,z,11,13,2.5,'skin','sand')
        for z in range(-13,14,4):
            m.b('body',(s*8-1,0,z),(2,8,3.5),'cloth');m.b('body',(s*8-1,6.5,z),(2,1,3.5),'gold')
    m.b('head',(-2,-5,-3),(4,2,4),'gold');m.b('head',(-1,-5.5,-3.5),(2,2,1),'cloth')
    m.bone('tail',(0,4,17),'tail');m.b('tail',(-1,0,0),(2,8,2),'skin');m.b('tail',(-2,6,-.5),(4,4,3),'sand')
    return m

def llama(trader=False):
    ident='trader_llama' if trader else 'llama'
    m=Model(ident,[('fur','#CDBEA4','wool'),('cloth','#325E91' if trader else '#A35174','cloth'),('gold','#E0B956','metal'),('wood','#876445','wood'),('armor','#556B81','metal'),('leaf','#65A38C','cloth')])
    m.bone('body',(0,7,1),'body');m.b('body',(-6,-5,-10),(12,12,21),'fur')
    m.bone('neck',(0,-3,-9),'body');m.b('neck',(-3,-13,-3),(6,18,6),'fur')
    m.bone('head',(0,-14,-12),'head');m.b('head',(-4,-4,-4),(8,8,8),'fur');m.b('head',(-3,0,-7),(6,4,4),'white')
    m.face_eyes('head',-1,-4.5,2.8)
    for s in (-1,1):
        m.ear('ear'+str(s),'head',(s*2.7,-3,0),8,2.8,'fur','white',(0,0,s*9))
        for k,z in [('fl',-6),('hl',8)]:m.leg('leg_'+(k if s<0 else k.replace('l','r')),s*4,z,15,9,2.4,'fur','ivory')
        for z in range(-9,11,3):
            m.b('body',(s*6-1,-4,z),(2,9,2.8),'cloth')
            m.b('body',(s*6-1.15,3,z+.8),(2.3,3,1),'gold')
            m.b('body',(s*6-1.3,-1,z+.7),(2.6,1.5,1.3),'leaf')
        for i in range(5):m.b('neck',(s*3-1,-11+i*3,-2),(2,2.5,5),'fur')
    m.bone('tail',(0,7,12),'tail');m.b('tail',(-1,-1,0),(2,4,5),'fur')
    if trader:
        for s in (-1,1):
            crate(m,'body',-12 if s<0 else 6,-5,-4,6,9,11)
            m.b('body',(s*5,-20,5),(1,16,1),'wood')
            for y in range(-20,-12,2):m.b('body',(s*5,-20+(y+20),5.7),(6,1.8,.6),'cloth')
            m.b('body',(s*5,-20.2,5.5),(6,.6,1),'gold')
    return m

def feline(ident):
    fox=ident=='fox';ocelot=ident=='ocelot'
    fur='#C77543' if fox else '#D5B15B' if ocelot else '#5F697D'
    m=Model(ident,[('fur',fur,'fur'),('accent','#EFE7CF' if fox else '#A17BBE','fur'),('stripe','#6B583E','fur'),('crystal','#EAA75D' if fox else '#B889DB','ice'),('leaf','#86A75D','leaf')])
    m.bone('body',(0,13,0),'body');m.b('body',(-4.5,-4,-8),(9,8,17),'fur');m.b('body',(-5,-3,3),(10,8,7),'fur')
    m.bone('head',(0,9,-9),'head');m.b('head',(-4,-3.5,-4),(8,7,7),'fur')
    m.b('head',(-3,.2,-7 if fox else -5.5),(6,3,4),'accent');m.b('head',(-1,0,-7.6 if fox else -6),(2,1.5,1),'black')
    m.face_eyes('head',-1,-4.4,2.5,ident=='cat')
    for s in (-1,1):
        m.ear('ear'+str(s),'head',(s*2.7,-3,0),5.5,3,'fur','accent',(0,0,s*13))
        for k,z in [('fl',-5.5),('hl',6)]:m.leg('leg_'+(k if s<0 else k.replace('l','r')),s*3,z,17,7,2,'fur','black',True)
        if not fox:
            for i in range(4):m.b('head',(s*(2.2+i*.65),1.3+i*.3,-5.8),(1.8,.25,.35),'white')
    m.bone('tail',(0,12,9),'tail')
    if fox:
        for i in range(8):
            w=4+2*math.sin(i/7*math.pi)
            m.b('tail',(-w/2,-i*.5,i*2),(w,5.5,3),'accent' if i>5 else 'fur')
        for s in (-1,1):
            for i in range(5):m.b('body',(s*4-1,-5,-6+i*3),(2,2.5,2),'accent')
            m.b('head',(s*3.5-1,-3.5,2),(2,4,3),'crystal')
    elif ocelot:
        for s in (-1,1):
            for z in range(-7,9,3):
                for y in (-2,1):m.b('body',(s*4.5-.25,y,z),(.6,1.6,1.5),'stripe')
        for i in range(9):m.b('tail',(-1.2,-i*.4,i*1.6),(2.4,2.8,2),'black' if i%2 else 'fur')
        for i in range(5):m.b('body',(-1,-6,-5+i*3),(2,3,2),'leaf')
    else:
        for i in range(9):m.b('tail',(-1.3,-i*.8,i*1.3),(2.6,3,2),'accent' if i>5 else 'fur')
        for s in (-1,1):
            for i in range(6):m.b('body',(s*4-1,-5,-7+i*2),(2,3,1.5),'accent')
        for i in range(4):m.b('tail',(-1,-7-i*.8,12+i),(2,2,2),'crystal')
    return m

def panda():
    m=Model('panda',[('fur','#EEEBD9','fur'),('bamboo','#65834C','wood'),('leaf','#87AA62','leaf'),('rope','#B4A374','cloth')])
    m.bone('body',(0,7,1),'body');m.b('body',(-9,-7,-11),(18,17,24),'fur');m.b('body',(-10,-3,-4),(20,11,12),'fur')
    m.b('body',(-9.5,-6,-9),(19,12,6),'black')
    m.bone('head',(0,4,-12),'head');m.b('head',(-7,-6,-5),(14,12,10),'fur');m.b('head',(-4,0,-8),(8,5,4),'fur');m.b('head',(-2,1,-8.5),(4,2,1),'black')
    for s in (-1,1):
        m.b('head',(s*3.5-2,-2,-5.7),(4,4,1),'black',(0,0,s*12));m.b('head',(s*3.5-.6,-.7,-5.9),(1.2,1.4,.9),'white')
        m.b('head',(s*3.5-.25,-.6,-6),(.6,1,1),'black')
        m.ear('ear'+str(s),'head',(s*5,-5,1),4,5,'black','black',(0,0,s*12))
        for k,z in [('fl',-7),('hl',9)]:m.leg('leg_'+(k if s<0 else k.replace('l','r')),s*6,z,14,10,4.5,'black','black',True)
    for x in (-6,-2,2,6):
        m.b('body',(x-.8,-11,-4),(1.6,7,18),'bamboo',(90,0,0))
        for z in (-6,-1,4,9):m.b('body',(x-1,-8,z),(2,1,2),'rope')
    for s in (-1,1):
        m.b('body',(s*5,-20,5),(1.2,14,1.2),'bamboo')
        for j in range(4):
            m.b('body',(s*5,-18+j*3,5),(s*0+5,.6,2),'leaf',(0,0,s*-25))
            m.b('body',(s*5-4,-17+j*3,5),(5,.6,2),'leaf',(0,0,s*25))
    m.bone('tail',(0,7,14),'tail');m.b('tail',(-2,-2,0),(4,4,3),'fur')
    return m

def polar_bear():
    m=Model('polar_bear',[('fur','#E5E9DF','fur'),('ice','#A5DAED','ice'),('deepice','#6CB5D8','ice'),('claw','#5D6D80','bone')])
    m.bone('body',(0,7,0),'body');m.b('body',(-8,-7,-13),(16,16,28),'fur');m.b('body',(-9,-5,-10),(18,14,12),'fur')
    m.bone('head',(0,3,-14),'head');m.b('head',(-6,-5,-5),(12,10,10),'fur');m.b('head',(-4,0,-10),(8,5,6),'fur');m.b('head',(-2.6,.5,-10.7),(5.2,2.5,1),'black')
    m.face_eyes('head',-1.5,-5.5,4)
    for s in (-1,1):
        m.ear('ear'+str(s),'head',(s*4,-4,1),3,3.8,'fur','claw')
        for k,z in [('fl',-8),('hl',10)]:m.leg('leg_'+(k if s<0 else k.replace('l','r')),s*5.5,z,14,10,4.5,'fur','fur',True)
        for z in range(-12,13,5):m.b('body',(s*7-1,-7,z),(3,5,4),'ice')
    for i,(x,z,h) in enumerate([(-5,-7,12),(1,-5,17),(4,1,9),(-3,5,14),(2,10,11)]):
        for level in range(3):
            w=4-level;m.b('body',(x-level*.2,-7-h+level*h/3,z),(w,h/3+1,w),'deepice' if level==0 else 'ice')
    for x in (-6,-2,2,6):
        for z in (-9,-3,4,10):m.b('body',(x,-7.8,z),(2,1.2,3),'white')
    m.bone('tail',(0,7,16),'tail');m.b('tail',(-1.7,-2,0),(3.4,4,3),'fur')
    return m

def bat():
    m=Model('bat',[('fur','#584A65','fur'),('wing','#31283F','cloth'),('vein','#8E69B0','void'),('crystal','#B89ADC','ice')])
    m.bone('body',(0,7,0),'float');m.b('body',(-3,-4,-2),(6,9,5),'fur');m.b('body',(-2,-3,-2.7),(4,6,1),'vein')
    m.bone('head',(0,1,-1),'head');m.b('head',(-4,-3,-3),(8,6,6),'fur');m.b('head',(-2,0,-4),(4,2,2),'fur');m.face_eyes('head',-1,-3.5,2.3,True)
    for s in (-1,1):
        m.ear('ear'+str(s),'head',(s*2.7,-2.5,0),9,4,'fur','vein',(0,0,s*12))
        name='wing_l' if s<0 else 'wing_r';m.bone(name,(s*2.5,4,0),name)
        for i in range(5):
            x=s*(2+i*3.2);h=12-i*1.5
            m.b(name,(min(x,x+s*3.8),-4+i*.8,0),(3.8,h,.7),'wing',(0,s*5,0))
            m.b(name,(min(x,x+s*3.8),-4+i*.8,-.2),(3.8,.7,1.1),'vein')
            m.b(name,(x,-4+i*.8,-.3),(.8,h,1.3),'fur')
            m.b(name,(x,-2+i*.8,-.5),(.6,2,1.5),'crystal')
        m.b(name,(s*16-.8,-.6,0),(1.6,4,1),'ivory')
        m.b('body',(s*1.8,5,0),(1,4,1),'fur');m.b('body',(s*1.8,8,-1),(1.5,1,2),'ivory')
    for i in range(5):m.b('body',(-1.5+i*.4,0+i*.7,-3),(2,1.5,2),'crystal')
    return m

def parrot():
    m=Model('parrot',[('red','#CB5345','fur'),('blue','#3E9DD1','fur'),('green','#68B967','fur'),('yellow','#F0CC69','fur'),('beak','#E1B15F','bone')])
    m.bone('body',(0,10,0),'body');m.b('body',(-4,-5,-3),(8,12,7),'red');m.b('body',(-3,-3,-3.6),(6,8,1),'yellow')
    m.bone('head',(0,1,-1),'head');m.b('head',(-4,-4,-3),(8,8,7),'red');m.b('head',(-2,0,-5),(4,4,2),'beak');m.b('head',(-1,3,-5),(2,2,2),'black')
    m.face_eyes('head',-1,-3.5,2.6)
    for i in range(5):m.b('head',(-3+i*1.25,-7-i%2,-.5),(1,4+i%2,2),'yellow' if i%2 else 'red',(0,0,(i-2)*10))
    for s in (-1,1):
        wing='wing_l' if s<0 else 'wing_r';m.bone(wing,(s*4,6,1),wing)
        for i in range(7):
            x=s*(i*1.6);m.b(wing,(min(x,x+s*2),-2+i*.5,0),(2,10-i*.8,1.5),['blue','green','yellow'][i%3],(0,0,s*-8))
            m.b(wing,(min(x,x+s*2),-2+i*.5,-.3),(2,2,2),'red')
        leg='leg_l' if s<0 else 'leg_r';m.bone(leg,(s*2,17,0),leg);m.b(leg,(-.6,0,-.5),(1.2,5,1),'beak')
        for t in range(3):m.b(leg,(-1.6+t*1.2,4,-3.5),(.7,1,4.5),'black')
    m.bone('tail',(0,13,3),'tail')
    for i in range(7):m.b('tail',(-4.5+i*1.4,0,i*.5),(1.2,12+3*(1-abs(i-3)/3),1.5),['red','blue','green','yellow'][i%4],(-22,0,(i-3)*3))
    return m

def frog():
    m=Model('frog',[('skin','#799A59','skin'),('belly','#C0BA7F','skin'),('moss','#59774B','leaf'),('mushroom','#A88666','wood'),('amber','#D8B462','honey')])
    m.bone('body',(0,13,0),'body');m.b('body',(-8,-5,-8),(16,10,16),'skin');m.b('body',(-7,1,-8.5),(14,5,15),'belly')
    m.bone('head',(0,10,-7),'head');m.b('head',(-8,-3,-5),(16,7,9),'skin')
    for s in (-1,1):
        m.b('head',(s*5-2,-6,-3),(4,5,5),'skin');m.b('head',(s*5-1.5,-4,-3.5),(3,2.5,1),'amber');m.b('head',(s*5-.5,-4,-3.8),(1,2.5,1),'black')
        m.b('head',(s*3-1,2,-5.5),(2,.5,1),'black')
        for kind,z,y,w in [('fl',-4,18,2.5),('hl',6,16,4)]:
            n='leg_'+(kind if s<0 else kind.replace('l','r'));m.bone(n,(s*7,y,z),n)
            m.b(n,(-w/2,0,-2),(w,4,5),'skin');m.b(n,(s*1,2,-4),(2,3,7),'skin')
            for i in range(3):
                m.b(n,(-3+i*2,4,-7),(1.2,1,5),'skin');m.b(n,(-3.4+i*2,4,-8),(2,1,2),'belly')
    m.b('head',(-4,3,-6),(8,4,3),'amber');m.b('head',(-3.5,3.5,-6.4),(7,2.5,.7),'glow')
    for x,z,w in [(-6,-4,5),(0,-6,6),(4,0,4),(-3,4,7)]:m.b('body',(x,-7,z),(w,3,5),'moss')
    for x,z,h in [(-4,-2,6),(4,3,4),(1,-4,3)]:
        m.b('body',(x,-7-h,z),(1,h,1),'mushroom');m.b('body',(x-2,-8-h,z-2),(5,1.5,5),'mushroom');m.b('body',(x-1,-9-h,z-1),(3,1,3),'amber')
    for i in range(8):m.b('body',(-6+i*1.6,-6.5,-6+(i%3)*4),(1.5,2,1.5),'skin')
    return m

def armadillo():
    m=Model('armadillo',[('skin','#A7866E','skin'),('plate','#A26954','stone'),('edge','#654A3E','stone'),('ember','#D9A261','fire')])
    m.bone('body',(0,10,0),'body');m.b('body',(-7,-4,-10),(14,10,20),'skin')
    for zi in range(7):
        for x in range(-2,3):
            y=-6-2*(2-abs(x));m.b('body',(x*2.8-1.5,y,-10+zi*3),(3,3.4,2.7),'plate')
            m.b('body',(x*2.8-1.5,y-.25,-10+zi*3),(3,.5,2.7),'edge')
            if x==0 and zi%2==0:m.b('body',(-.8,y-.6,-9.5+zi*3),(1.6,.5,1.7),'ember')
    m.bone('head',(0,12,-11),'head');m.b('head',(-4,-3,-4),(8,6,7),'skin');m.b('head',(-2.5,0,-7),(5,3,4),'skin');m.b('head',(-1.5,.3,-7.5),(3,1.5,1),'edge')
    m.face_eyes('head',-1,-4.3,2.5)
    for s in (-1,1):
        m.ear('ear'+str(s),'head',(s*2.5,-2,0),3,2,'skin','plate')
        for k,z in [('fl',-6),('hl',7)]:m.leg('leg_'+(k if s<0 else k.replace('l','r')),s*5.5,z,17,7,2.3,'skin','skin',True)
    m.bone('tail',(0,12,10),'tail')
    for i in range(8):m.b('tail',(-1.7+i*.12,i*.45,i*1.8),(3.4-i*.24,2.5,2),'plate' if i%2 else 'edge')
    return m

def sniffer():
    m=Model('sniffer',[('red','#985A51','fur'),('moss','#68874B','leaf'),('nose','#6C9D67','skin'),('wood','#6B573D','wood'),('fern','#91B967','leaf'),('seed','#D4AA5A','honey')])
    m.bone('body',(0,4,1),'body');m.b('body',(-12,-7,-17),(24,18,34),'red');m.b('body',(-11,-9,-15),(22,4,30),'moss')
    m.bone('head',(0,7,-18),'head');m.b('head',(-9,-6,-7),(18,12,13),'red');m.b('head',(-10,-1,-12),(20,8,7),'nose')
    for s in (-1,1):
        m.eye('head',s*8.7,-1,-3,s,False,3,2)
        m.b('head',(s*5-2,1,-12.5),(4,2.5,1),'black')
        for k,z in [('fl',-10),('hl',11)]:m.leg('leg_'+(k if s<0 else k.replace('l','r')),s*8.5,z,15,9,5,'red','wood')
        for z in range(-15,16,4):m.b('body',(s*11-1,-1,z),(2,10+(z%3),3.5),'red')
    for z in range(-12,14,5):
        m.b('body',(-10,-10,z),(20,2,3),'moss')
        m.b('body',(-9,-11,z+1),(7,2,2),'fern');m.b('body',(3,-11.5,z),(6,2.5,3),'fern')
    for x,z,height in [(-7,-8,12),(5,-4,15),(-2,6,9),(7,10,11)]:
        m.b('body',(x,-9-height,z),(1.4,height,1.4),'wood')
        for i in range(4):
            for s in (-1,1):m.b('body',(x+(s*1 if s>0 else -5),-10-height+i*2.3,z),(4.5,.8,1.8),'fern',(0,0,s*15))
        m.b('body',(x-1,-11-height,z-1),(3,2,3),'seed')
    for i in range(9):m.b('body',(-9+(i%3)*7,-10,-12+(i//3)*11),(3,1.5,3),'wood')
    return m

def mooshroom():
    m=Model('mooshroom',[('skin','#B9554D','skin'),('patch','#EEE2CE','fur'),('hoof','#624B47','stone'),('gill','#C9B99A','wool'),('cap','#C44842','skin'),('spore','#BFA560','honey')])
    m.bone('body',(0,5,1),'body');m.b('body',(-9,-7,-13),(18,16,27),'skin');m.b('body',(-10,-4,-6),(20,10,15),'skin')
    m.bone('head',(0,3,-14),'head');m.b('head',(-6,-5,-6),(12,11,11),'skin');m.b('head',(-5,1,-9),(10,5,4),'patch')
    m.face_eyes('head',-1,-6.5,4)
    for s in (-1,1):
        m.b('head',(s*2-1,2,-9.5),(2,1.5,.8),'hoof')
        m.ear('ear'+str(s),'head',(s*5,-2,1),4,4,'skin','patch',(0,0,s*65))
        for i in range(5):m.b('head',(s*(4+i*.35)-1,-6-i*1.3,-2+i*.3),(2.5,2,2.5),'ivory')
        for k,z in [('fl',-8),('hl',10)]:m.leg('leg_'+(k if s<0 else k.replace('l','r')),s*6.5,z,13,11,3.8,'skin','hoof')
        for i,(y,z,w,h) in enumerate([(-4,-10,4,5),(-2,-3,5,6),(1,6,4,5)]):m.b('body',(s*8.7-.3,y,z),(.7,h,w),'patch')
    for x,z,h,w in [(-4,-6,10,14),(4,7,14,17),(0,0,19,13)]:
        m.b('body',(x-1.2,-7-h,z-1.2),(2.4,h,2.4),'gill')
        for layer,(width,depth,hh) in enumerate([(w,w*.8,2),(w-3,w*.8-2,3),(w-6,w*.8-4,2)]):
            m.b('body',(x-width/2,-8-h-layer*2,z-depth/2),(width,hh,depth),'cap')
        for sx,sz in [(-3,-2),(2,2),(0,-4)]:m.b('body',(x+sx,-13-h,z+sz),(2.5,.8,2.5),'patch')
        for side in (-1,1):m.b('body',(x+side*(w/2-2),-8-h,z-2),(1,2,4),'spore')
    for s in (-1,1):
        for i in range(6):m.b('body',(s*8,-2+i*.9,-11+i*4),(1.5,3,1),'gill')
    m.bone('tail',(0,6,15),'tail');m.b('tail',(-1,-1,0),(2,8,2),'skin');m.b('tail',(-2,6,0),(4,4,3),'gill')
    return m

def strider():
    m=Model('strider',[('skin','#A9514C','skin'),('darkred','#743D45','skin'),('hair','#7C7C83','fur'),('obsidian','#343145','stone'),('lava','#EA9C4F','fire')])
    m.bone('body',(0,-1,0),'body');m.b('body',(-8,-8,-7),(16,17,14),'skin');m.b('body',(-7,-9,-6),(14,2,12),'darkred')
    m.bone('head',(0,-1,-6),'head');m.b('head',(-7,-5,-1),(14,11,2),'skin');m.face_eyes('head',-1,-1.6,4)
    for x in range(-5,6,2):m.b('head',(x,4,-1.8),(1.5,.8,1),'darkred')
    for s in (-1,1):
        n='leg_l' if s<0 else 'leg_r';m.bone(n,(s*5,7,0),n)
        m.b(n,(-1.4,0,-1.4),(2.8,15,2.8),'obsidian');m.b(n,(-2.5,14,-4),(5,3,7),'obsidian')
        for i in range(6):m.b(n,(-1.7,i*2.4,-1.7),(3.4,.7,3.4),'lava' if i%2 else 'darkred')
        for i in range(8):
            m.b('body',(s*7-1,-9+i*.8,-6+i*1.6),(2,8+i%3,1.5),'hair')
            m.b('body',(s*8,-2+i*.8,-6+i*1.7),(1,3,1),'lava')
    for i in range(7):m.b('body',(-6+i*2,-11,-4+(i%3)*3),(1.5,4,2),'hair')
    return m

def allay():
    m=Model('allay',[('bodyblue','#70CAE6','skin'),('wing','#BCECF1','glass'),('crystal','#89B6E4','ice'),('ribbon','#5598CF','cloth')])
    m.bone('body',(0,7,0),'float');m.b('body',(-2.5,-3,-1.5),(5,8,3),'bodyblue');m.b('body',(-1.5,4,-1),(3,5,2),'ribbon')
    m.bone('head',(0,1,0),'head');m.b('head',(-4,-4,-3),(8,7,6),'bodyblue');m.face_eyes('head',-1,-3.5,2.4,True)
    for s in (-1,1):
        arm='arm_l' if s<0 else 'arm_r';m.bone(arm,(s*3,5,0),arm);m.b(arm,(-.7,0,-.6),(1.4,7,1.2),'bodyblue');m.b(arm,(-1.1,6,-1),(2.2,2,2),'bodyblue')
        wing='wing_l' if s<0 else 'wing_r';m.bone(wing,(s*2,5,1),wing)
        for i in range(5):
            x=s*(i*2.8+1);m.b(wing,(min(x,x+s*3),-7+i,0),(3,13-i,1),'wing')
            m.b(wing,(min(x,x+s*3),-7+i,-.2),(3,1,1.4),'crystal');m.b(wing,(x,-6+i,-.3),(.6,8,1.6),'bodyblue')
        for i in range(3):m.b('body',(s*(4+i*1.6),-1+i*2,-3-i),(1.8,1.8,1.8),'crystal',(25,20,35))
    m.bone('orbit',(0,7,0),'orbit')
    for i in range(8):
        a=i*math.pi/4;m.b('orbit',(math.cos(a)*11,-3+math.sin(a)*3,math.sin(a)*7),(1.4,1.4,1.4),'glow')
    for i in range(5):m.b('body',(-2+i*.9,8+i*.6,0),(1,4,1),'ribbon')
    return m

def villager(trader=False):
    ident='wandering_trader' if trader else 'villager'
    m=Model(ident,[('skin','#B49D7D','skin'),('robe','#31558C' if trader else '#647653','cloth'),('trim','#D5BB6D','metal'),('darkcloth','#293C55' if trader else '#414E38','cloth'),('gem','#55BA87','ice'),('wood','#80613E','wood'),('armor','#776C55','metal'),('gold','#D5B85D','metal')])
    m.bone('body',(0,0,0),'body');m.b('body',(-5,-5,-3),(10,17,6),'robe')
    for layer in range(4):m.b('body',(-5.5-layer*.35,8+layer*3,-3.5-layer*.2),(11+layer*.7,3.4,7+layer*.4),'robe')
    for s in (-1,1):
        m.b('body',(s*4.7-.5,-4,-3.4),(1,16,1),'trim');m.b('body',(s*5-1,-4,-3),(2,4,7),'trim')
        for y in range(1,19,4):m.b('body',(s*2-1,y,-4.1),(2,2,.7),'darkcloth')
        n='leg_l' if s<0 else 'leg_r';m.bone(n,(s*2.5,15,0),n);m.b(n,(-1.8,0,-1.8),(3.6,8,3.6),'darkcloth');m.b(n,(-2,7,-3),(4,2,5),'black')
        arm='arm_l' if s<0 else 'arm_r';m.bone(arm,(s*5,-3,0),'none',rotation=(0,0,s*-25))
        m.b(arm,(-1.8,0,-1.8),(3.6,8,3.6),'robe');m.b(arm,(-1.6,6,-5),(3.2,3.2,5),'skin')
        m.b(arm,(-1.9,5.5,-2),(3.8,1,4),'trim')
    m.bone('head',(0,-7,0),'head');m.b('head',(-4,-7,-4),(8,10,8),'skin');m.b('head',(-1.2,-1.5,-7),(2.4,5,3),'skin')
    m.face_eyes('head',-3.3,-4.3,2.1)
    m.b('head',(-4.1,-4.5,-4.5),(8.2,1,1),'darkcloth');m.b('head',(-1,-1,-7.2),(2,2,.6),'darkcloth')
    if trader:
        for i in range(4):m.b('head',(-4.6,-8+i*.9,-4.6),(9.2,1.2,9.2),'robe')
        m.b('head',(-1.5,-7,-5),(3,3,1),'trim');m.b('head',(-.8,-6.5,-5.4),(1.6,1.6,.6),'gem')
        crate(m,'body',-5,-8,4,10,12,7)
        crate(m,'body',-4,-15,5,8,7,6,'robe')
        for s in (-1,1):
            for y in range(-4,17,4):m.b('body',(s*6-1,y,3),(2,4.3,5),'robe')
            m.b('body',(s*6-1,15,3),(2,1,5),'trim')
        for z in range(5,11,2):m.b('body',(-7,-7,z),(2,8,1.5),'wood')
    else:
        m.b('head',(-4.5,-8,-4.5),(9,2,9),'darkcloth');m.b('head',(-3.5,-9.5,-3.5),(7,1.5,7),'robe')
        for s in (-1,1):m.b('body',(s*5-1,-6,-3.5),(2,5,7),'gem')
        m.bone('sigils',(0,-1,0),'orbit')
        for i in range(3):
            x=-10+i*10;z=5 if i==1 else 0
            m.b('sigils',(x-2,-8,z),(4,6,1),'gem');m.b('sigils',(x-1,-9,z),(2,8,1),'glow')
            for s in (-1,1):m.b('sigils',(x+s*2,-6,z),(1,2,1),'trim')
    return m

def iron_golem():
    m=Model('iron_golem',[('iron','#B7BBAA','metal'),('seam','#69736C','metal'),('vine','#638A4D','leaf'),('flower','#BB5750','leaf'),('gold','#D3B77A','metal')])
    m.bone('body',(0,0,0),'body');m.b('body',(-8,-8,-4),(16,17,9),'iron');m.b('body',(-11,-6,-4.5),(22,7,10),'iron')
    m.b('body',(-6,8,-3),(12,8,7),'seam');m.b('body',(-3,-1,-4.8),(6,7,1),'gold')
    for i in range(4):m.b('body',(-2.7+i*1.5,0,-5),(1,5,.7),'glow')
    m.bone('head',(0,-12,-1),'head');m.b('head',(-4,-6,-4),(8,10,8),'iron');m.b('head',(-1.5,-1,-7),(3,4,3),'iron');m.face_eyes('head',-2.5,-4.5,2.5)
    m.b('head',(-4,-3.8,-4.7),(8,.9,1),'seam')
    for s in (-1,1):
        n='arm_l' if s<0 else 'arm_r';m.bone(n,(s*10,-5,0),n)
        m.b(n,(-3,-1,-3),(6,18,6),'iron');m.b(n,(-3.7,-2,-3.7),(7.4,6,7.4),'seam');m.b(n,(-3.5,7,-3.5),(7,2,7),'gold')
        m.b(n,(-3.5,16,-3.7),(7,5,7.4),'iron')
        for finger in range(4):m.b(n,(-3+finger*1.5,18,-4.2),(1.1,4,1.3),'seam')
        for y in range(1,14,3):m.b(n,(-3.2,y,-3.2),(1.2,2.8,1.2),'vine')
        leg='leg_l' if s<0 else 'leg_r';m.bone(leg,(s*4,14,0),leg);m.b(leg,(-2.5,0,-2.5),(5,9,5),'iron');m.b(leg,(-3,8,-4),(6,2,8),'iron')
        m.b(leg,(-2.7,3,-2.7),(5.4,1,5.4),'seam')
    for y in range(-6,12,3):m.b('body',(-6+y*.08,y,-4.9),(1.4,3.2,1),'vine')
    for x,y in [(-8,-5),(-7,-1),(5,3)]:
        m.b('body',(x,y,-5.5),(2,2,1),'gold')
        for dx,dy in [(-1,0),(1,0),(0,-1),(0,1)]:m.b('body',(x+dx,y+dy,-5.7),(1.6,1.6,.8),'flower')
    return m

def snow_golem():
    m=Model('snow_golem',[('snow','#E5EFF0','wool'),('ice','#9BCBD8','ice'),('pumpkin','#BD7D36','wood'),('rind','#85602D','wood'),('wood','#6B513D','wood')])
    m.bone('body',(0,9,0),'body')
    for y,w,d in [(5,16,14),(-1,13,12),(-7,10,10)]:
        m.b('body',(-w/2,y,-d/2),(w,7,d),'snow')
        m.b('body',(-w/2-.5,y+5,-d/2-.5),(w+1,1.5,d+1),'ice')
    m.bone('head',(0,-5,0),'head');m.b('head',(-5,-5,-5),(10,10,10),'pumpkin')
    for x in range(-4,5,2):m.b('head',(x,-5.2,-5.2),(1,10.4,10.4),'rind')
    for s in (-1,1):m.b('head',(s*2-1,-2,-5.7),(2,2,1),'black');m.b('head',(s*2-.6,-1.6,-5.9),(1.2,1.1,1),'glow')
    for x in (-3,-1,1,3):m.b('head',(x,2,-5.8),(1.7,1,1),'black')
    m.b('head',(-1,-7,-1),(2,2,2),'wood')
    for s in (-1,1):
        n='arm_l' if s<0 else 'arm_r';m.bone(n,(s*5,2,0),n)
        for i in range(4):m.b(n,(s*i*2-1,-i*1.3,0),(3,1.6,1.8),'wood',(0,0,s*-16))
        for finger in range(3):m.b(n,(s*7-1,-5+finger*2,0),(4,.9,1.2),'wood',(0,0,(finger-1)*25))
        for i in range(4):m.b(n,(s*i*2-1,-i*1.3-.5,-.2),(2,.5,2.2),'ice')
    m.b('body',(-3,-2,-6.5),(6,6,1.5),'ice');m.b('body',(-1.8,-1,-7),(3.6,4,1),'glow')
    for i in range(7):m.b('body',(-7+i*2,11,-7),(1.3,2.5,1.5),'snow')
    return m

def happy_ghast():
    m=Model('happy_ghast',[('cloud','#E4E8E9','wool'),('shadow','#B6CAD6','wool'),('wood','#AA855E','wood'),('rope','#BDAE85','cloth'),('blue','#79B2D3','cloth'),('gold','#D9C47F','metal')])
    m.bone('body',(0,-2,0),'float');m.b('body',(-13,-11,-12),(26,23,24),'cloud')
    for x,y,z,w,h,d in [(-15,-7,-7,4,13,13),(11,-6,-7,4,12,14),(-9,-13,-8,18,3,16),(-9,9,-9,18,5,18)]:m.b('body',(x,y,z),(w,h,d),'cloud')
    m.bone('head',(0,-2,-12),'head');m.face_eyes('head',-4,-.6,7,True)
    for s in (-1,1):m.b('head',(s*6-2,-5,-.4),(4,1,.7),'shadow');m.b('head',(s*5-1,3,-.7),(2,2,.8),'shadow')
    m.b('head',(-4,5,-.7),(8,1.2,.8),'shadow')
    for x,z in [(-8,-7),(8,-7),(-8,7),(8,7)]:
        n='tentacle_'+str(x)+'_'+str(z);m.bone(n,(x,9,z),'tentacle')
        for i in range(5):
            m.b(n,(-1.8,3*i,-1.8),(3.6,3.4,3.6),'cloud');m.b(n,(-2,3*i+2.5,-2),(4,.7,4),'gold' if i==4 else 'shadow')
    for x in range(-10,11,4):m.b('body',(x,-15,-9),(3.6,2.5,19),'wood')
    for s in (-1,1):
        m.b('body',(s*10,-20,-8),(1,6,18),'wood');m.b('body',(s*11,-8,-12.4),(2,18,1),'rope')
        for z in (-8,0,8):m.b('body',(s*10,-22,z),(1,9,1),'wood')
    for i in range(6):m.b('body',(-8+i*3,-21,8.5),(2.8,4,.8),'blue' if i%2 else 'gold')
    for i in range(12):m.b('body',(-12+(i%4)*7,-10+(i//4)*7,12),(4,4,2),'shadow' if i%3==0 else 'cloud')
    return m

def copper_golem():
    m=Model('copper_golem',[('copper','#BE815B','metal'),('darkcopper','#855E49','metal'),('patina','#70A68B','metal'),('tool','#6C7378','metal'),('gold','#D2AF69','metal')])
    m.bone('body',(0,6,0),'body');m.b('body',(-6,-5,-4),(12,12,9),'copper');m.b('body',(-5,-6,-3),(10,2,7),'darkcopper')
    m.b('body',(-4,-2,-4.7),(8,6,1),'darkcopper');m.b('body',(-2,-.5,-5.1),(4,3,.8),'glow')
    m.bone('head',(0,-3,-1),'head');m.b('head',(-5,-5,-4),(10,10,9),'copper');m.b('head',(-1.5,-.5,-8),(3,4,4),'copper')
    m.face_eyes('head',-2,-4.5,3)
    m.b('head',(-1,-10,-1),(2,5,2),'darkcopper');m.b('head',(-2,-11,-2),(4,1.5,4),'copper');m.b('head',(-.5,-13,-.5),(1,2,1),'gold')
    for s in (-1,1):
        arm='arm_l' if s<0 else 'arm_r';m.bone(arm,(s*7,2,0),arm)
        m.b(arm,(-2,-1,-2),(4,9,4),'copper');m.b(arm,(-2.5,2,-2.5),(5,2,5),'darkcopper')
        m.b(arm,(-2.6,8,-2.8),(5.2,4,5.6),'copper')
        for finger in range(3):m.b(arm,(-2+finger*1.6,10,-3.4),(1.1,3,1.5),'darkcopper')
        leg='leg_l' if s<0 else 'leg_r';m.bone(leg,(s*3,14,0),leg);m.b(leg,(-2,0,-2),(4,8,4),'copper');m.b(leg,(-2.5,7,-3.5),(5,3,6),'darkcopper')
        m.b(leg,(-2.2,3,-2.2),(4.4,1,4.4),'patina')
        for y,z in [(-3,2),(1,-2),(5,1)]:m.b('body',(s*5.8-.2,y,z),(.7,2,2),'patina')
    crate(m,'body',-5,-4,5,10,9,5,'darkcopper')
    for x in (-3,0,3):
        m.b('body',(x-.5,-10,6),(1,7,1),'tool');m.b('body',(x-1.7,-11,5.5),(3.4,2,2),'tool')
    for x,y in [(-3,-4),(2,0),(-2,3)]:m.b('head',(x,y,-4.6),(2,2,.7),'patina')
    for i in range(4):m.b('body',(-5+i*3,-5,-4.5),(.8,.8,.7),'gold')
    return m

def main():
    models=[rabbit(),goat(),horse(),donkey(),mule(),camel(),llama(),llama(True),skeleton_horse(),zombie_horse(),
            feline('cat'),feline('ocelot'),feline('fox'),panda(),polar_bear(),bat(),parrot(),frog(),armadillo(),sniffer(),
            mooshroom(),strider(),allay(),villager(),villager(True),iron_golem(),snow_golem(),happy_ghast(),copper_golem()]
    for m in models:m.write()
    print('TOTAL',len(models),'models',sum(len(m.boxes) for m in models),'meaningful cuboids')

if __name__=='__main__':main()
