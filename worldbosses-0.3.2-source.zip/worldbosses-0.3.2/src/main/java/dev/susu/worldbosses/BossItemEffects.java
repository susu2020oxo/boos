package dev.susu.worldbosses;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.*;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.block.*;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.*;
import net.minecraft.entity.*;
import net.minecraft.entity.damage.*;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.effect.*;
import net.minecraft.entity.mob.*;
import net.minecraft.entity.passive.*;
import net.minecraft.entity.player.*;
import net.minecraft.entity.projectile.*;
import net.minecraft.entity.projectile.thrown.SnowballEntity;
import net.minecraft.inventory.*;
import net.minecraft.item.*;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.*;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.tag.*;
import net.minecraft.screen.*;
import net.minecraft.screen.slot.Slot;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.property.Properties;
import net.minecraft.text.Text;
import net.minecraft.util.*;
import net.minecraft.util.collection.DefaultedList;
import net.minecraft.util.hit.*;
import net.minecraft.util.math.*;
import net.minecraft.world.World;
import java.util.*;

/** Each named action is an actual mechanic; no fallback universal buff/essence implementation. */
public final class BossItemEffects {
    private static final Map<UUID,Map<String,Long>> TIMERS=new HashMap<>();
    private static final Set<UUID> DOUBLE_JUMPED=new HashSet<>();
    private static final Map<UUID,Integer> SPRINT=new HashMap<>();
    private static final List<Decoy> DECOYS=new ArrayList<>();
    private static final List<Blast> BLASTS=new ArrayList<>();
    private static final Map<StepKey,Step> STEPS=new HashMap<>();
    private static final ThreadLocal<Boolean> BONUS_DAMAGE=ThreadLocal.withInitial(()->false);
    private record Decoy(ServerWorld world,ArmorStandEntity dummy,long until,UUID owner){}
    private record Blast(ServerWorld world,Vec3d position,long at,UUID owner,float damage,double radius,boolean destructive){}
    private record StepKey(ServerWorld world,BlockPos pos){}
    private record Step(BlockState original,long until){}
    public static final Block COOLING_STEP=Registry.register(Registries.BLOCK,WorldBosses.id("cooling_step"),
            new Block(AbstractBlock.Settings.copy(Blocks.BASALT).registryKey(RegistryKey.of(RegistryKeys.BLOCK,WorldBosses.id("cooling_step"))).dropsNothing().strength(.6f)));

    public static void register() {
        ServerTickEvents.END_WORLD_TICK.register(BossItemEffects::tick);
        ServerLivingEntityEvents.AFTER_DAMAGE.register(BossItemEffects::onHit);
        ServerLivingEntityEvents.AFTER_DEATH.register((entity,source)->{
            if(source.getAttacker() instanceof ServerPlayerEntity p) {
                var s=BossItems.spec(p.getMainHandStack());
                if(s!=null&&s.action().equals("undead_reap")&&entity.getType().isIn(EntityTypeTags.UNDEAD)&&ready(p,"undead_reap",160)) {
                    p.heal(6);p.removeStatusEffect(StatusEffects.HUNGER);spark((ServerWorld)p.getEntityWorld(),p.getEntityPos(),ParticleTypes.SOUL,12);
                }
            }
        });
        UseEntityCallback.EVENT.register((player,world,hand,entity,hit)->{
            if(!(world instanceof ServerWorld server)||hand!=Hand.MAIN_HAND)return ActionResult.PASS;
            for(Hand candidate:Hand.values()) {
                ItemStack stack=player.getStackInHand(candidate);var s=BossItems.spec(stack);
                if(s!=null&&interact(s,server,player,stack,candidate,entity))return ActionResult.SUCCESS;
            }
            return ActionResult.PASS;
        });
        ServerLifecycleEvents.SERVER_STOPPING.register(server->{
            for(var e:STEPS.entrySet())if(e.getKey().world.getBlockState(e.getKey().pos).isOf(COOLING_STEP))
                e.getKey().world.setBlockState(e.getKey().pos,e.getValue().original);
            for(var decoy:DECOYS)decoy.dummy.discard();
            TIMERS.clear();DOUBLE_JUMPED.clear();SPRINT.clear();DECOYS.clear();BLASTS.clear();STEPS.clear();
        });
    }
    private static long now(PlayerEntity p){return p.getEntityWorld().getTime();}
    public static boolean active(PlayerEntity p,String key){return !key.startsWith("cd_")&&TIMERS.getOrDefault(p.getUuid(),Map.of()).getOrDefault(key,0L)>now(p);}
    public static void mark(PlayerEntity p,String key,int ticks){if(key.startsWith("cd_"))return;TIMERS.computeIfAbsent(p.getUuid(),k->new HashMap<>()).put(key,now(p)+ticks);}
    public static boolean ready(PlayerEntity p,String key,int ticks){return true;}
    // v0.3: abilities never require fuel, payment or durability. Inputs being transformed remain real inputs.
    private static boolean consume(PlayerEntity player,Item item,int count){return true;}
    private static void wear(ItemStack stack,PlayerEntity p,Hand hand,int n){}
    private static void effect(LivingEntity e,RegistryEntry<StatusEffect> kind,int ticks,int level){e.addStatusEffect(new StatusEffectInstance(kind,e instanceof PlayerEntity&&kind.value().getCategory()==StatusEffectCategory.BENEFICIAL?ticks*3:ticks,level,false,true,true));}
    private static void spark(ServerWorld w,Vec3d p,net.minecraft.particle.ParticleEffect kind,int n){w.spawnParticles(kind,p.x,p.y+.5,p.z,n,.35,.35,.35,.025);}
    private static List<MobEntity> targets(ServerWorld world,PlayerEntity owner,Vec3d center,double radius) {
        return world.getEntitiesByClass(MobEntity.class,Box.of(center,radius*2,radius*2,radius*2),m->m.isAlive()
                &&m.squaredDistanceTo(center)<=radius*radius&&!(m instanceof TameableEntity t&&t.getOwner()==owner));
    }
    private static boolean hit(ServerWorld world,PlayerEntity owner,LivingEntity target,float amount) {
        if(target==owner)return false;return target.damage(world,world.getDamageSources().playerAttack(owner),amount);
    }
    private static ItemStack offhandOther(PlayerEntity player,Hand hand){return player.getStackInHand(hand==Hand.MAIN_HAND?Hand.OFF_HAND:Hand.MAIN_HAND);}
    private static BlockPos aimed(PlayerEntity p,BlockPos block){return block==null?BlockPos.ofFloored(p.raycast(8,1,false).getPos()):block;}

    public static boolean use(LootCatalog.Spec spec,World world,PlayerEntity player,ItemStack stack,Hand hand,BlockPos block) {
        if(player==null)return false;
        if(!(world instanceof ServerWorld server))return true;
        String action=spec.action();if(active(player,"cd_"+action))return false;
        Vec3d look=player.getRotationVec(1),position=player.getEntityPos();
        BlockPos pos=aimed(player,block);boolean done=false;
        switch(action) {
            case "basalt_guard" -> {
                for(var m:targets(server,player,position,3))m.takeKnockback(.8,player.getX()-m.getX(),player.getZ()-m.getZ());
                spark(server,position,ParticleTypes.CRIT,20);done=true;
            }
            case "feather_glide" -> {if(!player.isOnGround()){effect(player,StatusEffects.SLOW_FALLING,100,0);player.addVelocity(0,.2,0);player.velocityModified=true;done=true;}}
            case "cliff_climb" -> {
                var ray=player.raycast(3,1,false);
                if(ray instanceof BlockHitResult b&&b.getType()==HitResult.Type.BLOCK&&!b.getSide().getAxis().isVertical()) {
                    player.addVelocity(0,.6,0);player.velocityModified=true;effect(player,StatusEffects.SLOW_FALLING,40,0);done=true;
                }
            }
            case "mount_dash" -> {
                if(player.getVehicle() instanceof LivingEntity mount) {
                    mount.setVelocity(look.x*.85,Math.max(.1,mount.getVelocity().y),look.z*.85);mount.velocityModified=true;
                    mount.removeStatusEffect(StatusEffects.SLOWNESS);spark(server,mount.getEntityPos(),ParticleTypes.ELECTRIC_SPARK,16);done=true;
                }
            }
            case "vacuum_items","selective_magnet" -> {
                ItemStack filter=offhandOther(player,hand);if(action.equals("selective_magnet")&&filter.isEmpty())break;
                double range=action.equals("vacuum_items")?12:24;
                for(ItemEntity item:server.getEntitiesByClass(ItemEntity.class,player.getBoundingBox().expand(range),e->e.isAlive())) {
                    if(action.equals("selective_magnet")&&!item.getStack().isOf(filter.getItem()))continue;
                    ItemStack cargo=item.getStack().copy();int before=cargo.getCount();player.getInventory().insertStack(cargo);
                    if(cargo.isEmpty())item.discard();else item.setStack(cargo);
                    if(cargo.getCount()<before){done=true;spark(server,item.getEntityPos(),ParticleTypes.NOTE,2);}
                }
            }
            case "repair_offhand" -> {
                ItemStack target=offhandOther(player,hand);
                if(target.isDamageable()&&target.isDamaged()&&consume(player,Items.IRON_INGOT,1)) {target.setDamage(Math.max(0,target.getDamage()-256));done=true;}
            }
            case "caravan_call" -> {
                for(var m:targets(server,player,position,10))if(m instanceof AnimalEntity animal&&!(animal instanceof TameableEntity t&&t.isTamed()&&t.getOwner()!=player)) {
                    animal.getNavigation().startMovingTo(player,1.05);mark(player,"caravan",160);done=true;
                }
            }
            case "field_cook" -> {
                var raw=offhandOther(player,hand);
                Map<Item,Item> cooked=Map.of(Items.PORKCHOP,Items.COOKED_PORKCHOP,Items.BEEF,Items.COOKED_BEEF,Items.MUTTON,Items.COOKED_MUTTON,
                        Items.CHICKEN,Items.COOKED_CHICKEN,Items.RABBIT,Items.COOKED_RABBIT,Items.COD,Items.COOKED_COD,Items.SALMON,Items.COOKED_SALMON);
                if(cooked.containsKey(raw.getItem())&&consume(player,Items.COAL,1)) {
                    int n=Math.min(64,raw.getCount());Item result=cooked.get(raw.getItem());raw.decrement(n);
                    ItemStack output=new ItemStack(result,n);player.getInventory().insertStack(output);if(!output.isEmpty())player.dropItem(output,false);done=true;
                }
            }
            case "bamboo_garden" -> {
                for(int dx=-1;dx<=1;dx++)for(int dz=-1;dz<=1;dz++) {
                    BlockPos plant=pos.add(dx,1,dz);
                    if(server.getBlockState(plant).isReplaceable()&&Blocks.BAMBOO.getDefaultState().canPlaceAt(server,plant)&&server.canEntityModifyAt(player,plant)&&consume(player,Items.BAMBOO,1)) {
                        server.setBlockState(plant,Blocks.BAMBOO.getDefaultState());done=true;
                    }
                }
            }
            case "echo_scan" -> {
                for(var m:targets(server,player,position,24))if(m instanceof HostileEntity){effect(m,StatusEffects.GLOWING,140,0);done=true;}
                spark(server,position,ParticleTypes.SONIC_BOOM,1);
            }
            case "prismatic_decoy" -> {
                Vec3d at=position.add(look.multiply(4));ArmorStandEntity dummy=new ArmorStandEntity(server,at.x,at.y,at.z);
                dummy.setInvisible(true);dummy.setInvulnerable(true);dummy.setNoGravity(true);dummy.addCommandTag("worldbosses:decoy");
                server.spawnEntity(dummy);DECOYS.add(new Decoy(server,dummy,server.getTime()+120,player.getUuid()));spark(server,at,ParticleTypes.END_ROD,25);done=true;
            }
            case "tongue_pull" -> {
                Entity nearest=server.getOtherEntities(player,player.getBoundingBox().expand(8),e->e instanceof ItemEntity||e instanceof MobEntity)
                        .stream().filter(e->player.canSee(e)&&e.getEntityPos().subtract(player.getEyePos()).normalize().dotProduct(look)>.9)
                        .min(Comparator.comparingDouble(player::squaredDistanceTo)).orElse(null);
                if(nearest!=null){Vec3d velocity=player.getEntityPos().subtract(nearest.getEntityPos()).normalize().multiply(.65);nearest.setVelocity(velocity.x,.25,velocity.z);nearest.velocityModified=true;done=true;}
            }
            case "seed_excavate" -> {
                BlockState soil=server.getBlockState(pos);
                if((soil.isIn(BlockTags.DIRT)||soil.isOf(Blocks.MUD))&&consume(player,Items.BONE_MEAL,1)&&server.canEntityModifyAt(player,pos)) {
                    Item seed=server.random.nextBoolean()?Items.TORCHFLOWER_SEEDS:Items.PITCHER_POD;
                    player.giveItemStack(new ItemStack(seed));spark(server,pos.toCenterPos(),ParticleTypes.COMPOSTER,15);done=true;
                }
            }
            case "thermal_patch" -> {
                ItemStack armor=offhandOther(player,hand);
                if(armor.get(DataComponentTypes.EQUIPPABLE)!=null&&consume(player,Items.MAGMA_CREAM,1)) {
                    NbtComponent.set(DataComponentTypes.CUSTOM_DATA,armor,n->n.putInt("worldbosses_heatproof",1));done=true;
                }
            }
            case "waypoint_chart" -> {
                if(player.isSneaking()) {
                    NbtComponent.set(DataComponentTypes.CUSTOM_DATA,stack,n->{n.putInt("x",player.getBlockX());n.putInt("y",player.getBlockY());n.putInt("z",player.getBlockZ());n.putString("dimension",server.getRegistryKey().getValue().toString());});
                    player.sendMessage(Text.literal("已记录旅途路标"),true);done=true;
                } else {
                    NbtCompound data=stack.getOrDefault(DataComponentTypes.CUSTOM_DATA,NbtComponent.DEFAULT).copyNbt();
                    if(data.contains("x")) {
                        Vec3d point=new Vec3d(data.getInt("x",0)+.5,data.getInt("y",0),data.getInt("z",0)+.5);
                        player.sendMessage(Text.literal("路标 "+data.getInt("x",0)+", "+data.getInt("y",0)+", "+data.getInt("z",0)+" · "+Math.round(point.distanceTo(position))+" 格"),true);
                        if(data.getString("dimension","").equals(server.getRegistryKey().getValue().toString())) {
                            Vec3d d=point.subtract(player.getEyePos()).normalize();for(int i=1;i<=8;i++)spark(server,player.getEyePos().add(d.multiply(i)),ParticleTypes.END_ROD,1);
                        }done=true;
                    }
                }
            }
            case "rotate_block" -> {
                BlockState s=server.getBlockState(pos);
                if(server.canEntityModifyAt(player,pos)) {
                    if(s.contains(Properties.HORIZONTAL_FACING)){server.setBlockState(pos,s.with(Properties.HORIZONTAL_FACING,s.get(Properties.HORIZONTAL_FACING).rotateYClockwise()));done=true;}
                    else if(s.contains(Properties.AXIS)){server.setBlockState(pos,s.cycle(Properties.AXIS));done=true;}
                    else if(s.contains(Properties.FACING)){server.setBlockState(pos,s.cycle(Properties.FACING));done=true;}
                }
            }
            case "till_plane" -> {
                for(int dx=-2;dx<=2;dx++)for(int dz=-2;dz<=2;dz++) {
                    BlockPos q=pos.add(dx,0,dz);BlockState s=server.getBlockState(q);
                    if(server.canEntityModifyAt(player,q)&&server.getBlockState(q.up()).isAir()&&(s.isOf(Blocks.DIRT)||s.isOf(Blocks.GRASS_BLOCK)||s.isOf(Blocks.DIRT_PATH))) {
                        server.setBlockState(q,Blocks.FARMLAND.getDefaultState());wear(stack,player,hand,1);done=true;
                    }
                }
            }
            case "grapple" -> {
                HitResult ray=player.raycast(24,1,false);
                if(ray.getType()==HitResult.Type.BLOCK) {Vec3d pull=ray.getPos().subtract(player.getEyePos()).normalize().multiply(.8);player.setVelocity(pull.x,Math.min(.65,pull.y+.2),pull.z);player.velocityModified=true;done=true;}
            }
            case "safe_blink" -> done=blink(server,player);
            case "remote_pickup" -> {
                var remote=server.getEntitiesByClass(ItemEntity.class,player.getBoundingBox().expand(18),e->player.canSee(e)&&e.getEntityPos().subtract(player.getEyePos()).normalize().dotProduct(look)>.96)
                        .stream().min(Comparator.comparingDouble(player::squaredDistanceTo)).orElse(null);
                if(remote!=null){remote.setPosition(player.getEntityPos());spark(server,position,ParticleTypes.PORTAL,15);done=true;}
            }
            case "distill_potion" -> {
                ItemStack potion=offhandOther(player,hand);var data=potion.getOrDefault(DataComponentTypes.CUSTOM_DATA,NbtComponent.DEFAULT).copyNbt();
                var contents=potion.get(DataComponentTypes.POTION_CONTENTS);
                if(contents!=null&&!data.getBoolean("worldbosses_distilled",false)) {
                    List<StatusEffectInstance> effects=new ArrayList<>();
                    for(var e:contents.getEffects())if(e.getEffectType().value().getCategory()!=StatusEffectCategory.HARMFUL)
                        effects.add(new StatusEffectInstance(e.getEffectType(),Math.min(18000,(int)(e.getDuration()*2)),e.getAmplifier()));
                    potion.set(DataComponentTypes.POTION_CONTENTS,new PotionContentsComponent(Optional.empty(),Optional.empty(),effects,Optional.empty()));
                    NbtComponent.set(DataComponentTypes.CUSTOM_DATA,potion,n->n.putBoolean("worldbosses_distilled",true));done=true;
                }
            }
            case "vein_mine" -> {
                if(player instanceof ServerPlayerEntity p&&Registries.BLOCK.getId(server.getBlockState(pos).getBlock()).getPath().endsWith("_ore")) {
                    Block original=server.getBlockState(pos).getBlock();Deque<BlockPos> todo=new ArrayDeque<>();Set<BlockPos> seen=new HashSet<>();todo.add(pos);
                    int mined=0;while(!todo.isEmpty()&&mined<32) {
                        BlockPos q=todo.removeFirst();if(!seen.add(q)||!server.getBlockState(q).isOf(original)||q.getSquaredDistance(pos)>36)continue;
                        if(p.interactionManager.tryBreakBlock(q)){mined++;for(Direction dir:Direction.values())todo.add(q.offset(dir));}
                    }done=mined>0;
                }
            }
            case "pocket_vault" -> {openPocket(player,stack);done=true;}
            case "tomb_slam","shield_cleaver","rot_sweep","sonic_wave" -> {
                int count=0;double reach=action.equals("sonic_wave")?10:4;
                for(var target:targets(server,player,position,reach)) {
                    Vec3d delta=target.getEntityPos().add(0,target.getHeight()*.5,0).subtract(player.getEyePos());
                    double dot=delta.normalize().dotProduct(look);
                    if(dot<(action.equals("sonic_wave")?.985:.4)||!player.canSee(target))continue;
                    if(action.equals("sonic_wave")&&count>=3)break;
                    hit(server,player,target,spec.power());target.takeKnockback(.5,player.getX()-target.getX(),player.getZ()-target.getZ());
                    if(action.equals("rot_sweep"))effect(target,StatusEffects.WEAKNESS,80,0);count++;
                }spark(server,position,action.equals("sonic_wave")?ParticleTypes.SONIC_BOOM:ParticleTypes.CRIT,action.equals("sonic_wave")?1:20);done=true;
            }
            case "mounted_lance","wraith_dash" -> {
                player.setVelocity(look.x*.8,.16,look.z*.8);player.velocityModified=true;mark(player,"charged_"+action,80);done=true;
            }
            case "brute_charge" -> {mark(player,"charged_brute",100);effect(player,StatusEffects.SLOWNESS,20,0);spark(server,position,ParticleTypes.CRIT,20);done=true;}
            case "fang_line" -> {
                for(int i=1;i<=9;i++){Vec3d q=position.add(look.x*i*1.5,0,look.z*i*1.5);server.spawnEntity(new EvokerFangsEntity(server,q.x,q.y,q.z,player.getYaw()*((float)Math.PI/180),i*3,player));}done=true;
            }
            case "root_bind" -> {
                var target=targets(server,player,position,10).stream().filter(e->player.canSee(e)&&e.getEntityPos().subtract(player.getEyePos()).normalize().dotProduct(look)>.9)
                        .min(Comparator.comparingDouble(player::squaredDistanceTo)).orElse(null);
                if(target!=null){effect(target,StatusEffects.SLOWNESS,80,5);target.getNavigation().stop();target.setVelocity(0,0,0);spark(server,target.getEntityPos(),ParticleTypes.COMPOSTER,30);done=true;}
            }
            case "frost_snowball","crack_grenade","blaze_bolt","ghast_shell" -> {
                Item fuel=switch(action){case "frost_snowball"->Items.SNOWBALL;case "blaze_bolt"->Items.BLAZE_POWDER;default->Items.GUNPOWDER;};
                if(consume(player,fuel,1)) {
                    SnowballEntity shot=new SnowballEntity(server,player,new ItemStack(action.equals("frost_snowball")?Items.SNOWBALL:Items.FIRE_CHARGE));
                    shot.addCommandTag("worldbosses:shot:"+action);shot.setVelocity(player,player.getPitch(),player.getYaw(),0,action.equals("ghast_shell")?.9f:1.45f,1);
                    server.spawnEntity(shot);done=true;
                }
            }
            case "wind_launch" -> {
                if(consume(player,Items.WIND_CHARGE,1)) {
                    player.setVelocity(player.getVelocity().x, .9,player.getVelocity().z);player.velocityModified=true;effect(player,StatusEffects.SLOW_FALLING,100,0);
                    for(var t:targets(server,player,position,3))t.takeKnockback(.9,player.getX()-t.getX(),player.getZ()-t.getZ());done=true;
                }
            }
            case "piglin_pass" -> {
                if(consume(player,Items.GOLD_INGOT,1)){mark(player,"piglin_peace",400);done=true;}
            }
            default -> {} // Passive equipment, food and normal ranged weapons use their dedicated hooks below.
        }
        if(done) {
            mark(player,"cd_"+action,spec.cooldown_ticks());
            // No item cooldown is installed; buff lifetimes and projectile fuses are not cooldowns.
            wear(stack,player,hand,action.equals("seed_excavate")?4:1);
        }
        return done;
    }

    private static boolean blink(ServerWorld w,PlayerEntity p) {
        var ray=p.raycast(16,1,false);BlockPos candidate=ray instanceof BlockHitResult hit?hit.getBlockPos().offset(hit.getSide()):BlockPos.ofFloored(ray.getPos());
        for(int down=0;down<4;down++) {
            BlockPos feet=candidate.down(down);Vec3d destination=new Vec3d(feet.getX()+.5,feet.getY(),feet.getZ()+.5);
            if(w.getBlockState(feet.down()).isSolidBlock(w,feet.down())&&w.getFluidState(feet).isEmpty()
                    &&w.isSpaceEmpty(p,p.getBoundingBox().offset(destination.subtract(p.getEntityPos())))) {
                spark(w,p.getEntityPos(),ParticleTypes.PORTAL,20);p.requestTeleport(destination.x,destination.y,destination.z);spark(w,destination,ParticleTypes.PORTAL,20);return true;
            }
        }return false;
    }
    private static boolean interact(LootCatalog.Spec s,ServerWorld world,PlayerEntity p,ItemStack stack,Hand hand,Entity target) {
        if(active(p,"cd_"+s.action()))return false;
        if(s.action().equals("restock_offer")&&target instanceof VillagerEntity villager) {
            for(var offer:villager.getOffers())if(offer.isDisabled()&&consume(p,Items.EMERALD,1)){offer.resetUses();mark(p,"cd_"+s.action(),s.cooldown_ticks());wear(stack,p,hand,1);return true;}
        }
        if(s.action().equals("trade_seal")&&target instanceof VillagerEntity&&consume(p,Items.EMERALD,1)) {
            effect(p,StatusEffects.HERO_OF_THE_VILLAGE,1200,0);mark(p,"cd_"+s.action(),s.cooldown_ticks());wear(stack,p,hand,1);return true;
        }
        return false;
    }
    public static void eat(LootCatalog.Spec s,PlayerEntity p) {
        switch(s.action()) {
            case "ember_meal" -> {p.extinguish();p.heal(9);effect(p,StatusEffects.FIRE_RESISTANCE,400,0);}
            case "royal_detox" -> {p.removeStatusEffect(StatusEffects.POISON);p.heal(6);mark(p,"poison_immunity",1800);}
            case "desert_provision" -> {p.removeStatusEffect(StatusEffects.HUNGER);mark(p,"desert_provision",1800);}
            case "fungal_stew" -> {p.removeStatusEffect(StatusEffects.POISON);p.removeStatusEffect(StatusEffects.WITHER);effect(p,StatusEffects.ABSORPTION,900,2);}
            case "purifying_broth" -> {p.removeStatusEffect(StatusEffects.HUNGER);p.removeStatusEffect(StatusEffects.WEAKNESS);p.removeStatusEffect(StatusEffects.NAUSEA);effect(p,StatusEffects.REGENERATION,320,2);mark(p,"hunger_protection",1800);}
            case "war_ration" -> {effect(p,StatusEffects.STRENGTH,400,2);if(p.getHealth()<p.getMaxHealth()/2)effect(p,StatusEffects.ABSORPTION,400,0);effect(p,StatusEffects.SLOWNESS,60,0);}
            default -> throw new IllegalArgumentException("Food lacks its own implemented behavior: "+s.action());
        }
    }
    public static boolean permitsEffect(LivingEntity entity,StatusEffectInstance effect) {
        if(!(entity instanceof PlayerEntity p))return true;
        if(effect.getEffectType().equals(StatusEffects.POISON)&&active(p,"poison_immunity"))return false;
        return !effect.getEffectType().equals(StatusEffects.HUNGER)||!active(p,"hunger_protection");
    }
    private static boolean equipped(PlayerEntity p,String action) {
        for(EquipmentSlot slot:List.of(EquipmentSlot.HEAD,EquipmentSlot.CHEST,EquipmentSlot.LEGS,EquipmentSlot.FEET,EquipmentSlot.OFFHAND)){
            var s=BossItems.spec(p.getEquippedStack(slot));
            if(s!=null&&s.action().equals(action)&&s.slot()!=null&&switch(s.slot()){
                case "head"->slot==EquipmentSlot.HEAD;case "feet"->slot==EquipmentSlot.FEET;
                case "legs"->slot==EquipmentSlot.LEGS;case "offhand"->slot==EquipmentSlot.OFFHAND;default->slot==EquipmentSlot.CHEST;
            })return true;
        }return false;
    }
    public static double knockbackFactor(LivingEntity entity) {
        if(!(entity instanceof PlayerEntity p))return 1;
        if(equipped(p,"crouch_bulwark")&&p.isSneaking()&&p.getVelocity().horizontalLengthSquared()<.01)return .45;
        return equipped(p,"village_ward")?.75:1;
    }
    public static void landed(LivingEntity entity,double distance) {
        if(entity instanceof ServerPlayerEntity p&&distance>1.5&&p.isSneaking()&&equipped(p,"slime_bounce")&&ready(p,"slime_bounce",100)) {
            p.setVelocity(p.getVelocity().x,.45,p.getVelocity().z);p.velocityModified=true;
            p.getEquippedStack(EquipmentSlot.FEET).damage(1,p,EquipmentSlot.FEET);
        }
    }
    public static float damageFactor(LivingEntity entity,DamageSource source) {
        if(!(entity instanceof PlayerEntity p))return 1;
        if(source.isIn(DamageTypeTags.IS_FALL)) {
            if(equipped(p,"moonstep"))return .35f;
            if(equipped(p,"slime_bounce"))return .25f;
        }
        if(source.isIn(DamageTypeTags.IS_PROJECTILE)&&equipped(p,"ice_barrier")&&snowBelow(p)&&ready(p,"ice_barrier",400))return .2f;
        if(source.isIn(DamageTypeTags.IS_FIRE))for(EquipmentSlot slot:EquipmentSlot.values()) {
            ItemStack armor=p.getEquippedStack(slot);var data=armor.getOrDefault(DataComponentTypes.CUSTOM_DATA,NbtComponent.DEFAULT).copyNbt();
            if(data.getInt("worldbosses_heatproof",0)>0){return 0;}
        }
        return 1;
    }
    private static boolean snowBelow(PlayerEntity p){String id=Registries.BLOCK.getId(p.getEntityWorld().getBlockState(p.getBlockPos().down()).getBlock()).getPath();return id.contains("snow")||id.contains("ice");}

    private static void tick(ServerWorld world) {
        for(ServerPlayerEntity p:world.getPlayers())tickPlayer(world,p);
        for(var i=DECOYS.iterator();i.hasNext();) {
            Decoy d=i.next();if(d.world!=world)continue;
            if(world.getTime()>=d.until||d.dummy.isRemoved()){d.dummy.discard();i.remove();continue;}
            if(world.getTime()%4==0) {
                spark(world,d.dummy.getEntityPos(),ParticleTypes.END_ROD,3);
                for(MobEntity mob:world.getEntitiesByClass(HostileEntity.class,d.dummy.getBoundingBox().expand(10),e->true))mob.setTarget(d.dummy);
            }
        }
        for(var i=BLASTS.iterator();i.hasNext();) {
            Blast b=i.next();if(b.world!=world)continue;
            if(world.getTime()<b.at){if(world.getTime()%4==0)spark(world,b.position,ParticleTypes.SMOKE,3);continue;}
            PlayerEntity owner=world.getPlayerByUuid(b.owner);
            if(b.destructive){BossExplosions.detonate(world,owner,b.position);i.remove();continue;}
            if(owner!=null)for(var target:targets(world,owner,b.position,b.radius)) {
                hit(world,owner,target,b.damage);target.takeKnockback(.6,b.position.x-target.getX(),b.position.z-target.getZ());
            }
            spark(world,b.position,ParticleTypes.EXPLOSION,1);i.remove();
        }
        for(var i=STEPS.entrySet().iterator();i.hasNext();) {
            var e=i.next();if(e.getKey().world!=world||world.getTime()<e.getValue().until)continue;
            BlockState at=world.getBlockState(e.getKey().pos);
            if(at.isOf(COOLING_STEP)||at.isAir())world.setBlockState(e.getKey().pos,e.getValue().original);i.remove();
        }
    }
    private static void tickPlayer(ServerWorld world,ServerPlayerEntity p) {
        if(p.isOnGround())DOUBLE_JUMPED.remove(p.getUuid());
        if(active(p,"desert_provision")&&world.getTime()%400==0)p.getHungerManager().add(2,.1f);
        if(active(p,"piglin_peace"))for(var mob:targets(world,p,p.getEntityPos(),8))if(mob instanceof PiglinEntity&&mob.getTarget()==p)mob.setTarget(null);
        if(active(p,"caravan")&&world.getTime()%10==0)for(var mob:targets(world,p,p.getEntityPos(),10))if(mob instanceof AnimalEntity&&mob.getTarget()==null)mob.getNavigation().startMovingTo(p,1.05);
        if(world.getTime()%5!=0)return;
        for(EquipmentSlot slot:List.of(EquipmentSlot.HEAD,EquipmentSlot.CHEST,EquipmentSlot.LEGS,EquipmentSlot.FEET)) {
            ItemStack stack=p.getEquippedStack(slot);var spec=BossItems.spec(stack);if(spec==null||!spec.category().equals("equipment"))continue;
            switch(spec.action()) {
                case "frost_mantle" -> {p.setFrozenTicks(0);if(snowBelow(p)&&world.getTime()%100==0)p.heal(2f);if(p.hasStatusEffect(StatusEffects.SLOWNESS)&&snowBelow(p))p.removeStatusEffect(StatusEffects.SLOWNESS);}
                case "pack_guard" -> {
                    for(var pet:world.getEntitiesByClass(TameableEntity.class,p.getBoundingBox().expand(8),e->e.getOwner()==p)) {
                        effect(pet,StatusEffects.RESISTANCE,40,1);if(pet.hurtTime>0)effect(p,StatusEffects.SPEED,60,0);
                    }
                }
                case "moonstep" -> {
                    effect(p,StatusEffects.JUMP_BOOST,40,1);
                    if(!p.isOnGround()&&p.isSneaking()&&p.getVelocity().y<.12) {
                        p.setVelocity(p.getVelocity().x,.42,p.getVelocity().z);p.velocityModified=true;DOUBLE_JUMPED.add(p.getUuid());stack.damage(1,p,slot);
                    }
                }
                case "mire_walk" -> {
                    var below=world.getBlockState(p.getBlockPos().down());if(below.isOf(Blocks.MYCELIUM)||below.isOf(Blocks.PODZOL))p.removeStatusEffect(StatusEffects.POISON);
                    if(below.isOf(Blocks.MUD)||below.isOf(Blocks.MUDDY_MANGROVE_ROOTS))effect(p,StatusEffects.SPEED,40,1);
                }
                case "cat_stealth" -> {
                    if(p.isSneaking()){effect(p,StatusEffects.NIGHT_VISION,220,0);for(var mob:targets(world,p,p.getEntityPos(),8))if(mob instanceof CreeperEntity&&mob.getTarget()==p)mob.setTarget(null);}
                }
                case "crouch_bulwark" -> {if(p.isSneaking()&&p.getVelocity().horizontalLengthSquared()<.01)effect(p,StatusEffects.RESISTANCE,30,2);}
                case "village_ward" -> {for(var villager:world.getEntitiesByClass(VillagerEntity.class,p.getBoundingBox().expand(8),e->true))effect(villager,StatusEffects.RESISTANCE,50,1);}
                case "cloud_rescue" -> {
                    if(p.fallDistance>4&&ready(p,"cloud_rescue",800)){effect(p,StatusEffects.SLOW_FALLING,140,0);stack.damage(5,p,slot);}
                }
                case "phantom_glide" -> {
                    if(!p.isOnGround()&&p.isSneaking()&&ready(p,"phantom_glide",400)){effect(p,StatusEffects.SLOW_FALLING,120,0);stack.damage(2,p,slot);}
                }
                case "slime_bounce" -> {
                    effect(p,StatusEffects.JUMP_BOOST,30,0);
                }
                case "siege_charge" -> {
                    int t=p.isSprinting()?SPRINT.merge(p.getUuid(),5,Integer::sum):0;if(!p.isSprinting())SPRINT.put(p.getUuid(),0);
                    if(t>=30&&!targets(world,p,p.getEntityPos(),1.8).isEmpty()&&ready(p,"siege_charge",600)) {
                        for(var m:targets(world,p,p.getEntityPos(),1.8))m.takeKnockback(1.3,p.getX()-m.getX(),p.getZ()-m.getZ());stack.damage(2,p,slot);SPRINT.put(p.getUuid(),0);
                    }
                }
                case "lava_step" -> {
                    BlockPos below=p.getBlockPos().down();
                    if(world.getBlockState(below).isOf(Blocks.LAVA)&&world.canEntityModifyAt(p,below)) {
                        STEPS.put(new StepKey(world,below.toImmutable()),new Step(world.getBlockState(below),world.getTime()+60));world.setBlockState(below,COOLING_STEP.getDefaultState());stack.damage(1,p,slot);
                    }
                }
                default -> {}
            }
        }
    }

    private static void bonusHit(ServerWorld world,LivingEntity target,DamageSource source,float amount) {
        int remaining=target.timeUntilRegen;
        target.timeUntilRegen=0;
        try {target.damage(world,source,amount);}
        finally {target.timeUntilRegen=Math.max(remaining,target.timeUntilRegen);}
    }

    private static void onHit(LivingEntity target,DamageSource source,float base,float actual,boolean blocked) {
        if(BONUS_DAMAGE.get()||!(source.getAttacker() instanceof ServerPlayerEntity p)||!(p.getEntityWorld() instanceof ServerWorld world))return;
        var spec=BossItems.spec(p.getMainHandStack());
        if(spec!=null&&spec.action().equals("shield_cleaver")&&target instanceof PlayerEntity defender&&defender.isUsingItem()) {
            ItemStack shield=defender.getActiveItem();
            if(shield.contains(DataComponentTypes.BLOCKS_ATTACKS)){defender.stopUsingItem();defender.getItemCooldownManager().set(shield,80);}
        }
        if(blocked||actual<=0)return;
        if(p.getMainHandStack().isOf(BossItems.ALL.get("bone_sword")))effect(target,StatusEffects.GLOWING,60,0);
        if(spec==null)return;String a=spec.action();
        BONUS_DAMAGE.set(true);
        try {
            switch(a) {
                case "ambush_blade" -> {
                    Vec3d behind=p.getEntityPos().subtract(target.getEntityPos()).normalize();
                    if(target.getRotationVec(1).dotProduct(behind)<-.25&&ready(p,"ambush_strike",160)){bonusHit(world,target,world.getDamageSources().magic(),9);effect(target,StatusEffects.GLOWING,80,0);}
                }
                case "venom_blade" -> {
                    boolean already=target.hasStatusEffect(StatusEffects.POISON);effect(target,StatusEffects.POISON,80,0);
                    if(already&&ready(p,"venom_recover",120))p.heal(4);
                }
                case "ash_blade" -> {if(ready(p,"ash_strike",100)){effect(target,StatusEffects.WITHER,60,0);if(target.getArmor()>0)bonusHit(world,target,world.getDamageSources().magic(),6);}}
                case "shield_cleaver" -> {
                    if(target instanceof PlayerEntity defender&&defender.isUsingItem()) {ItemStack shield=defender.getActiveItem();defender.stopUsingItem();defender.getItemCooldownManager().set(shield,80);}
                }
                case "mounted_lance" -> {if(p.hasVehicle()||active(p,"charged_mounted_lance")){bonusHit(world,target,world.getDamageSources().magic(),6);mark(p,"charged_mounted_lance",0);}}
                case "wraith_dash" -> {if(active(p,"charged_wraith_dash")){bonusHit(world,target,world.getDamageSources().magic(),9);mark(p,"charged_wraith_dash",0);}}
                case "brute_charge" -> {if(active(p,"charged_brute")){bonusHit(world,target,world.getDamageSources().playerAttack(p),9);target.takeKnockback(.8,p.getX()-target.getX(),p.getZ()-target.getZ());mark(p,"charged_brute",0);}}
                default -> {}
            }
        } finally{BONUS_DAMAGE.set(false);}
    }
    public static void markArrow(PersistentProjectileEntity arrow,ItemStack weapon) {
        if(weapon==null)return;
        if(BossItems.freeAmmo(weapon)){arrow.setDamage(6);arrow.pickupType=PersistentProjectileEntity.PickupPermission.CREATIVE_ONLY;}
        if(weapon.isOf(BossItems.ALL.get("bone_bow"))||weapon.isOf(BossItems.LONG_BOW)){arrow.addCommandTag("worldbosses:arrow:soul_arrow");return;}
        if(weapon==null)return;var spec=BossItems.spec(weapon);if(spec!=null&&spec.action().endsWith("_arrow"))arrow.addCommandTag("worldbosses:arrow:"+spec.action());
    }
    public static void arrowHit(PersistentProjectileEntity arrow,EntityHitResult hit) {
        if(!(arrow.getEntityWorld() instanceof ServerWorld)||!(hit.getEntity() instanceof LivingEntity target)||!target.isAlive())return;
        for(String tag:arrow.getCommandTags())if(tag.startsWith("worldbosses:arrow:"))switch(tag.substring("worldbosses:arrow:".length())) {
            case "soul_arrow" -> effect(target,StatusEffects.GLOWING,100,0);
            case "frost_arrow" -> {effect(target,StatusEffects.SLOWNESS,60,0);target.setFrozenTicks(Math.min(150,target.getFrozenTicks()+60));}
            case "toxic_arrow" -> effect(target,StatusEffects.POISON,60,0);
            case "siege_arrow" -> target.takeKnockback(.6,-arrow.getVelocity().x,-arrow.getVelocity().z);
            default -> {}
        }
    }
    public static boolean projectileHit(SnowballEntity shot,HitResult collision) {
        String action=shot.getCommandTags().stream().filter(t->t.startsWith("worldbosses:shot:")).findFirst().map(t->t.substring("worldbosses:shot:".length())).orElse(null);
        if(action==null||!(shot.getEntityWorld() instanceof ServerWorld world)||!(shot.getOwner() instanceof PlayerEntity owner))return false;
        Vec3d point=collision.getPos();
        if(action.equals("crack_grenade")||action.equals("ghast_shell"))BLASTS.add(new Blast(world,point,world.getTime()+(action.equals("crack_grenade")?20:4),owner.getUuid(),21,6,action.equals("crack_grenade")));
        else if(collision instanceof EntityHitResult hit&&hit.getEntity() instanceof LivingEntity target) {
            hit(world,owner,target,action.equals("frost_snowball")?8:14);
            if(action.equals("frost_snowball")){effect(target,StatusEffects.SLOWNESS,60,0);target.setFrozenTicks(Math.min(150,target.getFrozenTicks()+70));}
            else target.setOnFireFor(4);
        }
        spark(world,point,action.equals("frost_snowball")?ParticleTypes.SNOWFLAKE:ParticleTypes.FLAME,15);shot.discard();return true;
    }
    private static void openPocket(PlayerEntity player,ItemStack carrier) {
        SimpleInventory inventory=new SimpleInventory(9) {
            @Override public void markDirty(){super.markDirty();DefaultedList<ItemStack> contents=DefaultedList.ofSize(9,ItemStack.EMPTY);for(int i=0;i<9;i++)contents.set(i,getStack(i).copy());carrier.set(DataComponentTypes.CONTAINER,ContainerComponent.fromStacks(contents));}
        };
        DefaultedList<ItemStack> initial=DefaultedList.ofSize(9,ItemStack.EMPTY);carrier.getOrDefault(DataComponentTypes.CONTAINER,ContainerComponent.DEFAULT).copyTo(initial);
        for(int i=0;i<9;i++)inventory.setStack(i,initial.get(i));
        player.openHandledScreen(new SimpleNamedScreenHandlerFactory((syncId,playerInventory,user)->new GenericContainerScreenHandler(ScreenHandlerType.GENERIC_9X1,syncId,playerInventory,inventory,1) {
            {for(int i=0;i<9;i++){final int index=i;Slot old=slots.get(i);Slot safe=new Slot(inventory,index,old.x,old.y){@Override public boolean canInsert(ItemStack item){var spec=BossItems.spec(item);return item!=carrier&&!item.contains(DataComponentTypes.CONTAINER)&&!item.isIn(ItemTags.SHULKER_BOXES)&&(spec==null||!spec.action().equals("pocket_vault"));}};safe.id=i;slots.set(i,safe);}}
            @Override public boolean canUse(PlayerEntity p){for(int i=0;i<p.getInventory().size();i++)if(p.getInventory().getStack(i)==carrier)return true;return false;}
        },Text.literal("紫晶随身匣 · 九格储物")));
    }
    private BossItemEffects(){}
}
