package dev.susu.worldbosses;

import dev.susu.worldbosses.client.BossShapes;
import net.fabricmc.fabric.api.client.gametest.v1.FabricClientGameTest;
import net.fabricmc.fabric.api.client.gametest.v1.context.ClientGameTestContext;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.entity.model.*;
import net.minecraft.client.render.entity.state.*;
import net.minecraft.client.util.math.MatrixStack;

/** Uses real vanilla constructors and actual vertex emission with the production Mixins active. */
public final class BossRenderTests implements FabricClientGameTest {
    @Override public void runTest(ClientGameTestContext context) {
        context.runOnClient(client->{
            var loader=client.getLoadedEntityModels();
            check("frog",new FrogEntityModel(loader.getModelPart(EntityModelLayers.FROG)),new FrogEntityRenderState());
            check("vex",new VexEntityModel(loader.getModelPart(EntityModelLayers.VEX)),new VexEntityRenderState());
            check("allay",new AllayEntityModel(loader.getModelPart(EntityModelLayers.ALLAY)),new AllayEntityRenderState());
            check("cow",new CowEntityModel(loader.getModelPart(EntityModelLayers.COW)),new LivingEntityRenderState());
        });
    }
    private static <S extends LivingEntityRenderState> void check(String id,EntityModel<S> model,S state) {
        state.age=23;state.relativeHeadYaw=25;state.limbSwingAmplitude=.6f;state.limbSwingAnimationProgress=3;
        model.setAngles(state);
        Counter sink=new Counter();model.getRootPart().render(new MatrixStack(),sink,0xF000F0,0);
        int expected=BossShapes.data(id).boxes().size()*24;
        if(sink.vertices!=expected)throw new AssertionError(id+" emitted "+sink.vertices+" vertices; expected full sculpture "+expected);
        if(sink.maxY>1.65f)throw new AssertionError(id+" rendered below its authored ground plane: y="+sink.maxY);
        var head=model.getRootPart().getChild("worldbosses_full_sculpture").traverse().stream()
                .filter(part->part.hasChild("wb_head")).findFirst().orElseThrow().getChild("wb_head");
        if(Math.abs(head.yaw-(float)Math.toRadians(25))>.001f)throw new AssertionError(id+" lost its own head animation");
        System.out.println("BOSS_RENDER_PASS "+id+" vertices="+sink.vertices+" maxY="+sink.maxY+" headYaw="+head.yaw);
    }
    private static final class Counter implements VertexConsumer {
        int vertices;float maxY=Float.NEGATIVE_INFINITY;
        public VertexConsumer vertex(float x,float y,float z){vertices++;maxY=Math.max(maxY,y);return this;}
        public VertexConsumer color(int r,int g,int b,int a){return this;}
        public VertexConsumer texture(float u,float v){return this;}
        public VertexConsumer overlay(int u,int v){return this;}
        public VertexConsumer light(int u,int v){return this;}
        public VertexConsumer normal(float x,float y,float z){return this;}
    }
}
