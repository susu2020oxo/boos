#!/usr/bin/env python3
"""Package the tested remapped mod and Fabric API without bundling game binaries or test worlds."""
from pathlib import Path
import hashlib,json,shutil,zipfile,xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parents[1];OUT=ROOT.parent/'artifacts';OUT.mkdir(exist_ok=True)
version=next(s.split('=',1)[1] for s in (ROOT/'gradle.properties').read_text().splitlines() if s.startswith('mod_version='))
stem='worldbosses-'+version
jar=ROOT/f'build/libs/{stem}.jar'
with zipfile.ZipFile(jar) as archive:
    meta=json.loads(archive.read('fabric.mod.json'));assert meta['version']==version and archive.testzip() is None
    assert len([n for n in archive.namelist() if '/boss_models/' in n and n.endswith('.json')])==68
installed=OUT/f'{stem}-fabric-1.21.10.jar';shutil.copy2(jar,installed)
api=next((ROOT.parent/'tools/gradle-home/caches/modules-2/files-2.1/net.fabricmc.fabric-api/fabric-api').rglob('fabric-api-0.138.4+1.21.10.jar'))
instructions=OUT/f'{stem}-安装说明.txt'
instructions.write_text(f'''万物皆 Boss {version}
Minecraft Java 1.21.10 · Fabric · Java 21

安装：
1. 在启动器选择 Minecraft 1.21.10 的 Fabric 配置，Fabric Loader 0.17.3 或更新版本。
2. 把安装包 mods 文件夹里的两个 JAR 放进该游戏实例的 mods 文件夹。
3. 若已有 Fabric API，保留对应版本的一份即可。更新时移出旧的 World Bosses JAR。
4. 客户端和多人服务器均需安装。启动游戏。

此包包含模组和 Fabric API；不包含 Minecraft 本体或启动器。

本版：
0.3.2：全部8种模组食物在生存模式下每次食用消耗1份，强化效果保留。
0.3.1修复青蛙、恼鬼与悦灵模型不可见，纠正实际渲染节点、高度与动画绑定。
监守者比0.2版大5倍；铁傀儡、马、野猪、蜘蛛和洞穴蜘蛛重做。
苦力怕/裂核弹爆炸强度200，会摧毁方块；技能免消耗、无冷却，装备属性加强。
68 种非水生 Boss 的新身体模型、独立材质和发光层。
68 件专属成品：21 武器、25 工具、6 增益食物、16 装备，各有独立作用与三维物品模型。
68 种立体刷怪蛋。创造模式按四个中文分类查看物品；操作说明在物品悬浮提示中。
猪/牛 16 HP，羊 12 HP，鸡 8 HP；友好动物保留原版行为。
猪额外掉落 72–96 个猪排，着火时为熟猪排；还掉专属增益肉排。
每位玩家周围 128 格，相交区域合并；每战斗家族自然生成上限 4 只、总量默认 12 只。
配置文件：config/worldbosses.json。
旧材料保留用于旧存档兼容，可用三份旧材料回收对应新成品。

技能仍有共享招式框架；未完成所有生物的复杂阶段连招。
已通过构建、6 项生成预算单元测试、5 项资源测试、20 项模组 GameTest 及正式 JAR 客户端检查。
细节、逐种掉落说明和检查范围见 README.md 与 专属掉落图鉴.md。
''',encoding='utf-8')
install=OUT/f'{stem}-install.zip'
with zipfile.ZipFile(install,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    z.write(installed,'mods/'+installed.name);z.write(api,'mods/'+api.name)
    z.write(instructions,'安装说明.txt');z.write(ROOT/'README.md','README.md');z.write(ROOT/'design/loot-v2-catalog.md','专属掉落图鉴.md')
source=OUT/f'{stem}-source.zip'
with zipfile.ZipFile(source,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for path in sorted(ROOT.rglob('*')):
        rel=path.relative_to(ROOT)
        if not path.is_file() or any(p in {'.git','.gradle','build','run','__pycache__'} for p in rel.parts) or path.suffix=='.pyc':continue
        z.write(path,str(Path(stem)/rel))
content=json.loads((ROOT/'build/reports/v2-content.json').read_text());assert not content['errors']
tests=ET.parse(ROOT/'build/gametest-results.xml').getroot();cases=tests.findall('.//testcase');assert not tests.findall('.//failure')
mod_tests=sum('worldbosses_gametest:' in c.get('name','') for c in cases)
assert mod_tests==20
log=(ROOT/'build/production-smoke/launcher-output.log').read_text()
assert 'logged in with entity id' in log and 'All 68 Boss species created for visual QA' in log
assert 'All 68 rewards and 68 spawn eggs created for visual QA' in log
assert 'Invisible-model regression gallery created for visual QA' in log
client_tests=(ROOT/'build/client-gametest.log').read_text()
assert all('BOSS_RENDER_PASS '+species+' ' in client_tests for species in ('frog','vex','allay','cow'))
assert 'BUILD SUCCESSFUL' in client_tests
assert not any(s in log for s in ['Missing textures in model worldbosses:','Mixin apply failed','InvalidMixinException'])
proof={'version':version,'minecraft':'1.21.10','loader':'0.17.3','fabric_api':'0.138.4+1.21.10',
       'build':'passed','spawn_budget_unit_tests':6,'resource_tests':5,'mod_gametests':mod_tests,
       'minecraft_baseline_tests':len(cases)-mod_tests,'independent_boss_models':len(content['models']),
       'new_finished_rewards':len(content['items']),'categories':content['categories'],
       'client_render_regressions':['frog','vex','allay','cow'],
       'actual_jar_client_world_entry':True,'all_68_boss_species_loaded_in_client_world':True,
       'all_68_reward_models_and_68_spawn_egg_models_loaded':True,
       'missing_mod_texture_warnings':False,
       'limitations':['Shared hostile ability patterns remain; advanced per-species phases are unfinished.',
                      'Long-term multiplayer balance and every animation state have not been exhaustively tested.']}
validation=OUT/f'{stem}-validation.json';validation.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
files=[installed,install,source,instructions,validation]
hashes=OUT/f'{stem}-SHA256SUMS.txt'
hashes.write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n' for p in files))
for p in files+[hashes]:print(p.name,p.stat().st_size,'bytes')
