#!/usr/bin/env python3
"""Standalone download card: embeds one stored ZIP and extracts the identical tested JAR locally."""
from pathlib import Path
import base64,io,zipfile,json,hashlib

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT.parent/'artifacts'
VERSION=next(line.split('=',1)[1].strip() for line in (ROOT/'gradle.properties').read_text().splitlines() if line.startswith('mod_version='))
STEM='worldbosses-'+VERSION
JAR=OUT/(STEM+'-fabric-1.21.10.jar')
proof=json.loads((OUT/(STEM+'-validation.json')).read_text())
assert proof['version']==VERSION and proof['build']=='passed'
with zipfile.ZipFile(JAR) as jar:
    assert jar.testzip() is None and json.loads(jar.read('fabric.mod.json'))['version']==VERSION
buf=io.BytesIO()
with zipfile.ZipFile(OUT/(STEM+'-install.zip')) as source,zipfile.ZipFile(buf,'w',zipfile.ZIP_STORED) as dest:
    for name in source.namelist():dest.writestr(name,source.read(name))
payload=buf.getvalue()
with zipfile.ZipFile(io.BytesIO(payload)) as z:
    assert z.testzip() is None and z.read('mods/'+JAR.name)==JAR.read_bytes()
metadata={'jarName':JAR.name,'jarPath':'mods/'+JAR.name,'zipName':STEM+'-offline-install.zip',
          'jarSha256':hashlib.sha256(JAR.read_bytes()).hexdigest(),'jarBytes':JAR.stat().st_size,'zipBytes':len(payload)}
html='''<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>万物皆 Boss v__VERSION__ · 下载</title>
<style>
*{box-sizing:border-box}body{margin:0;padding:28px 32px;color:#111;background:#fcfcfc;font:16px/1.5 system-ui,-apple-system,"Microsoft YaHei",sans-serif}main{max-width:960px;margin:auto}h1{font-size:23px;margin:0 0 22px}.card{padding:16px;border:1px solid #dedede;border-radius:21px;background:#fff}.top{display:flex;gap:16px;align-items:center;margin-bottom:14px}.icon{width:78px;height:78px;flex:none;border:1px solid #eee;border-radius:20px;padding:8px;background:#fafafa}.info{flex:1;min-width:0}h2{font-size:22px;line-height:1.3;margin:0 0 7px}.meta{font-size:15px;color:#626262;margin:2px 0}.badge{background:#d7f3df;color:#05812b;border-radius:16px;padding:3px 10px;font-size:14px;white-space:nowrap}.button{display:flex;justify-content:center;align-items:center;gap:10px;width:100%;min-height:46px;border-radius:28px;text-decoration:none;cursor:pointer;font:inherit;font-size:19px;line-height:1.4;padding:10px 16px}.primary{background:#101010;color:white;border:1px solid #101010}.secondary{background:white;color:#555;border:1px solid #d1d1d1;margin-top:13px}.button:hover{filter:brightness(.94)}.button:focus-visible,summary:focus-visible{outline:3px solid #66a6e3;outline-offset:3px}.button svg{width:22px;height:22px;flex:none}details{margin-top:16px}summary{text-decoration:underline;cursor:pointer;width:max-content}.help{font-size:14px;color:#666;margin:12px 0 0}.details{padding:12px 0 0;color:#444;font-size:15px}.details p{margin:5px 0}#status{min-height:22px;font-size:14px;color:#555;margin:9px 0 0}code{overflow-wrap:anywhere;font-size:12px}@media(max-width:550px){body{padding:20px 12px}.card{padding:14px}.top{gap:10px;flex-wrap:wrap}h2{font-size:19px}.badge{margin-left:88px;margin-top:-5px}.icon{width:72px;height:72px}.button{font-size:17px}}
</style></head><body><main><h1>下载 v__VERSION__</h1><article class="card" aria-label="万物皆 Boss 模组下载">
<div class="top"><svg class="icon" viewBox="0 0 64 64" role="img" aria-label="磐角牛 Boss"><path fill="#eee4c3" d="M7 2h9v21H7zm41 0h9v21h-9z"/><path fill="#282b30" d="M9 19h46v35H9z"/><path fill="#4d5358" d="M5 25h12v22H5zm42 0h12v22H47zM18 14h28v9H18z"/><path fill="#809146" d="M7 20h9v5H7zm41 1h8v8h-5v10h-3z"/><path fill="#e9e4d7" d="M28 22h8v13h-8zM18 31h8v7h-8zm20 0h8v7h-8z"/><path fill="#101116" d="M20 32h4v5h-4zm20 0h4v5h-4z"/><path fill="#d99a9e" d="M18 42h28v15H18z"/><path fill="#714950" d="M23 46h5v5h-5zm13 0h5v5h-5z"/></svg>
<div class="info"><h2>万物皆 Boss v__VERSION__</h2><p class="meta">Java 1.21.10 · Fabric</p><p class="meta">JAR · __JAR_SIZE__ MB</p></div><span class="badge">编译成功</span></div>
<a class="button primary" id="download-jar" href="#"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v12m-5-5 5 5 5-5M4 16v4h16v-4"/></svg>下载 MOD（JAR）</a>
<a class="button secondary" id="download-zip" href="#"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H5v20h14V7zM14 2v5h5M10 3v2m0 2v2m0 2v2m0 2v3h3v-3z"/></svg>下载完整 ZIP 安装包</a>
<p id="status" role="status" aria-live="polite">ZIP 包含本模组和对应 Fabric API。</p>
<details><summary>安装说明与版本内容</summary><div class="details"><p>使用 Minecraft Java 1.21.10、Fabric Loader 0.17.3 或更新版本、Java 21。</p><p>解压 ZIP，将 mods 文件夹中的两个 JAR 放入游戏实例的 mods 文件夹，移出旧版本模组后启动游戏。</p><p>本版修复：全部 8 种食物在生存模式下每次消耗 1 个，强化效果保留。</p><p>构建与 __GAME_TESTS__ 项模组 GameTest 通过。本次食物修复未重新进行图形客户端检查。</p><p>此页面内置安装文件，可离线使用。首次点击可能需要几秒钟准备文件。</p><p>MOD SHA-256：<code id="checksum"></code></p></div></details>
<noscript><p>请在浏览器启用 JavaScript 后使用下载按钮。</p></noscript></article></main>
<script type="application/json" id="metadata">__METADATA__</script>
<script type="application/octet-stream" id="payload">__PAYLOAD__</script>
<script>
'use strict';
const metadata=JSON.parse(document.getElementById('metadata').textContent);
document.getElementById('checksum').textContent=metadata.jarSha256;
let archive;
function bytes(){if(!archive){const raw=atob(document.getElementById('payload').textContent.trim());archive=new Uint8Array(raw.length);for(let i=0;i<raw.length;i++)archive[i]=raw.charCodeAt(i);}return archive;}
function extractJar(data){const view=new DataView(data.buffer,data.byteOffset,data.byteLength),decoder=new TextDecoder();let pos=0;
 while(pos+30<=data.length&&view.getUint32(pos,true)===0x04034b50){
  const flags=view.getUint16(pos+6,true),method=view.getUint16(pos+8,true),size=view.getUint32(pos+18,true),nameLength=view.getUint16(pos+26,true),extraLength=view.getUint16(pos+28,true);
  if(flags&8||method!==0)throw Error('安装文件格式不正确');
  const start=pos+30+nameLength+extraLength,end=start+size;if(end>data.length)throw Error('安装文件不完整');
  const name=decoder.decode(data.subarray(pos+30,pos+30+nameLength));
  if(name===metadata.jarPath){if(size!==metadata.jarBytes)throw Error('MOD 文件大小不符');return data.subarray(start,end);}pos=end;
 }throw Error('没有找到 MOD 文件');}
const status=document.getElementById('status');let busy=false;
for(const kind of ['jar','zip'])document.getElementById('download-'+kind).addEventListener('click',async event=>{
 event.preventDefault();if(busy)return;busy=true;status.textContent='正在准备下载文件…';
 try{await new Promise(resolve=>setTimeout(resolve,25));const data=kind==='jar'?extractJar(bytes()):bytes();
 const url=URL.createObjectURL(new Blob([data],{type:kind==='jar'?'application/java-archive':'application/zip'}));
 const link=document.createElement('a');link.href=url;link.download=kind==='jar'?metadata.jarName:metadata.zipName;document.body.appendChild(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),60000);
 status.textContent='已向浏览器发起下载。请在下载列表中查看；若无反应，请允许此页面下载文件。';
 }catch(error){status.textContent='下载失败：'+error.message+'。请重新保存并用浏览器打开此页面。';}finally{busy=false;}
});
</script></body></html>'''
html=(html.replace('__VERSION__',VERSION).replace('__JAR_SIZE__',f'{JAR.stat().st_size/1024/1024:.1f}')
      .replace('__GAME_TESTS__',str(proof['mod_gametests']))
      .replace('__METADATA__',json.dumps(metadata,ensure_ascii=False)).replace('__PAYLOAD__',base64.b64encode(payload).decode()))
target=OUT/(STEM+'-download.html');target.write_text(html,encoding='utf-8')
shutil_target=OUT/'worldbosses-download.html';shutil_target.write_text(html,encoding='utf-8')
print(json.dumps({'page':str(target),'bytes':target.stat().st_size,'jarSha256':metadata['jarSha256'],'embeddedZipBytes':len(payload)}))
